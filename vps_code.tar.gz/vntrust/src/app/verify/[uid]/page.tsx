"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

export default function VerificationResult() {
  const { uid } = useParams();
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useState<{ lat: number, lon: number, city: string } | null>(null);

  useEffect(() => {
    fetch(`/api/verify/${uid}`)
      .then(res => res.json())
      .then(data => {
        setResult(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });

    fetch('https://ipapi.co/json/')
      .then(res => res.json())
      .then(data => {
        if (data.latitude && data.longitude) {
          setLocation({ lat: data.latitude, lon: data.longitude, city: data.city || "IP Client" });
        }
      }).catch(err => console.error("Location fetch failed", err));
  }, [uid]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  const isFake = result?.status === "fake";
  const isSuspect = result?.status === "suspect";
  const isExpired = result?.status === "expired";
  const isGenuine = result?.status === "genuine";

  const pData = result?.data || {};
  const loHang = pData.loHang || {};
  const sanPham = loHang.sanPham || {};

  return (
    <div className="px-6 md:px-12 max-w-7xl mx-auto pb-12">
      {/* Hero: Verification Status */}
      <section className="relative mb-12">
        <div className={`flex flex-col md:flex-row items-center gap-8 p-8 rounded-xl ghost-border overflow-hidden ${
          isGenuine ? "bg-emerald-500/10 border-emerald-500/30" :
          isSuspect ? "bg-yellow-500/10 border-yellow-500/30" :
          isExpired ? "bg-slate-500/10 border-slate-500/30" :
          "bg-red-500/10 border-red-500/30"
        }`}>
          <div className="absolute top-0 right-0 opacity-5 pointer-events-none translate-x-1/4 -translate-y-1/4">
            <span className="material-symbols-outlined text-[300px]" style={{ fontVariationSettings: "'FILL' 1" }}>
              {isFake ? "cancel" : isExpired ? "timer_off" : isSuspect ? "warning" : "verified"}
            </span>
          </div>
          <div className={`relative w-32 h-32 md:w-48 md:h-48 flex items-center justify-center rounded-full ${
            isGenuine ? "bg-emerald-500/20" :
            isSuspect ? "bg-yellow-500/20" :
            isExpired ? "bg-slate-500/20" :
            "bg-red-500/20"
          }`}>
            <span className={`material-symbols-outlined text-7xl md:text-9xl ${
              isGenuine ? "text-emerald-500" :
              isSuspect ? "text-yellow-500" :
              isExpired ? "text-slate-400" :
              "text-red-500"
            }`} style={{ fontVariationSettings: "'FILL' 1" }}>
              {isFake ? "cancel" : isExpired ? "timer_off" : isSuspect ? "warning" : "verified"}
            </span>
            <div className={`absolute inset-0 rounded-full border-4 animate-pulse opacity-20 ${
              isGenuine ? "border-emerald-500" :
              isSuspect ? "border-yellow-500" :
              isExpired ? "border-slate-500" :
              "border-red-500"
            }`}></div>
          </div>
          <div className="flex-1 text-center md:text-left z-10">
            <div className="flex flex-wrap justify-center md:justify-start gap-2 mb-4">
              <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest font-label ${
                isGenuine ? "bg-emerald-500 text-white" :
                isSuspect ? "bg-yellow-500 text-white" :
                isExpired ? "bg-slate-600 text-white" :
                "bg-red-600 text-white"
              }`}>
                {isFake ? "Cảnh báo: Hàng giả" : isExpired ? "Cảnh báo: Hết hạn" : isSuspect ? "Bất thường Bảo mật" : "Xác thực Chính hãng"}
              </span>
              <span className="px-3 py-1 bg-surface-variant text-on-surface-variant rounded-full text-xs font-bold font-label tracking-widest uppercase">Mã: {uid}</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-headline font-extrabold tracking-tighter text-on-surface mb-2">
              {isFake ? "Tài sản Không hợp lệ" : isSuspect ? "Hoạt động Đáng ngờ" : isExpired ? "Sản phẩm Hết hạn" : "Xác thực Chính hãng"}
            </h1>
            <p className="text-on-surface-variant max-w-xl text-lg">
              {isFake ? "Sản phẩm này không tồn tại trên sổ cái blockchain của chúng tôi. Đây có thể là hàng giả." :
               isSuspect ? `Sản phẩm này đã bị quét ${result?.scanCount} lần. Hoạt động bất thường này đã bị gắn cờ.` :
               isExpired ? "Sản phẩm là chính hãng nhưng đã quá hạn sử dụng." :
               "Sản phẩm đã được quét và xác thực thành công qua Sổ cái Bất biến VNTrust. Nguồn gốc và xuất xứ được xác nhận 100%."}
            </p>
          </div>
        </div>
      </section>

      {!isFake && (
        <>
          {/* Product Data Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-12">
            
            {/* Product Specs */}
            <div className="md:col-span-4 flex flex-col gap-6">
              <div className="bg-surface-container-low p-6 rounded-xl flex flex-col justify-between min-h-[200px]">
                <span className="text-xs font-label text-outline uppercase tracking-widest mb-4">Định danh Sản phẩm</span>
                <div>
                  <h2 className="text-2xl font-headline font-bold mb-1">{sanPham.ten || "Sản phẩm không xác định"}</h2>
                  <p className="text-on-surface-variant font-body">{sanPham.moTa || "Không có mô tả"}</p>
                </div>
              </div>
              <div className="bg-surface-container-lowest ghost-border p-6 rounded-xl">
                <span className="text-xs font-label text-outline uppercase tracking-widest mb-4 block">Nhật ký Sản xuất</span>
                <div className="space-y-4">
                  <div>
                    <p className="text-[10px] uppercase text-outline mb-1">Mã lô hàng</p>
                    <p className="font-bold text-on-surface font-headline">{loHang.maLo || "N/A"}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-outline mb-1">Ngày sản xuất</p>
                    <p className="font-bold text-on-surface font-headline">
                      {loHang.ngaySanXuat ? new Date(loHang.ngaySanXuat).toLocaleDateString() : "N/A"}
                    </p>
                  </div>
                  <div className="pt-4 border-t border-outline-variant/20">
                    <div className="flex items-center gap-2 text-primary font-bold text-sm">
                      <span className="material-symbols-outlined text-sm">link</span>
                      <span>XEM HASH BLOCKCHAIN</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Digital Twin Timeline */}
            <div className="md:col-span-5 bg-surface-container-low rounded-xl p-8">
              <div className="flex justify-between items-start mb-8">
                <h3 className="font-headline font-bold text-xl">Hành trình Bản sao Kỹ thuật số</h3>
                <span className="material-symbols-outlined text-primary-fixed-dim">hub</span>
              </div>
              <div className="relative space-y-8 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-outline-variant/30">
                <div className="relative flex gap-6 items-start">
                  <div className="z-10 w-6 h-6 bg-tertiary-container rounded-full flex items-center justify-center ring-4 ring-surface-container-low">
                    <span className="material-symbols-outlined text-xs text-white" style={{ fontVariationSettings: "'FILL' 1" }}>check</span>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-primary uppercase">Trạng thái Hiện tại</p>
                    <p className="font-bold text-on-surface">Được xác thực bởi Người dùng</p>
                    <p className="text-xs text-on-surface-variant">Hôm nay • Lần quét #{result?.scanCount}</p>
                  </div>
                </div>
                <div className="relative flex gap-6 items-start">
                  <div className="z-10 w-6 h-6 bg-outline-variant rounded-full flex items-center justify-center ring-4 ring-surface-container-low"></div>
                  <div>
                    <p className="font-bold text-on-surface">Khởi tạo Sổ cái Genesis</p>
                    <p className="text-xs text-on-surface-variant">Khởi động Hệ thống • Nút Bảo mật 01</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Map View & Location */}
            <div className="md:col-span-3 flex flex-col gap-6">
              <div className="bg-surface-container-low rounded-xl overflow-hidden h-full flex flex-col">
                <div className="p-4 bg-surface-container-high flex justify-between items-center">
                  <span className="text-[10px] font-bold uppercase tracking-tighter">Vị trí Xác thực Lần cuối</span>
                  <span className="material-symbols-outlined text-sm">location_on</span>
                </div>
                <div className="flex-1 min-h-[200px] relative pointer-events-none">
                  {location ? (
                    <iframe 
                      className="w-full h-full grayscale opacity-70 border-0" 
                      src={`https://www.openstreetmap.org/export/embed.html?bbox=${location.lon-0.05},${location.lat-0.05},${location.lon+0.05},${location.lat+0.05}&layer=mapnik&marker=${location.lat},${location.lon}`}
                    ></iframe>
                  ) : (
                    <img className="w-full h-full object-cover grayscale opacity-50" alt="map" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBoW5TKBMO9mez-ZTdAOisaDsO_PG66wUUEdSpVtIt8IoJxOhks00HlJ4s0JlY0z0_D7mbBpFjVqClt7qetRmhzAXYs3D_gmte7izqbWt0TBlv8lylWYechod99kCO5_sKQzwy25zcdZvN1s47_eBN2ggOHo31B4IBAsxzCgj9XSHtNk0A20q9O0GA3g7sv7fHaywy7XWBkTIL4KKEWTL6dZLNtDMLuBkBHFBCTvTkmDVg5RqvSzy5AA0ywMT9AQAeH4vut5cGJwAOs"/>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-8 h-8 bg-primary rounded-full pulse-glow flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-surface-container-lowest">
                  <p className="text-sm font-bold text-on-surface">{location ? location.city : "IP Khu vực Hiện tại"}</p>
                  <p className="text-xs text-on-surface-variant">{location ? `${location.lat.toFixed(4)} / ${location.lon.toFixed(4)}` : "Đang lấy Kinh độ/Vĩ độ..."}</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Digital Certificates Section */}
          <div className="bg-surface-container-low rounded-xl p-8 mb-12">
            <div className="flex items-center gap-3 mb-8">
              <span className="material-symbols-outlined text-emerald-500 text-3xl">workspace_premium</span>
              <div>
                <h3 className="font-headline font-black text-2xl text-on-surface">Chứng nhận & Tiêu chuẩn Chất lượng</h3>
                <p className="text-sm text-on-surface-variant">Các văn bản chứng nhận kỹ thuật số được đính kèm trên sổ cái.</p>
              </div>
            </div>
            
            {sanPham.chungNhans && sanPham.chungNhans.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sanPham.chungNhans.map((cn: any, idx: number) => (
                  <div key={idx} className="bg-surface-container-lowest border border-outline-variant/20 rounded-2xl p-6 relative overflow-hidden group hover:border-emerald-500/50 transition-all hover:shadow-lg hover:shadow-emerald-500/10 hover:-translate-y-1">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                      <span className="material-symbols-outlined text-5xl text-emerald-500" style={{ fontVariationSettings: "'FILL' 1" }}>verified_user</span>
                    </div>
                    <div className="mb-4">
                      <span className="inline-block px-3 py-1 bg-emerald-500/10 text-emerald-600 font-black text-[10px] tracking-widest uppercase rounded-full border border-emerald-500/20">{cn.loai}</span>
                    </div>
                    <h4 className="font-headline font-bold text-lg text-on-surface mb-1">{cn.soChungNhan}</h4>
                    <p className="text-xs text-on-surface-variant mb-4 flex items-center gap-1">
                      <span className="material-symbols-outlined text-[14px]">account_balance</span>
                      {cn.toChucCap || "Cơ quan Thẩm quyền"}
                    </p>
                    <div className="flex justify-between items-center text-[11px] border-t border-outline-variant/20 pt-4 mt-2">
                      <div>
                        <span className="block text-outline uppercase">Ngày cấp</span>
                        <span className="font-bold text-on-surface">{new Date(cn.ngayCap).toLocaleDateString()}</span>
                      </div>
                      <div className="text-right">
                        <span className="block text-outline uppercase">Hết hạn</span>
                        <span className="font-bold text-on-surface">{new Date(cn.ngayHetHan).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-surface-container rounded-2xl border border-dashed border-outline-variant/30">
                <span className="material-symbols-outlined text-outline mb-2 text-4xl">inventory_2</span>
                <p className="text-outline font-medium">Chưa có chứng nhận kỹ thuật số nào được ban hành cho sản phẩm này.</p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
