"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useLanguage } from "@/contexts/LanguageContext";

export default function LoginPage() {
  const { t } = useLanguage();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState<"login" | "register" | "forgot">("login");
  const [showPassword, setShowPassword] = useState(false);

  // Login states
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  // Register states
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regRole, setRegRole] = useState("");
  const [regPassword, setRegPassword] = useState("");

  const handleAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (view === "login") {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        
        if (res.ok && data.role) {
          localStorage.setItem("userRole", data.role);
          localStorage.setItem("userName", data.username || username);
          router.push("/dashboard");
        } else {
          alert(data.error || "Sai tên đăng nhập hoặc mật khẩu!");
          setLoading(false);
        }
      } else if (view === "register") {
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: regName,
            email: regEmail,
            phone: regPhone,
            role: regRole,
            password: regPassword
          })
        });
        const data = await res.json();

        if (res.ok) {
          alert("Đăng ký thành công! Vui lòng đăng nhập.");
          setView("login");
          setUsername(regEmail);
          setPassword(regPassword);
        } else {
          alert(data.error || "Đăng ký thất bại!");
        }
        setLoading(false);
      } else if (view === "forgot") {
        alert("Hướng dẫn đã được gửi vào email/sđt của bạn!");
        setView("login");
        setLoading(false);
      }
    } catch (error) {
      console.error(error);
      alert("Lỗi kết nối máy chủ!");
      setLoading(false);
    }
  };

  // Redirect if already logged in
  useEffect(() => {
    const role = localStorage.getItem("userRole");
    if (role) {
      router.replace("/dashboard");
    }
  }, [router]);

  const handleDemoLogin = (demoRole: string, demoUsername: string) => {
    setUsername(demoUsername);
    setPassword("123456");
  };

  return (
    <div className="fixed inset-0 min-h-screen bg-[#0b1320] flex flex-col items-center p-4 z-[100] overflow-y-auto">
      {/* Background decorations */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[10%] left-[20%] w-[30%] h-[30%] bg-blue-900/20 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[10%] right-[20%] w-[30%] h-[30%] bg-cyan-900/10 blur-[120px] rounded-full"></div>
      </div>

      <div className="relative z-10 w-full max-w-md my-auto py-8">
        {/* Logo Area */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500/20 to-blue-600/10 rounded-3xl flex items-center justify-center mb-4 border border-blue-500/20 shadow-lg shadow-blue-900/20 backdrop-blur-sm">
            <span className="material-symbols-outlined text-4xl text-blue-400">shield_person</span>
          </div>
          <h1 className="text-3xl font-headline font-bold text-white tracking-tight">VNTrust</h1>
          <p className="text-slate-400 mt-2 text-sm text-center font-medium">Hệ thống xác thực thông minh</p>
        </div>

        {/* Main Card */}
        <div className="bg-[#1a2235]/90 backdrop-blur-xl border border-slate-800/50 p-8 rounded-3xl w-full shadow-2xl relative transition-all">
          {view === "login" && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <h2 className="text-2xl font-bold text-white mb-2">Đăng nhập</h2>
              <p className="text-slate-400 text-sm mb-6">Nhập thông tin tài khoản để truy cập</p>

              <form onSubmit={handleAction} className="space-y-5">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Email / Số điện thoại</label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-purple-500 text-xl">person</span>
                    <input
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      type="text"
                      className="w-full bg-[#131b2c] border border-slate-700/50 text-white rounded-xl py-3.5 pl-12 pr-4 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all placeholder:text-slate-600"
                      placeholder="Email hoặc số điện thoại"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Mật khẩu</label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-orange-400 text-xl">lock</span>
                    <input
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      type={showPassword ? "text" : "password"}
                      className="w-full bg-[#131b2c] border border-slate-700/50 text-white rounded-xl py-3.5 pl-12 pr-12 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all placeholder:text-slate-600"
                      placeholder="Nhập mật khẩu"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"
                    >
                      <span className="material-symbols-outlined text-xl">{showPassword ? "visibility_off" : "visibility"}</span>
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-6 bg-[#3cdada] hover:bg-[#34c4c4] text-[#0b1320] font-bold py-3.5 rounded-xl shadow-lg shadow-cyan-900/30 transition-all flex items-center justify-center gap-2 group relative overflow-hidden"
                >
                  {loading ? (
                    <span className="animate-spin w-5 h-5 border-2 border-[#0b1320]/30 border-t-[#0b1320] rounded-full"></span>
                  ) : (
                    <>
                      ĐĂNG NHẬP <span className="material-symbols-outlined text-xl group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </>
                  )}
                </button>
              </form>

              <div className="mt-6 flex flex-col items-center gap-4">
                <button
                  onClick={() => setView("forgot")}
                  className="text-sm font-medium text-slate-400 hover:text-cyan-400 transition-colors"
                >
                  Quên mật khẩu?
                </button>
                <div className="text-sm text-slate-500">
                  Chưa có tài khoản? <button onClick={() => setView("register")} className="text-cyan-400 font-medium hover:underline">Đăng ký ngay</button>
                </div>
              </div>
            </div>
          )}

          {view === "register" && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex items-center mb-6">
                <button onClick={() => setView("login")} className="mr-3 text-slate-400 hover:text-white transition-colors">
                  <span className="material-symbols-outlined text-xl">arrow_back</span>
                </button>
                <div>
                  <h2 className="text-2xl font-bold text-white">Đăng ký tài khoản</h2>
                  <p className="text-slate-400 text-sm mt-1">Tham gia hệ thống VNTrust</p>
                </div>
              </div>

              <form onSubmit={handleAction} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Họ và tên</label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-purple-500 text-xl">person</span>
                    <input
                      required
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      className="w-full bg-[#131b2c] border border-slate-700/50 text-white rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all placeholder:text-slate-600"
                      placeholder="Nhập họ và tên"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Email</label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-blue-400 text-xl">mail</span>
                    <input
                      required
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className="w-full bg-[#131b2c] border border-slate-700/50 text-white rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all placeholder:text-slate-600"
                      placeholder="Địa chỉ email"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Số điện thoại</label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-green-500 text-xl">call</span>
                    <input
                      required
                      type="tel"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      className="w-full bg-[#131b2c] border border-slate-700/50 text-white rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all placeholder:text-slate-600"
                      placeholder="Số điện thoại"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Vai trò đăng ký</label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-cyan-400 text-xl">badge</span>
                    <select
                      required
                      value={regRole}
                      onChange={(e) => setRegRole(e.target.value)}
                      className="w-full bg-[#131b2c] border border-slate-700/50 text-white rounded-xl py-3 pl-12 pr-10 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all appearance-none cursor-pointer"
                    >
                      <option value="">Chọn vai trò của bạn</option>
                      <option value="manufacturer">Nhà sản xuất</option>
                      <option value="importer">Nhà nhập khẩu</option>
                      <option value="consumer">Người tiêu dùng</option>
                    </select>
                    <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none">arrow_drop_down</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Mật khẩu</label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-orange-400 text-xl">lock</span>
                    <input
                      required
                      type={showPassword ? "text" : "password"}
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full bg-[#131b2c] border border-slate-700/50 text-white rounded-xl py-3 pl-12 pr-12 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all placeholder:text-slate-600"
                      placeholder="Tạo mật khẩu"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"
                    >
                      <span className="material-symbols-outlined text-xl">{showPassword ? "visibility_off" : "visibility"}</span>
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-6 bg-[#3cdada] hover:bg-[#34c4c4] text-[#0b1320] font-bold py-3.5 rounded-xl shadow-lg shadow-cyan-900/30 transition-all flex items-center justify-center gap-2 group relative overflow-hidden"
                >
                  {loading ? (
                    <span className="animate-spin w-5 h-5 border-2 border-[#0b1320]/30 border-t-[#0b1320] rounded-full"></span>
                  ) : (
                    <>
                      ĐĂNG KÝ <span className="material-symbols-outlined text-xl group-hover:translate-x-1 transition-transform">person_add</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {view === "forgot" && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex items-center mb-6">
                <button onClick={() => setView("login")} className="mr-3 text-slate-400 hover:text-white transition-colors">
                  <span className="material-symbols-outlined text-xl">arrow_back</span>
                </button>
                <div>
                  <h2 className="text-2xl font-bold text-white">Quên mật khẩu</h2>
                  <p className="text-slate-400 text-sm mt-1">Khôi phục truy cập tài khoản</p>
                </div>
              </div>

              <form onSubmit={handleAction} className="space-y-5">
                <p className="text-sm text-slate-400 mb-2">
                  Vui lòng nhập địa chỉ email hoặc số điện thoại đã đăng ký. Chúng tôi sẽ gửi cho bạn hướng dẫn để đặt lại mật khẩu.
                </p>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Email hoặc Số điện thoại</label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-blue-400 text-xl">contact_mail</span>
                    <input
                      required
                      type="text"
                      className="w-full bg-[#131b2c] border border-slate-700/50 text-white rounded-xl py-3.5 pl-12 pr-4 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all placeholder:text-slate-600"
                      placeholder="Nhập email hoặc số điện thoại"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-6 bg-[#3cdada] hover:bg-[#34c4c4] text-[#0b1320] font-bold py-3.5 rounded-xl shadow-lg shadow-cyan-900/30 transition-all flex items-center justify-center gap-2 group relative overflow-hidden"
                >
                  {loading ? (
                    <span className="animate-spin w-5 h-5 border-2 border-[#0b1320]/30 border-t-[#0b1320] rounded-full"></span>
                  ) : (
                    <>
                      GỬI YÊU CẦU <span className="material-symbols-outlined text-xl group-hover:translate-x-1 transition-transform">send</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          )}
        </div>

        {/* Demo Accounts (Only show on login) */}
        {view === "login" && (
          <div className="mt-8 animate-in fade-in duration-700 delay-300">
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="h-px bg-slate-800 flex-1"></div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Tài khoản DEMO</span>
              <div className="h-px bg-slate-800 flex-1"></div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => handleDemoLogin("manufacturer", "nsx@vntrust.vn")} className="bg-[#1a2235]/60 hover:bg-[#1a2235] border border-slate-800/80 hover:border-cyan-500/30 p-4 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all group backdrop-blur-sm">
                <span className="material-symbols-outlined text-2xl text-rose-400 group-hover:scale-110 transition-transform">factory</span>
                <span className="text-sm font-semibold text-white">Nhà sản xuất</span>
              </button>
              <button onClick={() => handleDemoLogin("importer", "nhapkhau@vntrust.vn")} className="bg-[#1a2235]/60 hover:bg-[#1a2235] border border-slate-800/80 hover:border-cyan-500/30 p-4 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all group backdrop-blur-sm">
                <span className="material-symbols-outlined text-2xl text-blue-400 group-hover:scale-110 transition-transform">local_shipping</span>
                <span className="text-sm font-semibold text-white">Nhà nhập khẩu</span>
              </button>
              <button onClick={() => handleDemoLogin("consumer", "nguoitieudung@vntrust.vn")} className="bg-[#1a2235]/60 hover:bg-[#1a2235] border border-slate-800/80 hover:border-cyan-500/30 p-4 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all group backdrop-blur-sm">
                <span className="material-symbols-outlined text-2xl text-emerald-400 group-hover:scale-110 transition-transform">qr_code_scanner</span>
                <span className="text-sm font-semibold text-white">Người tiêu dùng</span>
              </button>
              <button onClick={() => handleDemoLogin("admin", "admin@vntrust.vn")} className="bg-[#1a2235]/60 hover:bg-[#1a2235] border border-slate-800/80 hover:border-cyan-500/30 p-4 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all group backdrop-blur-sm">
                <span className="material-symbols-outlined text-2xl text-amber-400 group-hover:scale-110 transition-transform">admin_panel_settings</span>
                <span className="text-sm font-semibold text-white">Quản trị hệ thống</span>
              </button>
            </div>
          </div>
        )}

        {/* Back to Home Link */}
        <div className="mt-8 text-center">
          <Link href="/" className="inline-flex items-center justify-center gap-1.5 text-sm font-medium text-slate-500 hover:text-white transition-colors">
            <span className="material-symbols-outlined text-[14px]">home</span>
            Quay lại Trang chủ
          </Link>
        </div>
      </div>
    </div>
  );
}

