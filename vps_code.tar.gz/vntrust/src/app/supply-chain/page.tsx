"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

// Mock data generators for realistic simulation
const LOCATION_HUBS = ["Hà Nội", "TP. Hồ Chí Minh", "Đà Nẵng", "Hải Phòng", "Cần Thơ", "Nha Trang", "Biên Hòa", "Huế"];
const PRODUCTS = ["Túi Xách Cao Cấp", "Đồng Hồ Cơ", "Rượu Vang Grand Cru", "Thiết Bị Y Tế", "Linh Kiện Bán Dẫn", "Mỹ Phẩm Thuần Chay"];
const ACTION_KEYS = ["sc_action_log1", "sc_action_log2", "sc_action_log3", "sc_action_log4"];

function generateId() {
  return "0x" + Math.random().toString(16).substr(2, 8);
}

export default function SupplyChainPage() {
  const [totalAuths, setTotalAuths] = useState(0);
  const [preventions, setPreventions] = useState(0);
  const [latency, setLatency] = useState(1.2);
  const [todayAuths, setTodayAuths] = useState(0);
  
  const [logs, setLogs] = useState([
    { id: "1", type: "success", titleKey: "sc_log_auth_done", titleSuffix: " - HK-9201", desc: "3,200 Túi Xách Cao Cấp | Chữ Ký RFID: 0x4f...e8", timeKey: "sc_log_just_now", timeSuffix: "" },
    { id: "2", type: "error",   titleKey: "sc_log_blocked",  titleSuffix: "", desc: "Vị trí: Ga Hà Nội | Nỗ Lực Quét Mã QR Trùng Lặp",  timeKey: "sc_log_mins_ago", timeSuffix: "1 " },
    { id: "3", type: "info",    titleKey: "sc_log_contract", titleSuffix: "", desc: "Kết Nối Nút Mạng Mới: TP.HCM Hub (SGN-04)",          timeKey: "sc_log_mins_ago", timeSuffix: "3 " },
  ]);

  const [liveNode, setLiveNode] = useState({ 
    loc: "Hà Nội", 
    lat: (21.0285 + (Math.random() - 0.5)).toFixed(4), 
    lng: (105.8048 + (Math.random() - 0.5)).toFixed(4) 
  });

  const [chartPoints, setChartPoints] = useState<number[]>([180, 180, 180, 180, 180, 180, 180, 180, 180, 180, 180]);
  const [chartPeriod, setChartPeriod] = useState<"1" | "7" | "30">("1");

  const [timeRange, setTimeRange] = useState("30");
  const { t } = useLanguage();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch(`/api/stats?days=${timeRange}&chartPeriod=${chartPeriod}`);
        const data = await res.json();
        setTotalAuths(data.totalAuths);
        setPreventions(data.preventions);
        setTodayAuths(data.todayAuths);
        if (data.chartData && data.chartData.length > 0) {
          const counts = data.chartData;
          const maxCount = Math.max(...counts, 5);
          const scaledPts = counts.map((c: number) => {
            const ratio = c / maxCount;
            return 180 - (ratio * 160);
          });
          setChartPoints(scaledPts);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchStats();
    
    const interval = setInterval(() => {
      fetchStats();
      setLatency((Math.random() * 1.5 + 0.5).toFixed(2) as unknown as number);
      
      // 2. Generate new log
      const isError = Math.random() > 0.9;
      const type = isError ? "error" : (Math.random() > 0.6 ? "info" : "success");
      const loc = LOCATION_HUBS[Math.floor(Math.random() * LOCATION_HUBS.length)];

      let titleKey = "";
      let titleSuffix = "";
      let desc = "";
      if (isError) {
        titleKey = "sc_log_fraud";
        desc = `sc_log_found_at:${loc}|sc_log_sig_viol:${generateId()}`;
      } else if (type === "success") {
        titleKey = "sc_log_auth_cert";
        titleSuffix = ` - ${generateId().substring(0, 8).toUpperCase()}`;
        desc = `${Math.floor(Math.random()*5000)} ${PRODUCTS[Math.floor(Math.random() * PRODUCTS.length)]}`;
      } else {
        titleKey = ACTION_KEYS[Math.floor(Math.random() * ACTION_KEYS.length)];
        desc = `sc_log_sync:${loc}`;
      }

      const newLog = { id: Date.now().toString(), type, titleKey, titleSuffix, desc, timeKey: "sc_log_just_now", timeSuffix: "" };
      
      setLogs(prev => {
        const newLogs = [newLog, ...prev].slice(0, 6);
        return newLogs.map((l, i) => ({
          ...l,
          timeKey: i === 0 ? "sc_log_just_now" : "sc_log_mins_ago",
          timeSuffix: i === 0 ? "" : `${i * 2} `,
        }));
      });

      // 3. Update map - Vietnam coordinates
      // Lat bound approx: 8.5 -> 23.3
      // Lng bound approx: 102.1 -> 109.4
      setLiveNode({
         loc,
         lat: ((Math.random() * (23.3 - 8.5)) + 8.5).toFixed(4),
         lng: ((Math.random() * (109.4 - 102.1)) + 102.1).toFixed(4),
      });

      // 4. Update Line Chart: chi random walk o che do real-time (Day)
      if (chartPeriod === "1") {
        setChartPoints(prev => {
          const newPts = [...prev.slice(1)];
          const newY = Math.max(20, Math.min(180, prev[prev.length - 1] + (Math.random() * 80 - 40)));
          newPts.push(newY);
          return newPts;
        });
      }

    }, 2800); // Trigger every 2.8s

    return () => clearInterval(interval);
  }, [timeRange, chartPeriod]);

  const generatePath = (pts: number[]) => {
    let d = `M-50 ${pts[0]} Q 0 ${(pts[0]+pts[1])/2}, 50 ${pts[1]}`;
    for (let i = 2; i < pts.length; i++) {
      d += ` T ${i * 100 - 50} ${pts[i]}`;
    }
    return d;
  };
  const linePath = generatePath(chartPoints);

  const safeScoreNum = totalAuths > 0 ? (((totalAuths - preventions) / totalAuths) * 100) : 100;
  const safeScoreDisplay = safeScoreNum >= 99.9 && safeScoreNum < 100 ? 99.9 : parseFloat(safeScoreNum.toFixed(1));
  const dashOffset = 502 - (502 * safeScoreDisplay / 100);

  return (
    <div className="flex transparent font-body ">
      
      

      
      <main className="mx-auto max-w-7xl w-full flex-1 p-8 lg:p-12 overflow-x-hidden min-h-[calc(100vh-80px)] transparent">
        <header className="flex justify-between items-center mb-10 pb-4 border-b border-outline-variant/10">
          <div>
            <nav className="flex items-center gap-2 text-xs font-medium text-secondary mb-1 uppercase tracking-widest">
              <span>{t("sc_board")}</span>
              <span className="material-symbols-outlined text-[10px]">chevron_right</span>
              <span className="text-primary font-bold">{t("sc_analytics")}</span>
            </nav>
            <h1 className="text-3xl lg:text-4xl font-extrabold font-headline tracking-tighter text-white">{t("sc_title")}</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden lg:flex items-center bg-white/5 glass-panel text-white rounded-full border border-outline-variant/30 shadow-sm relative overflow-hidden">
              <span className="material-symbols-outlined text-outline text-sm absolute left-4 z-10 pointer-events-none">calendar_today</span>
              <select 
                className="bg-transparent text-sm font-medium text-slate-200 focus:outline-none appearance-none pr-10 pl-10 py-1.5 cursor-pointer w-full relative z-20" 
                value={timeRange}
                onChange={(e) => {
                  setTimeRange(e.target.value);
                  setChartPeriod("1");
                }}
              >
                <option value="7">{t("sc_7d")}</option>
                <option value="30">{t("sc_30d")}</option>
                <option value="90">{t("sc_90d")}</option>
              </select>
              <span className="material-symbols-outlined text-outline text-sm absolute right-3 z-10 pointer-events-none">expand_more</span>
            </div>
          </div>
        </header>

        <div className="space-y-8">
          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white/5 glass-panel text-white p-6 rounded-2xl shadow-sm border-l-4 border-primary relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 w-24 h-24 bg-primary/5 rounded-full scale-150 transition-transform group-hover:scale-175"></div>
              <p className="text-sm font-bold text-secondary uppercase tracking-tighter mb-2">{t("sc_total_auth")}</p>
              <div className="flex items-end gap-3">
                <h3 className="text-4xl font-extrabold font-headline text-white">{totalAuths.toLocaleString('en-US')}</h3>
                <span className="text-emerald-700 text-xs font-bold mb-1.5 flex items-center bg-emerald-50 px-2 py-0.5 rounded-full animate-pulse transition-all">
                  <span className="material-symbols-outlined text-xs">trending_up</span> 12.4%
                </span>
              </div>
              <p className="text-[11px] text-outline mt-4 font-mono transition-opacity">HASH: {generateId()}...{generateId().substring(0,4)}</p>
            </div>
            
            <div className="bg-white/5 glass-panel text-white p-6 rounded-2xl shadow-sm border-l-4 border-error relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 w-24 h-24 bg-error/5 rounded-full scale-150 transition-transform group-hover:scale-175"></div>
              <p className="text-sm font-bold text-secondary uppercase tracking-tighter mb-2">{t("sc_fake_prev")}</p>
              <div className="flex items-end gap-3">
                <h3 className="text-4xl font-extrabold font-headline text-white">{preventions.toLocaleString('en-US')}</h3>
                <span className="text-error text-xs font-bold mb-1.5 flex items-center bg-error-container px-2 py-0.5 rounded-full">
                  <span className="material-symbols-outlined text-xs">security</span> {t("sc_active_badge")}
                </span>
              </div>
              <p className="text-[11px] text-outline mt-4">{t("sc_ai_detect")}</p>
            </div>
            
            <div className="bg-white/5 glass-panel text-white p-6 rounded-2xl shadow-sm border-l-4 border-tertiary-container relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 w-24 h-24 bg-tertiary-container/5 rounded-full scale-150 transition-transform group-hover:scale-175"></div>
              <p className="text-sm font-bold text-secondary uppercase tracking-tighter mb-2">{t("sc_efficiency")}</p>
              <div className="flex items-end gap-3">
                <h3 className="text-4xl font-extrabold font-headline text-white">98.2<span className="text-2xl">%</span></h3>
                <span className="text-emerald-700 text-xs font-bold mb-1.5 flex items-center bg-emerald-50 px-2 py-0.5 rounded-full">
                  {t("sc_optimal")}
                </span>
              </div>
              <p className="text-[11px] text-outline mt-4">{t("sc_latency")} {latency}ms (Live)</p>
            </div>
          </section>

          <section className="grid grid-cols-12 gap-6">
            {/* Line Chart */}
            <div className="col-span-12 lg:col-span-8 bg-white/5 glass-panel text-white p-8 rounded-2xl shadow-sm border border-outline-variant/10 transition-all overflow-hidden">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                <div>
                  <h4 className="text-xl font-bold font-headline text-white flex items-center gap-2">{t("sc_auth_speed")} <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span></h4>
                  <p className="text-sm text-secondary">{t("sc_live_traffic")}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setChartPeriod("1")} className={`cursor-pointer z-20 relative ${chartPeriod === "1" ? "transparent-container text-primary" : "hover:transparent-container text-secondary"} px-4 py-2 rounded-lg text-xs font-bold transition-colors`}>{t("sc_day")}</button>
                  {timeRange !== "7" && (
                    <button onClick={() => setChartPeriod("7")} className={`cursor-pointer z-20 relative ${chartPeriod === "7" ? "transparent-container text-primary" : "hover:transparent-container text-secondary"} px-4 py-2 rounded-lg text-xs font-bold transition-colors`}>{t("sc_week")}</button>
                  )}
                  {timeRange === "90" && (
                    <button onClick={() => setChartPeriod("30")} className={`cursor-pointer z-20 relative ${chartPeriod === "30" ? "transparent-container text-primary" : "hover:transparent-container text-secondary"} px-4 py-2 rounded-lg text-xs font-bold transition-colors`}>{t("sc_month")}</button>
                  )}
                </div>
              </div>
              <div className="h-64 relative border-b border-outline-variant/20 flex flex-col justify-between py-2 overflow-hidden">
                <div className="border-t border-outline-variant/10 w-full"></div>
                <div className="border-t border-outline-variant/10 w-full"></div>
                <div className="border-t border-outline-variant/10 w-full"></div>
                <div className="border-t border-outline-variant/10 w-full"></div>
                
                <div className="absolute inset-0">
                  <svg className="w-full h-full" preserveAspectRatio="none" viewBox="-50 0 850 200">
                    <path d={linePath} fill="none" stroke="#004c4c" strokeLinecap="round" strokeWidth="4" className="path-anim transition-all duration-[2800ms] ease-linear"></path>
                    <path d={`${linePath} V 200 H -50 Z`} fill="url(#grad1)" opacity="0.1" className="path-fade transition-all duration-[2800ms] ease-linear"></path>
                    <defs>
                      <linearGradient id="grad1" x1="0%" x2="0%" y1="0%" y2="100%">
                        <stop offset="0%" style={{ stopColor: "#004c4c", stopOpacity: 1 }}></stop>
                        <stop offset="100%" style={{ stopColor: "#004c4c", stopOpacity: 0 }}></stop>
                      </linearGradient>
                    </defs>
                    <circle cx="750" cy="30" fill="#004c4c" r="6" stroke="white" strokeWidth="2"></circle>
                  </svg>
                  <div className="absolute top-4 right-10 bg-slate-800 text-white p-3 rounded-lg text-xs font-bold shadow-xl">
                    {t("sc_today")} {todayAuths.toLocaleString('en-US')} {t("sc_unit_scans")}
                  </div>
                </div>
              </div>
            </div>

            <div className="col-span-12 lg:col-span-4 bg-white/5 glass-panel text-white p-8 rounded-2xl shadow-sm border border-outline-variant/10 flex flex-col">
              <h4 className="text-xl font-bold font-headline text-white mb-1">{t("sc_trust_dist")}</h4>
              <p className="text-sm text-secondary mb-8">{t("sc_safety_status")}</p>
              
              <div className="relative w-48 h-48 mx-auto mb-8">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="96" cy="96" fill="transparent" r="80" stroke="#f3f4f5" strokeWidth="24"></circle>
                  <circle cx="96" cy="96" fill="transparent" r="80" stroke="#004c4c" strokeDasharray="502" strokeDashoffset="100" strokeWidth="24"></circle>
                  <circle cx="96" cy="96" fill="transparent" r="80" stroke="#006a23" strokeDasharray="502" strokeDashoffset={dashOffset} strokeWidth="24" className="transition-all duration-1000 ease-out"></circle>
                  <circle cx="96" cy="96" fill="transparent" r="80" stroke="#ba1a1a" strokeDasharray="502" strokeDashoffset="480" strokeWidth="24"></circle>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-extrabold text-white">{safeScoreDisplay}%</span>
                  <span className="text-[10px] font-bold text-secondary uppercase tracking-tighter">{t("sc_safe_score")}</span>
                </div>
              </div>
            </div>

            {/* Global Map */}
            <div className="col-span-12 lg:col-span-7 bg-white/5 glass-panel text-white p-8 rounded-2xl shadow-sm border border-outline-variant/10 min-h-[400px]">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h4 className="text-xl font-bold font-headline text-white">{t("sc_scan_activity")}</h4>
                  <p className="text-sm text-secondary">{t("sc_geo_dist")}</p>
                </div>
                <div className="p-2 transparent-container rounded-lg">
                  <span className="material-symbols-outlined text-primary">public</span>
                </div>
              </div>
              <div className="relative w-full h-[300px] bg-white/10 rounded-xl overflow-hidden group">
                <div className="absolute inset-0 opacity-60 grayscale group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700">
                  <img className="w-full h-full object-cover mix-blend-multiply" alt="abstract map" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAC94FOhZv7D2N9SKs9kG7MiEINLJBwY_-TP5A_CAwEesciolMMUrQr3vpTSwBGQSnv3abduQWr4e-4_gUbwuq5YnNR10YnKNaYqA9_SIciYwlXSsHb49VhvzbkCSPW0ab7JgytJF2ML_2WuH2CXRA8Kk2vgDDnGhScEeUwBhFKYYHWsW28cNXV72JSBKgVXpxPbKd9vHky6m2BbmFwa1aTkRmLp4aEeRHKMc420uR4JxIqxRKW4fhFizYooDxDzc8EmeBTa1fEQQSD"/>
                </div>
                {/* Dynamically placed Heatmap point */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-emerald-500/30 rounded-full blur-2xl animate-ping opacity-50"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-primary/80 rounded-full blur-md"></div>
                
                <div className="absolute bottom-4 left-4 bg-slate-900/90 text-white p-4 rounded-xl backdrop-blur-md border border-white/10 shadow-xl transition-all duration-500">
                  <p className="text-[10px] font-bold text-primary-fixed uppercase tracking-widest mb-1">{t("sc_live_data")}</p>
                  <p className="text-xs font-medium">{t("sc_new_scan")} {liveNode.loc}</p>
                  <p className="text-[10px] font-mono text-outline-variant mt-1 text-slate-400">LAT: {liveNode.lat} / LONG: {liveNode.lng}</p>
                </div>
              </div>
            </div>

            {/* Live Feed Event Log */}
            <div className="col-span-12 lg:col-span-5 bg-white/5 glass-panel text-white p-8 rounded-2xl shadow-sm border border-outline-variant/10 flex flex-col relative overflow-hidden">
               <div className="absolute top-0 right-0 w-full h-12 bg-gradient-to-b from-white to-transparent pointer-events-none z-10"></div>
              <h4 className="text-xl font-bold font-headline text-white mb-1 flex items-center justify-between">
                {t("sc_latest_ledger")}
                <span className="text-[10px] bg-red-100 text-red-600 px-2 py-1 rounded font-black tracking-widest uppercase flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></span> {t("sc_live")}</span>
              </h4>
              <p className="text-sm text-secondary mb-6">{t("sc_realtime_block")}</p>
              
              <div className="space-y-6 flex-1 pr-2 relative mt-2">
                 {logs.map((log) => {
                   const logTitle = t((log as any).titleKey) + ((log as any).titleSuffix || "");
                   const logTime = (log as any).timeSuffix + t((log as any).timeKey);
                   const rawDesc = (log as any).desc || "";
                   const logDesc = rawDesc.startsWith("sc_log_sync:") ? `${t("sc_log_sync")} ${rawDesc.split(":")[1]}` :
                     rawDesc.startsWith("sc_log_found_at:") ? (() => { const parts = rawDesc.split("|"); const loc = parts[0].replace("sc_log_found_at:",""); const sig = parts[1]?.replace("sc_log_sig_viol:",""); return `${t("sc_log_found_at")} ${loc} | ${t("sc_log_sig_viol")} ${sig}`; })() : rawDesc;
                   return (
                   <div key={log.id} className="flex gap-4 group animate-[slideIn_0.3s_ease-out]">
                     <div className="flex flex-col items-center">
                       <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                         log.type === 'success' ? 'bg-emerald-50 border border-emerald-200' : 
                         log.type === 'error' ? 'bg-red-50 ring-4 ring-red-50 border border-red-200' :
                         'bg-white/10 border border-slate-300'
                       }`}>
                         <span className={`material-symbols-outlined text-sm ${
                           log.type === 'success' ? 'text-emerald-700' :
                           log.type === 'error' ? 'text-red-600' : 'text-slate-300'
                         }`}>
                           {log.type === 'success' ? 'check_circle' : log.type === 'error' ? 'warning' : 'link'}
                         </span>
                       </div>
                       <div className="w-px h-full bg-slate-200 -mt-1"></div>
                     </div>
                     <div className="pb-6 w-full relative">
                       <p className={`text-sm font-bold truncate ${log.type === 'error' ? 'text-red-600' : 'text-white'}`}>{logTitle}</p>
                       <p className="text-xs text-secondary mb-2 truncate max-w-[200px] sm:max-w-xs">{logDesc}</p>
                       <span className={`text-[10px] font-bold px-2 py-1 rounded ${
                         log.type === 'error' ? 'bg-red-100 text-red-700' : 'bg-white/10 text-primary'  
                       }`}>{logTime}</span>
                     </div>
                   </div>
                   );
                 })}
                 <div className="absolute bottom-0 w-full h-16 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>
              </div>
              
              <button onClick={() => alert(t("sc_full_network"))} className="w-full mt-6 py-3 text-xs font-bold text-primary uppercase tracking-widest hover:bg-teal-50 hover:text-emerald-700 transition-colors rounded-lg border border-primary/20 bg-white/5 glass-panel text-white shadow-sm mt-auto z-10 custom-blockchain-btn">
                {t("sc_full_network")}
              </button>
            </div>
          </section>
        </div>

        {/* Bottom Floating Action State */}
        <div className="fixed bottom-8 right-8 z-50">
          <button className="flex items-center gap-3 bg-slate-900 text-white pl-4 pr-6 py-3 rounded-full shadow-2xl hover:scale-105 transition-transform group border border-slate-700">
            <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center relative overflow-hidden">
              <span className="material-symbols-outlined text-white text-sm relative z-10" style={{ fontVariationSettings: "'FILL' 1" }}>bolt</span>
              <div className="absolute inset-0 bg-white/5 glass-panel text-white/20 animate-pulse"></div>
            </div>
            <div className="text-left">
              <p className="text-[10px] font-bold uppercase tracking-tighter text-emerald-400">{t("sc_ai_running")}</p>
              <p className="text-xs font-medium text-slate-300 transition-all">{t("sc_scanning")} {(1.5 + Math.random()).toFixed(1)}k {t("sc_data_per_sec")}</p>
            </div>
          </button>
        </div>
        <style dangerouslySetInnerHTML={{__html: `
          @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-[slideIn_0.3s_ease-out] {
            animation: slideIn 0.3s ease-out;
          }
          .path-anim {
             animation: dash 10s linear infinite;
             stroke-dasharray: 20, 10;
          }
          @keyframes dash {
            to { stroke-dashoffset: -300; }
          }
        `}} />
      </main>
    </div>
  );
}
