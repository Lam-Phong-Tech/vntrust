import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  // Lấy IP từ header proxy (Vercel, Nginx...) hoặc remote address
  const forwarded = req.headers.get("x-forwarded-for");
  const realIp    = req.headers.get("x-real-ip");
  const cfIp      = req.headers.get("cf-connecting-ip"); // Cloudflare

  const ip = (forwarded?.split(",")[0].trim()) || cfIp || realIp || "127.0.0.1";

  return NextResponse.json({ ip });
}
