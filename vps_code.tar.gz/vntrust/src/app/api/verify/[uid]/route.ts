import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest, { params }: { params: Promise<{ uid: string }> }) {
  const resolvedParams = await params;
  const uid = resolvedParams.uid;

  try {
    let maDinhDanh = await prisma.maDinhDanh.findUnique({
      where: { uid },
      include: {
        loHang: {
          include: { sanPham: { include: { doanhNghiep: true, chungNhans: true } } }
        }
      }
    });

    if (!maDinhDanh) {
      maDinhDanh = await prisma.maDinhDanh.findUnique({
        where: { serialNumber: uid },
        include: {
          loHang: {
            include: { sanPham: { include: { doanhNghiep: true, chungNhans: true } } }
          }
        }
      });
    }

    if (!maDinhDanh) {
      await prisma.canhBao.create({
        data: {
          loai: "FAKE_QR_SCANNED",
          mucDo: "high",
          moTa: `Phát hiện quét mã QR không hợp lệ hoặc giả mạo: ${uid}`,
          uid: uid,
        }
      });
      return NextResponse.json({ status: "fake", message: "Mã không tồn tại trên hệ thống VNTrust. Đây có thể là hàng giả." });
    }

    if (maDinhDanh.trangThai === "fake") {
      return NextResponse.json({ status: "fake", message: "Mã này đã bị gắn cờ là hàng giả." });
    }

    const isExpired = new Date(maDinhDanh.loHang.hanDung) < new Date();
    const ip = req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || "unknown";

    let currentStatus: string;
    if (isExpired) {
      currentStatus = "expired";
    } else if (maDinhDanh.soLanQuet >= 5) {
      currentStatus = "suspect";
    } else {
      currentStatus = "genuine";
    }

    // Ghi log lượt quét
    await prisma.luotQuet.create({
      data: {
        uid: maDinhDanh.uid,
        diaChi_IP: ip,
        ketQua: currentStatus,
      }
    });

    // Tăng số lần quét
    const updatedMa = await prisma.maDinhDanh.update({
      where: { uid: maDinhDanh.uid },
      data: { soLanQuet: { increment: 1 } }
    });

    // Tạo cảnh báo nếu bị quét quá nhiều
    if (updatedMa.soLanQuet >= 5 && currentStatus === "genuine") {
      currentStatus = "suspect";
      await prisma.canhBao.create({
        data: {
          loai: "SCAN_ANOMALY",
          mucDo: "high",
          moTa: `Mã ${uid} đã bị quét ${updatedMa.soLanQuet} lần — có thể đang bị làm giả.`,
          uid: updatedMa.uid,
        }
      });
    }

    return NextResponse.json({
      status: currentStatus,
      data: { ...maDinhDanh, soLanQuet: updatedMa.soLanQuet },
      scanCount: updatedMa.soLanQuet
    });
  } catch (error: any) {
    console.error("Verification Error:", error);
    return NextResponse.json({ status: "fake", message: "Lỗi hệ thống xác thực. Vui lòng thử lại." }, { status: 500 });
  }
}
