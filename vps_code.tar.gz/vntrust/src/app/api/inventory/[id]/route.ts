import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { cookies } from "next/headers";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const cookieStore = await cookies();
    const userRole = cookieStore.get('userRole')?.value;
    const userDoanhNghiepId = cookieStore.get('doanhNghiepId')?.value;

    if (!userRole) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const loHang = await prisma.loHang.findUnique({
      where: { id },
      include: {
        sanPham: { include: { doanhNghiep: true } },
        uids: {
          orderBy: { ngayTao: "asc" },
          select: { uid: true, trangThai: true, soLanQuet: true, ngayTao: true }
        }
      }
    });

    if (!loHang) {
      return NextResponse.json({ error: "Không tìm thấy lô hàng" }, { status: 404 });
    }

    // RBAC: If not admin, the user's doanhNghiepId must match the product's doanhNghiepId
    if (userRole !== 'admin' && loHang.sanPham.doanhNghiepId !== userDoanhNghiepId) {
      return NextResponse.json({ error: "Forbidden: Bạn không có quyền truy cập dữ liệu của doanh nghiệp khác" }, { status: 403 });
    }

    return NextResponse.json(loHang);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
