import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { username, password } = body;
    const ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || '127.0.0.1';

    let foundRole = "";
    let foundUsername = "";
    let doanhNghiepId = "";

    // Check hardcoded demo accounts
    if (username === "nsx@vntrust.vn" && password === "123456") { foundRole = "manufacturer"; foundUsername = "Nhà sản xuất (Demo)"; }
    else if (username === "nhapkhau@vntrust.vn" && password === "123456") { foundRole = "importer"; foundUsername = "Nhà nhập khẩu (Demo)"; }
    else if (username === "nguoitieudung@vntrust.vn" && password === "123456") { foundRole = "consumer"; foundUsername = "Người tiêu dùng (Demo)"; }
    else if (username === "admin@vntrust.vn" && password === "123456") { foundRole = "admin"; foundUsername = "Admin"; }
    else {
      // Find in DB
      const user = await prisma.nguoiDung.findFirst({
        where: {
          OR: [{ email: username }, { soDienThoai: username }],
          matKhau: password
        }
      });

      if (user) {
        foundRole = user.vaiTro;
        doanhNghiepId = user.doanhNghiepId || "";
        foundUsername = user.ten || user.email;
      }
    }

    if (foundRole) {
      // Record login to DB
      try {
        await prisma.nhatKy.create({
          data: {
            action: "Đăng nhập hệ thống thành công",
            user: foundUsername,
            role: foundRole,
            ip,
            status: "success",
          }
        });
      } catch (e) {
        console.error("Log error:", e);
      }

      const response = NextResponse.json({
        message: 'Đăng nhập thành công',
        role: foundRole,
        username: foundUsername,
      });
      response.cookies.set('userRole', foundRole, { path: '/', maxAge: 86400 });
      response.cookies.set('userName', foundUsername, { path: '/', maxAge: 86400 });
      if (doanhNghiepId) {
        response.cookies.set('doanhNghiepId', doanhNghiepId, { path: '/', maxAge: 86400 });
      }
      return response;
    }

    // Record failed login
    try {
      await prisma.nhatKy.create({
        data: {
          action: `Đăng nhập thất bại: ${username}`,
          user: username,
          role: "unknown",
          ip,
          status: "error",
        }
      });
    } catch {}

    return NextResponse.json(
      { error: 'Sai tên đăng nhập hoặc mật khẩu!' },
      { status: 401 }
    );
  } catch (error: any) {
    console.error("Login Error:", error);
    return NextResponse.json({ error: 'Đã xảy ra lỗi hệ thống' }, { status: 500 });
  }
}
