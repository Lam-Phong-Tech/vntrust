import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, email, phone, role, password } = body;

    // Check if user exists
    const existingUser = await prisma.nguoiDung.findUnique({
      where: { email },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'Email này đã được đăng ký!' },
        { status: 400 }
      );
    }

    if (role === 'admin') {
      return NextResponse.json(
        { error: 'Không thể đăng ký tài khoản Quản trị hệ thống!' },
        { status: 403 }
      );
    }

    // Hash password (for demo, storing plain text as we don't have bcrypt installed, 
    // but in real app we'd hash it)
    const newUser = await prisma.nguoiDung.create({
      data: {
        ten: name,
        email: email,
        soDienThoai: phone,
        vaiTro: role,
        matKhau: password, // In production: bcrypt.hashSync(password, 10)
      },
    });

    return NextResponse.json({
      message: 'Đăng ký thành công',
      user: { id: newUser.id, email: newUser.email, role: newUser.vaiTro },
    });
  } catch (error: any) {
    console.error("Register Error:", error);
    return NextResponse.json({ error: 'Đã xảy ra lỗi hệ thống' }, { status: 500 });
  }
}
