import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const days = searchParams.get("days") || "30";
    const chartPeriod = searchParams.get("chartPeriod") || "1";
    const dateLimit = new Date();
    dateLimit.setDate(dateLimit.getDate() - parseInt(days));

    const realTotalAuths = await prisma.luotQuet.count({ where: { thoiGian: { gte: dateLimit } } });
    const realPreventions = await prisma.canhBao.count({ where: { thoiGian: { gte: dateLimit } } });
    
    const todayStart = new Date();
    todayStart.setHours(0,0,0,0);
    const realTodayAuths = await prisma.luotQuet.count({
      where: {
        thoiGian: { gte: todayStart }
      }
    });

    let chartData = Array(11).fill(0);
    if (chartPeriod === "1") {
      const start = new Date();
      start.setHours(start.getHours() - 11);
      const scans = await prisma.luotQuet.findMany({ where: { thoiGian: { gte: start } }, select: { thoiGian: true } });
      scans.forEach((s) => {
        const diffHours = Math.floor((new Date().getTime() - s.thoiGian.getTime()) / (1000 * 60 * 60));
        if (diffHours >= 0 && diffHours < 11) {
          chartData[10 - diffHours]++;
        }
      });
    } else {
      const numDays = parseInt(chartPeriod);
      const start = new Date();
      start.setDate(start.getDate() - 10 * Math.ceil(numDays / 11));
      const scans = await prisma.luotQuet.findMany({ where: { thoiGian: { gte: start } }, select: { thoiGian: true } });
      const groupDays = Math.max(1, Math.floor(numDays / 11));
      scans.forEach((s) => {
        const diffDays = Math.floor((new Date().getTime() - s.thoiGian.getTime()) / (1000 * 60 * 60 * 24));
        const index = 10 - Math.floor(diffDays / groupDays);
        if (index >= 0 && index < 11) {
          chartData[index]++;
        }
      });
    }

    return NextResponse.json({ 
      totalAuths: realTotalAuths, 
      preventions: realPreventions, 
      todayAuths: realTodayAuths,
      chartData
    });
  } catch (error) {
    return NextResponse.json({ totalAuths: 0, preventions: 0, todayAuths: 0 }); 
  }
}
