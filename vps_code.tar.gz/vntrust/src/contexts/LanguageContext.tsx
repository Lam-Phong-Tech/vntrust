"use client";
import { createContext, useContext, useState, useEffect, ReactNode } from "react";

// ─── Translation Dictionary ───────────────────────────────────────────────────
const dict: Record<string, Record<string, string>> = {
  // ── Nav ──
  nav_verify:        { vi: "Xác thực",         en: "Verify",       zh: "认证",       ja: "認証",    ko: "인증",    fr: "Vérifier" },
  nav_supply:        { vi: "Chuỗi cung ứng",   en: "Supply Chain", zh: "供应链",     ja: "サプライチェーン", ko: "공급망", fr: "Chaîne d'approvisionnement" },
  nav_dashboard:     { vi: "Bảng điều khiển",  en: "Dashboard",    zh: "控制台",     ja: "ダッシュボード",   ko: "대시보드", fr: "Tableau de bord" },
  nav_enterprise:    { vi: "Doanh nghiệp",     en: "Enterprise",   zh: "企业",       ja: "エンタープライズ", ko: "기업",     fr: "Entreprise" },
  nav_login:         { vi: "Đăng nhập",        en: "Login",        zh: "登录",       ja: "ログイン", ko: "로그인",   fr: "Connexion" },
  // ── Search ──
  search_title:      { vi: "TÌM KIẾM SẢN PHẨM BẰNG SỐ SERIAL?", en: "SEARCH PRODUCTS BY SERIAL?", zh: "通过序列号搜索产品?", ja: "シリアル番号で商品を検索?", ko: "시리얼 번호로 제품 검색?", fr: "RECHERCHER PAR NUMÉRO DE SÉRIE?" },
  search_sub:        { vi: "Trợ lý AI VNTrust...", en: "VNTrust AI Assistant...", zh: "VNTrust AI助手...", ja: "VNTrust AIアシスタント...", ko: "VNTrust AI 어시스턴트...", fr: "Assistant IA VNTrust..." },
  search_ph:         { vi: "Nhập số serial để xác thực...", en: "Enter serial number to verify...", zh: "输入序列号进行验证...", ja: "シリアル番号を入力...", ko: "시리얼 번호 입력...", fr: "Entrez le numéro de série..." },
  // ── App Cards ──
  app_inv:           { vi: "Tài sản & Lô hàng",    en: "Assets & Batches",      zh: "资产和批次",    ja: "資産とバッチ",   ko: "자산 및 배치",       fr: "Actifs & Lots" },
  app_inv_sub:       { vi: "Quản lý Kho hàng",     en: "Inventory Management",  zh: "库存管理",      ja: "在庫管理",       ko: "재고 관리",          fr: "Gestion des stocks" },
  app_sc:            { vi: "Chuỗi Cung ứng",       en: "Supply Chain",          zh: "供应链",        ja: "サプライチェーン",ko: "공급망",             fr: "Chaîne d'approvisionnement" },
  app_sc_sub:        { vi: "Bản đồ Phân phối",     en: "Distribution Map",      zh: "分发地图",      ja: "配送マップ",     ko: "배포 지도",          fr: "Carte de distribution" },
  app_verify:        { vi: "Quét QR Ngay",         en: "Scan QR Now",           zh: "立即扫描QR",    ja: "QRをスキャン",   ko: "QR 스캔",            fr: "Scanner QR" },
  app_verify_sub:    { vi: "Xác thực Nhanh",       en: "Quick Verify",          zh: "快速验证",      ja: "クイック認証",   ko: "빠른 인증",          fr: "Vérification rapide" },
  app_hk:            { vi: "Hậu kiểm & Thu hồi",  en: "Post-Audit & Recall",   zh: "事后审计和召回", ja: "事後監査と回収",  ko: "사후 감사 및 회수",  fr: "Audit & Rappel" },
  app_hist:          { vi: "Nhật ký Hệ thống",    en: "System History",        zh: "系统历史",      ja: "システム履歴",   ko: "시스템 기록",        fr: "Historique système" },
  app_emg:           { vi: "Trung tâm Sự cố",     en: "Incident Center",       zh: "事故中心",      ja: "インシデントセンター", ko: "사고 센터",      fr: "Centre d'incidents" },
  // ── Security ──
  sec_title:         { vi: "BẢO MẬT & HỖ TRỢ",    en: "SECURITY & SUPPORT",   zh: "安全与支持",   ja: "セキュリティとサポート", ko: "보안 및 지원", fr: "SÉCURITÉ & SUPPORT" },
  sec_team:          { vi: "ĐỘI NGŨ CHUYÊN GIA BẢO MẬT", en: "SECURITY EXPERT TEAM", zh: "安全专家团队", ja: "セキュリティ専門家チーム", ko: "보안 전문가 팀", fr: "ÉQUIPE D'EXPERTS SÉCURITÉ" },
  sec_team_sub:      { vi: "Hỗ trợ chống giả chuyên sâu", en: "In-depth anti-counterfeit support", zh: "深度防伪支持", ja: "詳細な偽造防止サポート", ko: "심층 위조 방지 지원", fr: "Support anti-contrefaçon approfondi" },
  sec_hotline:       { vi: "ĐƯỜNG DÂY NÓNG 24/7",  en: "HOTLINE 24/7",         zh: "24/7热线",     ja: "24/7ホットライン", ko: "24/7 핫라인",  fr: "LIGNE D'ASSISTANCE 24/7" },
  sec_hotline_sub:   { vi: "Xử lý ngay lập tức: HCM, HN...", en: "Immediate support: HCM, HN...", zh: "立即处理：胡志明市，河内...", ja: "即時対応：HCM、HN...", ko: "즉각 처리: HCM, HN...", fr: "Traitement immédiat：HCM, HN..." },
  // ── AI button ──
  ai_btn:            { vi: "TRỢ LÝ AI",            en: "AI ASSISTANT",         zh: "AI助手",       ja: "AIアシスタント",  ko: "AI 어시스턴트",      fr: "ASSISTANT IA" },
  recent:            { vi: "Hoạt động Gần đây",    en: "Recent Activity",      zh: "最近活动",     ja: "最近のアクティビティ", ko: "최근 활동",      fr: "Activité récente" },
  map_title:         { vi: "BẢN ĐỒ VIỆT NAM",     en: "VIETNAM MAP",           zh: "越南地图",     ja: "ベトナム地図",      ko: "베트남 지도",         fr: "CARTE VIETNAM" },
  // ── Verify Page ──
  verify_badge:      { vi: "Cổng Xác thực Trung tâm (Zero-Trust)", en: "Central Authentication Gateway (Zero-Trust)", zh: "中央认证网关", ja: "中央認証ゲートウェイ", ko: "중앙 인증 게이트웨이", fr: "Passerelle d'authentification centrale" },
  verify_title:      { vi: "Mạng lưới đối soát", en: "Verification Network", zh: "核查网络", ja: "検証ネットワーク", ko: "검증 네트워크", fr: "Réseau de vérification" },
  verify_sub:        { vi: "Chọn phương thức phù hợp để bắt đầu quy trình kiểm định. Mọi dữ liệu đều được ánh xạ lên Sổ cái Bất biến Blockchain VNTrust.", en: "Choose the appropriate method to begin the verification process. All data is mapped to the VNTrust Immutable Blockchain Ledger.", zh: "选择合适的方式开始验证流程。所有数据均映射到VNTrust不可变区块链账本。", ja: "検証プロセスを開始する適切な方法を選択してください。", ko: "검증 프로세스를 시작하기 위해 적절한 방법을 선택하세요.", fr: "Choisissez la méthode appropriée pour commencer le processus de vérification." },
  verify_new:        { vi: "MỚI", en: "NEW", zh: "新功能", ja: "新機能", ko: "신규", fr: "NOUVEAU" },
  verify_card1_title:{ vi: "Quét Mã Bảo Mật", en: "Scan Security Code", zh: "扫描安全码", ja: "セキュリティコードをスキャン", ko: "보안 코드 스캔", fr: "Scanner le code de sécurité" },
  verify_card1_desc: { vi: "Sử dụng Camera thiết bị để quét Tem Chống Giả (QR / Mã Vạch 1D) chuẩn xác nhất.", en: "Use your device camera to scan Anti-Counterfeit Stamps (QR / 1D Barcode) with the highest accuracy.", zh: "使用设备摄像头扫描防伪贴标（QR码/一维条形码），准确率最高。", ja: "デバイスカメラで偽造防止スタンプをスキャンします。", ko: "기기 카메라를 사용하여 위조 방지 스탬프를 스캔하세요.", fr: "Utilisez la caméra de votre appareil pour scanner les tampons anti-contrefaçon." },
  verify_card1_cta:  { vi: "Bắt đầu Quét", en: "Start Scanning", zh: "开始扫描", ja: "スキャン開始", ko: "스캔 시작", fr: "Commencer le scan" },
  verify_card2_title:{ vi: "Nhập Mã Serial", en: "Enter Serial Code", zh: "输入序列号", ja: "シリアルコードを入力", ko: "시리얼 코드 입력", fr: "Saisir le code série" },
  verify_card2_desc: { vi: "Tra cứu chéo bằng cách nhập mã ký tự (UID) in dọc tem thẻ cào hoặc mã in trên nhãn.", en: "Cross-check by entering the character code (UID) printed on the scratch card or label.", zh: "通过输入刮刮卡或标签上印制的字符码进行交叉核验。", ja: "スクラッチカードに印刷された文字コードを入力してクロスチェックします。", ko: "스크래치 카드에 인쇄된 문자 코드를 입력하여 교차 확인하세요.", fr: "Vérification croisée en saisissant le code alphanumérique imprimé sur la carte." },
  verify_card2_cta:  { vi: "Nhập Dữ liệu", en: "Enter Data", zh: "输入数据", ja: "データを入力", ko: "데이터 입력", fr: "Saisir les données" },
  verify_card3_title:{ vi: "AI Đối Soát Giấy Tờ", en: "AI Document Verification", zh: "AI文件核查", ja: "AI書類照合", ko: "AI 문서 검증", fr: "Vérification de documents par IA" },
  verify_card3_desc: { vi: "Tải lên Chứng nhận, Vi bằng, Invoice. Công nghệ OCR bóc tách và phân tích mộc chữ ký giả mạo.", en: "Upload Certificates, Notarial Records, Invoices. OCR technology extracts and analyzes forged seals and signatures.", zh: "上传证书、公证记录、发票。OCR技术提取并分析伪造的印章和签名。", ja: "証明書をアップロード。OCR技術で偽造の印章と署名を分析します。", ko: "증명서를 업로드하세요. OCR 기술로 위조 도장과 서명을 분석합니다.", fr: "Téléchargez des certificats. La technologie OCR extrait les cachets et signatures falsifiés." },
  verify_card3_cta:  { vi: "Tải file lên", en: "Upload File", zh: "上传文件", ja: "ファイルをアップロード", ko: "파일 업로드", fr: "Télécharger le fichier" },

  // ── Enterprise Page ──
  ent_badge:         { vi: "Giải pháp B2B Toàn diện", en: "Comprehensive B2B Solution", zh: "全面的B2B解决方案", ja: "包括的なB2Bソリューション", ko: "종합 B2B 솔루션", fr: "Solution B2B complète" },
  ent_title:         { vi: "Nền tảng Quản trị", en: "Management Platform", zh: "管理平台", ja: "管理プラットフォーム", ko: "관리 플랫폼", fr: "Plateforme de gestion" },
  ent_sub:           { vi: "Hệ sinh thái chống giả mạo và quản lý chuỗi cung ứng bằng công nghệ siêu thông minh. Chúng tôi cung cấp giải pháp chuyển đổi số toàn diện giúp doanh nghiệp bảo vệ di sản thương hiệu, minh bạch hoá nguồn gốc và trực tiếp giao tiếp với tệp người dùng cuối.", en: "An anti-counterfeiting ecosystem powered by hyper-intelligent technology. We provide comprehensive digital transformation solutions to protect brand heritage and ensure origin transparency.", zh: "基于超智能技术的防伪和供应链管理生态系统，帮助企业保护品牌遗产、透明化溯源。", ja: "超知能技術を活用した偽造防止エコシステム。ブランド資産の保護と原産地の透明化を支援します。", ko: "초지능 기술로 구동되는 위조 방지 생태계. 브랜드 유산 보호와 원산지 투명성을 돕습니다.", fr: "Un écosystème anti-contrefaçon alimenté par une technologie hyper-intelligente pour protéger le patrimoine de marque." },
  ent_features_title:{ vi: "Tính năng Cốt lõi", en: "Core Features", zh: "核心功能", ja: "コア機能", ko: "핵심 기능", fr: "Fonctionnalités principales" },
  ent_f1_title:      { vi: "Số hoá Chuỗi Cung ứng", en: "Supply Chain Digitization", zh: "供应链数字化", ja: "サプライチェーンのデジタル化", ko: "공급망 디지털화", fr: "Numérisation de la chaîne d'approvisionnement" },
  ent_f1_desc:       { vi: "Theo dõi đường đi của từng đơn vị sản phẩm từ xưởng sản xuất, kho bãi, qua nhà phân phối đến điểm bán lẻ trên hệ thống bản đồ nhiệt thời gian thực.", en: "Track each product unit from factory, warehouse, through distributors to retail points on a real-time heat map.", zh: "在实时热力图上追踪每件产品从工厂到零售点的全程路径。", ja: "リアルタイムヒートマップで各製品の工場から小売店までの移動を追跡します。", ko: "실시간 히트맵에서 공장, 창고, 소매점까지 각 제품 단위를 추적합니다.", fr: "Suivez chaque unité de produit de l'usine aux points de vente sur une carte thermique en temps réel." },
  ent_f2_title:      { vi: "Xác thực Chống giả Tức thời", en: "Instant Anti-counterfeit Verification", zh: "即时防伪验证", ja: "即時偽造防止検証", ko: "즉각 위조 방지 인증", fr: "Vérification anti-contrefaçon instantanée" },
  ent_f2_desc:       { vi: "Bộ thẻ sản phẩm được gắn định danh mã QR động. Khách hàng dễ dàng dùng Camera điện thoại để check mã, nhận chứng chỉ chính hãng trực quan.", en: "Product cards embedded with dynamic QR identity codes. Customers use their phone camera to check codes and receive authenticity certificates.", zh: "产品卡片嵌入动态QR身份码。客户可用手机摄像头扫码，获取正品证书。", ja: "製品カードにダイナミックQRコードを埋め込み。顧客はスマホで正規品証明書を受け取れます。", ko: "제품 카드에 동적 QR 식별 코드 내장. 고객이 정품 인증서를 받을 수 있습니다.", fr: "Les cartes produits dotées de codes QR dynamiques. Les clients reçoivent des certificats d'authenticité." },
  ent_f3_title:      { vi: "Báo cáo Mảng AI Cảnh Báo", en: "AI Alert Analytics", zh: "AI预警分析报告", ja: "AIアラート分析レポート", ko: "AI 경고 분석", fr: "Rapports d'alertes IA" },
  ent_f3_desc:       { vi: "Thu thập và phân tích dữ liệu quét toàn thế giới. Tự động phát giác ngay hành vi làm giả khi 1 lô hàng/mã số có luồng quét bất thường.", en: "Collect and analyze global scan data. Automatically detect counterfeiting when a batch has abnormal scan patterns.", zh: "收集并分析全球扫描数据。自动检测批次异常扫描流量中的伪造行为。", ja: "グローバルスキャンデータを分析。異常なスキャンパターンで偽造行為を自動検出します。", ko: "전 세계 스캔 데이터를 분석합니다. 비정상 스캔 패턴이 있을 때 위조 행위를 자동 감지합니다.", fr: "Collectez les données de scan mondiales. Détectez automatiquement les comportements de contrefaçon." },
  ent_f4_title:      { vi: "Tích hợp Hệ thống (ERP)", en: "System Integration (ERP)", zh: "系统集成（ERP）", ja: "システム統合（ERP）", ko: "시스템 통합 (ERP)", fr: "Intégration système (ERP)" },
  ent_f4_desc:       { vi: "Giao thức API kết nối sẵn với Oracle, SAP, phần mềm quản kho nội khối. Đẩy dữ liệu theo kiện hàng tự động không cần thao tác dán mã thủ công.", en: "API protocols ready to connect with Oracle, SAP, internal warehouse software. Push data per shipment automatically without manual code entry.", zh: "API协议可与Oracle、SAP及内部仓储软件直接对接，按货件自动推送数据。", ja: "Oracle、SAP、社内倉庫ソフトウェアとの接続に対応。手動入力不要で貨物ごとにデータを自動プッシュ。", ko: "Oracle, SAP와 연결 준비된 API 프로토콜. 수동 코드 입력 없이 화물별 데이터를 자동 전송합니다.", fr: "Protocoles API prêts à se connecter avec Oracle, SAP. Poussez les données par expédition automatiquement." },
  ent_process_title: { vi: "Quy trình Vận hành Chuẩn", en: "Standard Operating Process", zh: "标准运营流程", ja: "標準運営プロセス", ko: "표준 운영 프로세스", fr: "Processus opérationnel standard" },
  ent_s1_title:      { vi: "Gắn Định Danh (Tagging)", en: "Identity Tagging", zh: "身份标签贴标", ja: "識別タグ付け", ko: "식별 태깅", fr: "Étiquetage d'identité" },
  ent_s1_desc:       { vi: "Sản phẩm ở nhà máy được gắn mã QR VNTrust công nghệ nén mật mã trước khi đóng thùng và xuất xưởng ra thị trường.", en: "Products at the factory are tagged with VNTrust QR codes using encryption technology before packaging and market release.", zh: "工厂产品在包装出厂前贴附采用加密技术的VNTrust QR码。", ja: "工場の製品は梱包前に暗号化QRコードでタグ付けされます。", ko: "공장의 제품은 포장 전에 암호화 QR 코드로 태깅됩니다.", fr: "Les produits sont étiquetés avec des codes QR VNTrust avant l'emballage." },
  ent_s2_title:      { vi: "Kích hoạt và Phân phối", en: "Activation and Distribution", zh: "激活与分发", ja: "有効化と配布", ko: "활성화 및 유통", fr: "Activation et Distribution" },
  ent_s2_desc:       { vi: "Tổng kho / Đại lý quét mã lô hàng lúc nhập kho, kích hoạt trạng thái hợp pháp trên hệ thống kiểm soát trung tâm.", en: "Warehouses and Agents scan batch codes upon receiving, activating legal circulation status on the central control system.", zh: "总仓和代理商在入库时扫描批次码，在中央控制系统中激活合法流通状态。", ja: "倉庫と代理店が入庫時にバッチコードをスキャンし、合法流通ステータスを有効化します。", ko: "창고와 대리점이 입고 시 배치 코드를 스캔하여 합법적 유통 상태를 활성화합니다.", fr: "Les entrepôts et agents scannent les codes de lot à la réception, activant le statut de circulation légale." },
  ent_s3_title:      { vi: "Người dùng Xác minh", en: "Consumer Verification", zh: "消费者验证", ja: "消費者検証", ko: "소비자 인증", fr: "Vérification du consommateur" },
  ent_s3_desc:       { vi: "Phía người mua chỉ cần một chiếc smartphone quét mã QR trên hộp. Nhận ngay chứng minh nguồn gốc chính hiệu một cách nhanh chóng.", en: "Buyers only need a smartphone to scan the QR code on the box. Instantly receive proof of authentic origin.", zh: "买家只需用智能手机扫描包装盒上的QR码，即可即时获得正品溯源证明。", ja: "購入者はスマートフォンでQRコードをスキャンするだけで正規品証明を受け取れます。", ko: "구매자는 스마트폰으로 QR 코드를 스캔하기만 하면 즉시 정품 원산지 증명을 받으세요.", fr: "Les acheteurs scannent le code QR et reçoivent instantanément la preuve d'origine authentique." },

  // ── Supply Chain & Dashboard ──
  sc_board:          { vi: "Bảng điều khiển", en: "Dashboard", zh: "控制台", ja: "ダッシュボード", ko: "대시보드", fr: "Tableau de bord" },
  sc_analytics:      { vi: "Phân tích", en: "Analytics", zh: "分析", ja: "分析", ko: "분석", fr: "Analyse" },
  sc_title:          { vi: "Phân tích Chuỗi Cung ứng", en: "Supply Chain Analytics", zh: "供应链分析", ja: "サプライチェーン分析", ko: "공급망 분석", fr: "Analyse de la chaîne d'approvisionnement" },
  sc_30d:            { vi: "30 Ngày Qua", en: "Last 30 Days", zh: "过去30天", ja: "過去30日", ko: "지난 30일", fr: "30 derniers jours" },
  sc_7d:             { vi: "7 Ngày Qua", en: "Last 7 Days", zh: "过去7天", ja: "過去7日", ko: "지난 7일", fr: "7 derniers jours" },
  sc_90d:            { vi: "90 Ngày Qua", en: "Last 90 Days", zh: "过去90天", ja: "過去90日", ko: "지난 90일", fr: "90 derniers jours" },
  sc_total_auth:     { vi: "Tổng Số Lượt Xác Thực", en: "Total Authentications", zh: "总认证次数", ja: "総認証数", ko: "총 인증 수", fr: "Authentifications totales" },
  sc_fake_prev:      { vi: "Nỗ Lực Làm Giả Bị Ngăn Chặn", en: "Fake Attempts Prevented", zh: "已阻止的伪造尝试", ja: "阻止した偽造試行", ko: "차단된 위조 시도", fr: "Tentatives de faux empêchées" },
  sc_active:         { vi: "ĐANG HOẠT ĐỘNG", en: "ACTIVE", zh: "活跃中", ja: "アクティブ", ko: "활성", fr: "ACTIF" },
  sc_efficiency:     { vi: "Hiệu Quả Chuỗi Cung Ứng", en: "Supply Chain Efficiency", zh: "供应链效率", ja: "サプライチェーン効率", ko: "공급망 효율", fr: "Efficacité de la chaîne" },
  sc_optimal:        { vi: "TỐI ƯU", en: "OPTIMAL", zh: "最优", ja: "最適", ko: "최적", fr: "OPTIMAL" },
  sc_auth_speed:     { vi: "Tốc Độ Xác Thực", en: "Authentication Speed", zh: "认证速度", ja: "認証速度", ko: "인증 속도", fr: "Vitesse d'authentification" },
  sc_live_traffic:   { vi: "Lưu lượng thực tế trên các nút mạng toàn cầu", en: "Live traffic across global nodes", zh: "全球节点实时流量", ja: "グローバルノードのライブトラフィック", ko: "글로벌 노드의 실시간 트래픽", fr: "Trafic en direct sur les noeuds" },
  sc_day:            { vi: "Ngày", en: "Day", zh: "天", ja: "日", ko: "일", fr: "Jour" },
  sc_week:           { vi: "Tuần", en: "Week", zh: "周", ja: "週", ko: "주", fr: "Semaine" },
  sc_month:          { vi: "Tháng", en: "Month", zh: "月", ja: "月", ko: "월", fr: "Mois" },
  sc_today:          { vi: "Hôm nay:", en: "Today:", zh: "今天：", ja: "本日：", ko: "오늘：", fr: "Aujourd'hui:" },
  sc_trust_dist:     { vi: "Phân bổ Mức Độ Tinh cậy", en: "Trust Level Distribution", zh: "信任度分布", ja: "信頼レベル分布", ko: "신뢰 수준 분포", fr: "Répartition du niveau de confiance" },
  sc_safety_status:  { vi: "Trạng thái an toàn trên toàn hệ thống", en: "System-wide safety status", zh: "全系统安全状态", ja: "システム全体のセキュリティ状態", ko: "시스템 전체 안전 상태", fr: "Statut de sécurité du système" },
  sc_safe_score:     { vi: "ĐIỂM AN TOÀN", en: "SAFETY SCORE", zh: "安全评分", ja: "安全スコア", ko: "안전 점수", fr: "SCORE DE SÉCURITÉ" },
  sc_scan_activity:  { vi: "Hoạt Động Quét Toàn Quốc", en: "National Scan Activity", zh: "全国扫描活动", ja: "全国スキャン活動", ko: "전국 스캔 활동", fr: "Activité de scan nationale" },
  sc_geo_dist:       { vi: "Phân bổ xác thực theo vị trí địa lý", en: "Authentication distribution by geography", zh: "按地理位置的认证分布", ja: "地域別認証分布", ko: "지역별 인증 분포", fr: "Répartition par géographie" },
  sc_live_data:      { vi: "Dữ Liệu Trực Tiếp", en: "Live Data", zh: "实时数据", ja: "ライブデータ", ko: "실시간 데이터", fr: "Données en direct" },
  sc_new_scan:       { vi: "Lượt quét mới: Nút", en: "New scan: Node", zh: "新扫描：节点", ja: "新しいスキャン：ノード", ko: "새 스캔：노드", fr: "Nouveau scan: Noeud" },
  sc_latest_ledger:  { vi: "Nhật Ký Sổ Cái Mới Nhất", en: "Latest Ledger Logs", zh: "最新账本日志", ja: "最新台帳ログ", ko: "최신 원장 로그", fr: "Derniers journaux du grand livre" },
  sc_live:           { vi: "LIVE", en: "LIVE", zh: "实时", ja: "ライブ", ko: "라이브", fr: "EN DIRECT" },
  sc_realtime_block: { vi: "Cập nhật khối thời gian thực", en: "Real-time block updates", zh: "实时区块更新", ja: "リアルタイムブロック更新", ko: "실시간 블록 업데이트", fr: "Mises à jour des blocs en temps réel" },
  sc_full_network:   { vi: "Toàn Bộ Mạng Lưới Blockchain", en: "Full Blockchain Network", zh: "完整区块链网络", ja: "完全ブロックチェーンネットワーク", ko: "전체 블록체인 네트워크", fr: "Réseau complet de la blockchain" },
  sc_ai_running:     { vi: "Trình Phân Tích AI Đang Chạy", en: "AI Analyzer Running", zh: "AI分析器运行中", ja: "AIアナライザー稼働中", ko: "AI 분석기 실행 중", fr: "Analyseur IA en cours" },
  sc_scanning:       { vi: "Đang quét", en: "Scanning", zh: "正在扫描", ja: "スキャン中", ko: "스캔 중", fr: "Analyse en cours" },
  sc_hotspot:        { vi: "Điểm nóng", en: "Hotspot", zh: "热点", ja: "ホットスポット", ko: "핫스팟", fr: "Point chaud" },
  sc_tracking:       { vi: "Đang theo dõi", en: "Tracking", zh: "追踪中", ja: "追跡中", ko: "추적 중", fr: "En suivi" },
  sc_normal:         { vi: "Bình thường", en: "Normal", zh: "正常", ja: "正常", ko: "정상", fr: "Normal" },
  sc_export:         { vi: "EXPORT REPORT", en: "EXPORT REPORT", zh: "导出报告", ja: "レポート出力", ko: "보고서 내보내기", fr: "EXPORTER RAPPORT" },

  // ── Supply Chain inline text ──
  sc_active_badge:   { vi: "ĐANG HOẠT ĐỘNG", en: "ACTIVE", zh: "活跃中", ja: "アクティブ", ko: "활성", fr: "ACTIF" },
  sc_ai_detect:      { vi: "Phát hiện bởi Phân tích Phân cực AI", en: "Detected by Polarization AI Analytics", zh: "由极化AI分析检测", ja: "偏光AI分析によって検出", ko: "편광 AI 분석으로 감지", fr: "Détecté par l'analyse IA de polarisation" },
  sc_latency:        { vi: "Độ trễ Blockchain:", en: "Blockchain Latency:", zh: "区块链延迟：", ja: "ブロックチェーン遅延：", ko: "블록체인 지연：", fr: "Latence blockchain :" },
  sc_unit_scans:     { vi: "lượt", en: "scans", zh: "次", ja: "回", ko: "회", fr: "scans" },
  sc_data_per_sec:   { vi: "dữ liệu/giây", en: "data/sec", zh: "数据/秒", ja: "データ/秒", ko: "데이터/초", fr: "données/sec" },
  sc_action_log1:    { vi: "Thực thi Hợp đồng Thông minh", en: "Smart Contract Execution", zh: "智能合约执行", ja: "スマートコントラクト実行", ko: "스마트 컨트랙트 실행", fr: "Exécution de contrat intelligent" },
  sc_action_log2:    { vi: "Xác nhận NFT Lô hàng mới", en: "New Batch NFT Confirmed", zh: "新批次NFT已确认", ja: "新バッチNFT確認済み", ko: "신규 배치 NFT 확인됨", fr: "NFT de nouveau lot confirmé" },
  sc_action_log3:    { vi: "Đồng bộ Giao dịch Blockchain", en: "Blockchain Transaction Sync", zh: "区块链交易同步", ja: "ブロックチェーン取引同期", ko: "블록체인 거래 동기화", fr: "Synchronisation des transactions blockchain" },
  sc_action_log4:    { vi: "Cập nhật Trạng thái Phân cực AI", en: "AI Polarization Status Update", zh: "AI极化状态更新", ja: "AI偏光ステータス更新", ko: "AI 편광 상태 업데이트", fr: "Mise à jour du statut IA de polarisation" },
  sc_log_auth_done:  { vi: "Xác Thực Lô Hàng Hoàn Tất", en: "Batch Authentication Complete", zh: "批次验证完成", ja: "バッチ認証完了", ko: "배치 인증 완료", fr: "Authentification de lot terminée" },
  sc_log_blocked:    { vi: "Ngăn Chặn Hoạt Động Bất Thường", en: "Abnormal Activity Blocked", zh: "已阻止异常活动", ja: "異常活動を遮断", ko: "비정상 활동 차단됨", fr: "Activité anormale bloquée" },
  sc_log_contract:   { vi: "Thực Thi Hợp Đồng Thông Minh", en: "Smart Contract Executed", zh: "智能合约已执行", ja: "スマートコントラクト実行済み", ko: "스마트 컨트랙트 실행됨", fr: "Contrat intelligent exécuté" },
  sc_log_just_now:   { vi: "Vừa xong", en: "Just now", zh: "刚刚", ja: "たった今", ko: "방금 전", fr: "À l'instant" },
  sc_log_mins_ago:   { vi: "phút trước", en: "min ago", zh: "分钟前", ja: "分前", ko: "분 전", fr: "min. avant" },
  sc_log_fraud:      { vi: "Ngăn Chặn Cố Gắng Làm Giả", en: "Counterfeit Attempt Blocked", zh: "已阻止伪造尝试", ja: "偽造試行を遮断", ko: "위조 시도 차단됨", fr: "Tentative de contrefaçon bloquée" },
  sc_log_found_at:   { vi: "Phát hiện tại", en: "Detected at", zh: "发现于", ja: "発見場所：", ko: "발견 위치：", fr: "Détecté à" },
  sc_log_sig_viol:   { vi: "Vi phạm chữ ký:", en: "Signature violation:", zh: "签名违规：", ja: "署名違反：", ko: "서명 위반：", fr: "Violation de signature :" },
  sc_log_sync:       { vi: "Đồng bộ dữ liệu mạng: Nút", en: "Network data sync: Node", zh: "网络数据同步：节点", ja: "ネットワークデータ同期：ノード", ko: "네트워크 데이터 동기화：노드", fr: "Sync données réseau : Noeud" },
  sc_log_new_node:   { vi: "Kết Nối Nút Mạng Mới:", en: "New Network Node Connected:", zh: "新网络节点已连接：", ja: "新しいネットワークノード接続済み：", ko: "새 네트워크 노드 연결됨：", fr: "Nouveau noeud réseau connecté :" },
  sc_log_auth_cert:  { vi: "Xác thực Cấp phép", en: "Licensed Authentication", zh: "授权认证", ja: "ライセンス認証", ko: "인가 인증", fr: "Authentification autorisée" },

  // ── History Page ──
  hist_title:        { vi: "Nhật ký Hệ thống",        en: "System History",          zh: "系统历史",      ja: "システム履歴",     ko: "시스템 기록",          fr: "Historique système" },
  hist_monitor:      { vi: "Giám sát Hoạt động",       en: "Activity Monitor",        zh: "活动监控",      ja: "アクティビティ監視", ko: "활동 모니터",          fr: "Surveillance d'activité" },
  hist_sub_admin:    { vi: "Hiển thị toàn bộ nhật ký hệ thống", en: "Showing all system logs", zh: "显示所有系统日志", ja: "全システムログ表示", ko: "전체 시스템 로그 표시", fr: "Affichage de tous les journaux" },
  hist_sub_user:     { vi: "Hiển thị nhật ký của tài khoản bạn", en: "Showing logs for your account", zh: "显示您的账户日志", ja: "あなたのアカウントのログ", ko: "내 계정 로그 표시", fr: "Journaux de votre compte" },
  hist_all:          { vi: "Tất cả",                   en: "All",                     zh: "全部",          ja: "すべて",           ko: "전체",                 fr: "Tout" },
  hist_warning:      { vi: "Cảnh báo",                 en: "Warning",                 zh: "警告",          ja: "警告",             ko: "경고",                 fr: "Avertissement" },
  hist_error:        { vi: "Lỗi",                      en: "Error",                   zh: "错误",          ja: "エラー",           ko: "오류",                 fr: "Erreur" },
  hist_loading:      { vi: "Đang tải nhật ký...",      en: "Loading logs...",         zh: "正在加载日志...", ja: "ログ読込中...",    ko: "로그 로딩 중...",       fr: "Chargement des journaux..." },
  hist_empty:        { vi: "Chưa có nhật ký nào",      en: "No logs yet",             zh: "暂无日志",      ja: "ログがありません",  ko: "로그 없음",             fr: "Aucun journal" },
  hist_col_action:   { vi: "Hành động",                en: "Action",                  zh: "操作",          ja: "アクション",       ko: "작업",                 fr: "Action" },
  hist_col_user:     { vi: "Người dùng",               en: "User",                    zh: "用户",          ja: "ユーザー",         ko: "사용자",               fr: "Utilisateur" },
  hist_col_role:     { vi: "Vai trò",                  en: "Role",                    zh: "角色",          ja: "役割",             ko: "역할",                 fr: "Rôle" },
  hist_col_ip:       { vi: "IP",                       en: "IP",                      zh: "IP",            ja: "IP",               ko: "IP",                   fr: "IP" },
  hist_col_time:     { vi: "Thời gian",                en: "Time",                    zh: "时间",          ja: "時間",             ko: "시간",                 fr: "Heure" },
  role_admin:        { vi: "Quản trị",                 en: "Admin",                   zh: "管理员",        ja: "管理者",           ko: "관리자",               fr: "Admin" },
  role_mfr:          { vi: "Nhà sản xuất",             en: "Manufacturer",            zh: "制造商",        ja: "製造業者",         ko: "제조업체",             fr: "Fabricant" },
  role_imp:          { vi: "Nhà nhập khẩu",            en: "Importer",                zh: "进口商",        ja: "輸入業者",         ko: "수입업체",             fr: "Importateur" },
  role_consumer:     { vi: "Người tiêu dùng",          en: "Consumer",                zh: "消费者",        ja: "消費者",           ko: "소비자",               fr: "Consommateur" },
  role_unknown:      { vi: "Không xác định",           en: "Unknown",                 zh: "未知",          ja: "不明",             ko: "알 수 없음",            fr: "Inconnu" },
  time_just_now:     { vi: "Vừa xong",                 en: "Just now",                zh: "刚刚",          ja: "たった今",         ko: "방금",                 fr: "À l'instant" },
  time_min_ago:      { vi: "phút trước",               en: "min ago",                 zh: "分钟前",        ja: "分前",             ko: "분 전",                fr: "min. avant" },
  time_hour_ago:     { vi: "giờ trước",                en: "hr ago",                  zh: "小时前",        ja: "時間前",           ko: "시간 전",              fr: "h avant" },
  time_day_ago:      { vi: "ngày trước",               en: "days ago",                zh: "天前",          ja: "日前",             ko: "일 전",                fr: "j avant" },

  // ── Footer ──
  footer_sub:        { vi: "Bảo mật sổ cái bất biến.",  en: "Immutable ledger security.", zh: "不可变账本安全。", ja: "不変台帳セキュリティ。", ko: "불변 원장 보안.", fr: "Sécurité du grand livre immuable." },
  footer_link1:      { vi: "Trung tâm bảo mật",          en: "Security Center",           zh: "安全中心",       ja: "セキュリティセンター",   ko: "보안 센터",             fr: "Centre de sécurité" },
  footer_link2:      { vi: "Minh bạch Blockchain",        en: "Blockchain Transparency",   zh: "区块链透明度",   ja: "ブロックチェーン透明性",  ko: "블록체인 투명성",        fr: "Transparence Blockchain" },
  footer_link3:      { vi: "Giao thức Quyền riêng tư",   en: "Privacy Protocol",          zh: "隐私协议",       ja: "プライバシープロトコル",  ko: "개인정보 프로토콜",      fr: "Protocole de confidentialité" },
  footer_link4:      { vi: "Điều khoản dịch vụ",         en: "Terms of Service",          zh: "服务条款",       ja: "利用規約",             ko: "서비스 약관",            fr: "Conditions d'utilisation" },

  // ── Navbar Modals ──
  nav_chat_title:    { vi: "VNTrust AI Assistant", en: "VNTrust AI Assistant", zh: "VNTrust AI 助手", ja: "VNTrust AI アシスタント", ko: "VNTrust AI 어시스턴트", fr: "Assistant IA VNTrust" },
  nav_chat_placeholder: { vi: "Hỏi VNTrust AI...", en: "Ask VNTrust AI...", zh: "询问 VNTrust AI...", ja: "VNTrust AI に質問...", ko: "VNTrust AI에게 질문하세요...", fr: "Demandez à l'IA VNTrust..." },
  nav_lang_title:    { vi: "Ngôn Ngữ Hệ Thống", en: "System Language", zh: "系统语言", ja: "システム言語", ko: "시스템 언어", fr: "Langue du système" },
  nav_app_title:     { vi: "Tải App VNTrust", en: "Download VNTrust App", zh: "下载 VNTrust 应用", ja: "VNTrust アプリをダウンロード", ko: "VNTrust 앱 다운로드", fr: "Télécharger l'application VNTrust" },
  nav_app_desc:      { vi: "Quét mã QR để cài đặt ứng dụng VNTrust trên thiết bị di động. Hỗ trợ iOS và Android.", en: "Scan the QR code to install the VNTrust app on your mobile device. Supports iOS and Android.", zh: "扫描二维码在移动设备上安装 VNTrust 应用程序。支持 iOS 和 Android。", ja: "QRコードをスキャンしてモバイルデバイスに VNTrust アプリをインストールします。iOSとAndroidをサポート。", ko: "QR 코드를 스캔하여 모바일 기기에 VNTrust 앱을 설치하세요. iOS 및 Android 지원.", fr: "Scannez le code QR pour installer l'application VNTrust sur votre appareil mobile. Prend en charge iOS et Android." },
  nav_profile_logout:{ vi: "Đăng xuất", en: "Logout", zh: "登出", ja: "ログアウト", ko: "로그아웃", fr: "Déconnexion" },

  // ── Inventory Page ──
  inv_title:         { vi: "Quản lý Kho hàng", en: "Inventory Management", zh: "库存管理", ja: "在庫管理", ko: "재고 관리", fr: "Gestion des stocks" },
  inv_sub:           { vi: "Sản phẩm & Lô hàng", en: "Products & Batches", zh: "产品和批次", ja: "製品とバッチ", ko: "제품 및 배치", fr: "Produits et lots" },
  inv_seed:          { vi: "Khởi tạo dữ liệu mẫu", en: "Initialize Sample Data", zh: "初始化样本数据", ja: "サンプルデータの初期化", ko: "샘플 데이터 초기화", fr: "Initialiser les données d'échantillon" },
  inv_sync:          { vi: "Đồng bộ Tem QR", en: "Sync QR Stamps", zh: "同步QR码", ja: "QRスタンプを同期", ko: "QR 스탬프 동기화", fr: "Synchroniser les timbres QR" },
  inv_add_product:   { vi: "Sản phẩm mới", en: "New Product", zh: "新产品", ja: "新製品", ko: "새 제품", fr: "Nouveau produit" },
  inv_add_batch:     { vi: "Tạo Lô Hàng", en: "Create Batch", zh: "创建批次", ja: "バッチを作成", ko: "배치 생성", fr: "Créer un lot" },
  inv_col_sp:        { vi: "Sản phẩm", en: "Product", zh: "产品", ja: "製品", ko: "제품", fr: "Produit" },
  inv_col_lohang:    { vi: "Thông tin Lô", en: "Batch Info", zh: "批次信息", ja: "バッチ情報", ko: "배치 정보", fr: "Infos du lot" },
  inv_col_qty:       { vi: "Số lượng", en: "Quantity", zh: "数量", ja: "数量", ko: "수량", fr: "Quantité" },
  inv_col_qr:        { vi: "Tem QR", en: "QR Stamps", zh: "QR码", ja: "QRスタンプ", ko: "QR 스탬프", fr: "Timbres QR" },
  inv_col_status:    { vi: "Trạng thái", en: "Status", zh: "状态", ja: "ステータス", ko: "상태", fr: "Statut" },
  inv_col_actions:   { vi: "Thao tác", en: "Actions", zh: "操作", ja: "アクション", ko: "작업", fr: "Actions" },
  inv_status_valid:  { vi: "Hợp lệ", en: "Valid", zh: "有效", ja: "有効", ko: "유효함", fr: "Valide" },
  inv_status_exp:    { vi: "Hết hạn", en: "Expired", zh: "已过期", ja: "期限切れ", ko: "만료됨", fr: "Expiré" },
  inv_empty:         { vi: "Chưa có lô hàng nào", en: "No batches yet", zh: "暂无批次", ja: "まだバッチがありません", ko: "아직 배치가 없습니다", fr: "Aucun lot pour le moment" },
  inv_view_qr:       { vi: "Xem danh sách mã QR", en: "View QR list", zh: "查看QR码列表", ja: "QRコードリストを表示", ko: "QR 목록 보기", fr: "Voir la liste des QR" },
  
  // ── Login Page ──
  login_title:       { vi: "Đăng nhập", en: "Login", zh: "登录", ja: "ログイン", ko: "로그인", fr: "Connexion" },
  login_sub:         { vi: "Đăng nhập để vào bảng điều khiển", en: "Login to access the dashboard", zh: "登录以访问仪表板", ja: "ダッシュボードにアクセスするにはログインしてください", ko: "대시보드에 액세스하려면 로그인하세요", fr: "Connectez-vous pour accéder au tableau de bord" },
  login_user:        { vi: "Email hoặc Tên đăng nhập", en: "Email or Username", zh: "电子邮件或用户名", ja: "メールまたはユーザー名", ko: "이메일 또는 사용자 이름", fr: "Email ou nom d'utilisateur" },
  login_pass:        { vi: "Mật khẩu", en: "Password", zh: "密码", ja: "パスワード", ko: "비밀번호", fr: "Mot de passe" },
  login_btn:         { vi: "Đăng nhập Hệ thống", en: "Login to System", zh: "登录系统", ja: "システムにログイン", ko: "시스템에 로그인", fr: "Connexion au système" },
  login_register:    { vi: "Tạo tài khoản mới", en: "Create a new account", zh: "创建新账户", ja: "新しいアカウントを作成", ko: "새 계정 만들기", fr: "Créer un nouveau compte" },
  login_forgot:      { vi: "Quên mật khẩu?", en: "Forgot password?", zh: "忘记密码？", ja: "パスワードをお忘れですか？", ko: "비밀번호를 잊으셨나요?", fr: "Mot de passe oublié ?" },

  // ── Chat Quick Buttons ──
  chat_q_qr:         { vi: "Cách tra mã QR?", en: "How to scan QR?", zh: "如何扫描QR？", ja: "QRスキャン方法？", ko: "QR 스캔 방법?", fr: "Comment scanner QR?" },
  chat_q_fake:       { vi: "Báo cáo hàng giả", en: "Report fake", zh: "举报假货", ja: "偽造を報告", ko: "가품 신고", fr: "Signaler un faux" },
  chat_q_price:      { vi: "Giá dịch vụ", en: "Service pricing", zh: "服务价格", ja: "サービス価格", ko: "서비스 가격", fr: "Tarifs des services" },
  chat_q_support:    { vi: "Liên hệ hỗ trợ", en: "Contact support", zh: "联系支持", ja: "サポートに連絡", ko: "고객 지원", fr: "Contacter le support" },
  chat_q_app:        { vi: "Hướng dẫn dùng app", en: "App guide", zh: "应用指南", ja: "アプリガイド", ko: "앱 가이드", fr: "Guide de l'application" },

  // ── AI Doc Verify ──
  aidoc_title:       { vi: "AI Xác thực Giấy tờ", en: "AI Document Verification", zh: "AI文件认证", ja: "AI書類認証", ko: "AI 문서 검증", fr: "Vérification de documents IA" },
  aidoc_desc:        { vi: "Tải lên hình ảnh Giấy chứng nhận (CO, CQ, VietGAP, ISO...). Trí tuệ Nhân tạo sẽ bóc tách dữ liệu và đối chiếu chữ ký số để phát hiện làm giả.", en: "Upload certificate images (CO, CQ, VietGAP, ISO...). Artificial Intelligence will extract data and compare digital signatures to detect forgery.", zh: "上传证书图像（CO，CQ，VietGAP，ISO...）。人工智能将提取数据并比较数字签名以检测伪造。", ja: "証明書の画像（CO、CQ、VietGAP、ISOなど）をアップロードします。人工知能がデータを抽出し、デジタル署名を比較して偽造を検出します。", ko: "인증서 이미지(CO, CQ, VietGAP, ISO 등)를 업로드하세요. 인공지능이 데이터를 추출하고 디지털 서명을 비교하여 위조를 감지합니다.", fr: "Téléchargez des images de certificat (CO, CQ, VietGAP, ISO...). L'Intelligence Artificielle extraira les données et comparera les signatures numériques pour détecter les falsifications." },
  aidoc_drag:        { vi: "Kéo thả ảnh hoặc Nhấn để chọn", en: "Drag & drop image or Click to select", zh: "拖放图像或单击以选择", ja: "画像をドラッグ＆ドロップまたはクリックして選択", ko: "이미지를 드래그 앤 드롭하거나 클릭하여 선택", fr: "Glissez et déposez l'image ou cliquez pour sélectionner" },
  aidoc_format:      { vi: "Hỗ trợ định dạng JPG, PNG, WEBP (Tối đa 10MB)", en: "Supported formats: JPG, PNG, WEBP (Max 10MB)", zh: "支持的格式：JPG，PNG，WEBP（最大10MB）", ja: "サポートされる形式：JPG、PNG、WEBP（最大10MB）", ko: "지원되는 형식: JPG, PNG, WEBP (최대 10MB)", fr: "Formats pris en charge : JPG, PNG, WEBP (Max 10MB)" },
  aidoc_cancel:      { vi: "Hủy ảnh", en: "Cancel image", zh: "取消图像", ja: "画像をキャンセル", ko: "이미지 취소", fr: "Annuler l'image" },
  aidoc_start:       { vi: "Bắt đầu Xác thực AI", en: "Start AI Verification", zh: "开始AI验证", ja: "AI認証を開始", ko: "AI 검증 시작", fr: "Commencer la vérification IA" },
  aidoc_analyzing:   { vi: "AI Đang phân tích OCR...", en: "AI is analyzing OCR...", zh: "AI正在分析OCR...", ja: "AIがOCRを分析中...", ko: "AI가 OCR을 분석 중...", fr: "L'IA analyse l'OCR..." },
  aidoc_result:      { vi: "Ghi nhận Phân tích", en: "Analysis Record", zh: "分析记录", ja: "分析記録", ko: "분석 기록", fr: "Enregistrement d'analyse" },
  aidoc_empty_res:   { vi: "Vui lòng tải lên giấy chứng nhận\nđể AI phân tích dữ liệu mộc đỏ & chữ ký.", en: "Please upload a certificate\nfor AI to analyze red seal & signature data.", zh: "请上传证书\n供AI分析红章和签名数据。", ja: "AIが赤い印鑑と署名データを分析するために\n証明書をアップロードしてください。", ko: "AI가 빨간 도장 및 서명 데이터를 분석할 수 있도록\n인증서를 업로드하세요.", fr: "Veuillez télécharger un certificat\npour que l'IA analyse le sceau rouge et la signature." },
  aidoc_ready:       { vi: "Sẵn sàng để chạy mô hình AI VNTrust...", en: "Ready to run VNTrust AI model...", zh: "准备运行VNTrust AI模型...", ja: "VNTrust AIモデルを実行する準備ができました...", ko: "VNTrust AI 모델을 실행할 준비가 되었습니다...", fr: "Prêt à exécuter le modèle IA VNTrust..." },
  aidoc_wait:        { vi: "Tiến trình có thể mất vài giây...", en: "The process may take a few seconds...", zh: "此过程可能需要几秒钟...", ja: "プロセスには数秒かかる場合があります...", ko: "이 프로세스는 몇 초 정도 걸릴 수 있습니다...", fr: "Le processus peut prendre quelques secondes..." },
  aidoc_valid:       { vi: "Chứng nhận Hợp lệ", en: "Valid Certificate", zh: "有效证书", ja: "有効な証明書", ko: "유효한 인증서", fr: "Certificat valide" },
  aidoc_valid_sub:   { vi: "Không phát hiện mộc giả hoặc can thiệp kỹ thuật số.", en: "No fake seals or digital tampering detected.", zh: "未检测到假印章或数字篡改。", ja: "偽の印鑑やデジタル改ざんは検出されませんでした。", ko: "가짜 도장이나 디지털 변조가 감지되지 않았습니다.", fr: "Aucun faux sceau ou falsification numérique détecté." },
  aidoc_type:        { vi: "Loại giấy tờ", en: "Document Type", zh: "文件类型", ja: "ドキュメントタイプ", ko: "문서 유형", fr: "Type de document" },
  aidoc_issuer:      { vi: "Cơ quan cấp", en: "Issuer", zh: "签发机构", ja: "発行者", ko: "발급자", fr: "Émetteur" },
  aidoc_date:        { vi: "Ngày hiệu lực", en: "Effective Date", zh: "生效日期", ja: "発効日", ko: "발효일", fr: "Date d'entrée en vigueur" },
  aidoc_ocr:         { vi: "Dữ liệu bóc tách (OCR):", en: "Extracted data (OCR):", zh: "提取数据 (OCR):", ja: "抽出データ (OCR):", ko: "추출된 데이터 (OCR):", fr: "Données extraites (OCR):" },
  aidoc_fake:        { vi: "Nghi ngờ Giả mạo", en: "Suspected Forgery", zh: "涉嫌伪造", ja: "偽造の疑い", ko: "위조 의심", fr: "Falsification suspectée" },
  aidoc_fake_sub:    { vi: "Không tìm thấy từ khóa pháp lý hoặc văn bản sai chuẩn quốc gia.", en: "Legal keywords not found or text deviates from national standards.", zh: "未找到法律关键字或文本偏离国家标准。", ja: "法的なキーワードが見つからないか、テキストが国家標準から逸脱しています。", ko: "법적 키워드를 찾을 수 없거나 텍스트가 국가 표준에서 벗어납니다.", fr: "Mots-clés légaux introuvables ou le texte s'écarte des normes nationales." },
  aidoc_warn:        { vi: "Cảnh báo Nội dung", en: "Content Warning", zh: "内容警告", ja: "コンテンツ警告", ko: "콘텐츠 경고", fr: "Avertissement de contenu" },
  aidoc_dev:         { vi: "Sai lệch / Không xác định", en: "Deviated / Unknown", zh: "偏离 / 未知", ja: "逸脱 / 不明", ko: "일탈 / 알 수 없음", fr: "Dévié / Inconnu" },
  aidoc_notfound:    { vi: "Không tìm thấy ký tự nào", en: "No characters found", zh: "未找到任何字符", ja: "文字が見つかりません", ko: "문자를 찾을 수 없음", fr: "Aucun caractère trouvé" },
  aidoc_report:      { vi: "Báo cáo tài liệu vi phạm lên Cục QLTT", en: "Report violating document to Market Surveillance Agency", zh: "向市场监管局举报违规文件", ja: "市場監視局に違反文書を報告", ko: "시장 감시 기관에 위반 문서 신고", fr: "Signaler le document en violation à l'Agence de surveillance du marché" },
  verify_back:       { vi: "Về Trung tâm Xác thực", en: "Back to Verification Center", zh: "返回认证中心", ja: "認証センターに戻る", ko: "인증 센터로 돌아가기", fr: "Retour au centre de vérification" },
  
  // ── Missing Inventory ──
  inv_add_batch_btn: { vi: "Thêm lô hàng", en: "Add batch", zh: "添加批次", ja: "バッチを追加", ko: "배치 추가", fr: "Ajouter un lot" },
  inv_batch_code:    { vi: "Mã lô", en: "Batch code", zh: "批次代码", ja: "バッチコード", ko: "배치 코드", fr: "Code de lot" },
  inv_mfg_date:      { vi: "Ngày SX", en: "Mfg Date", zh: "生产日期", ja: "製造日", ko: "제조일", fr: "Date de fabrication" },
  inv_exp_date:      { vi: "Hạn dùng", en: "Exp Date", zh: "到期日", ja: "有効期限", ko: "만료일", fr: "Date d'expiration" },
  inv_stamp:         { vi: "tem", en: "stamps", zh: "贴标", ja: "スタンプ", ko: "스탬프", fr: "timbres" },
  inv_no_product:    { vi: "Chưa có sản phẩm nào", en: "No products yet", zh: "暂无产品", ja: "まだ製品がありません", ko: "아직 제품이 없습니다", fr: "Aucun produit pour le moment" },
  inv_add_first:     { vi: "+ Thêm sản phẩm đầu tiên", en: "+ Add first product", zh: "+ 添加第一个产品", ja: "+ 最初の製品を追加", ko: "+ 첫 번째 제품 추가", fr: "+ Ajouter le premier produit" },
  inv_click_add:     { vi: "Nhấn", en: "Click", zh: "点击", ja: "クリック", ko: "클릭", fr: "Cliquez sur" },
  inv_click_or:      { vi: "để thêm, hoặc", en: "to add, or", zh: "添加，或", ja: "して追加、または", ko: "하여 추가하거나", fr: "pour ajouter, ou" },
  inv_click_seed:    { vi: "nếu lần đầu dùng.", en: "if using for the first time.", zh: "如果第一次使用。", ja: "初めて使用する場合。", ko: "처음 사용하는 경우.", fr: "si c'est la première fois." },
  
  // ── Chat missing ──
  chat_greeting:     { vi: "Chào bạn! 👋 Mình là AI VNTrust, sẵn sàng giúp bạn:\n• Tra cứu sản phẩm theo số serial\n• Kiểm tra lô hàng & chuỗi cung ứng\n• Hướng dẫn sử dụng hệ thống\n• Hỗ trợ kỹ thuật 24/7\n\nBạn cần giúp gì hôm nay? 😊", en: "Hello! 👋 I am VNTrust AI, ready to help you:\n• Lookup products by serial number\n• Check batches & supply chain\n• System usage guide\n• 24/7 technical support\n\nHow can I help you today? 😊", zh: "你好！👋我是 VNTrust AI，随时准备为您提供帮助：\n•按序列号查找产品\n•检查批次和供应链\n•系统使用指南\n• 24/7技术支持\n\n今天我能帮您什么？😊", ja: "こんにちは！👋 VNTrust AIです。次のサポートを提供します：\n•シリアル番号で製品を検索\n•バッチとサプライチェーンを確認\n•システム使用ガイド\n•24時間年中無休の技術サポート\n\n今日はどのようにお手伝いしましょうか？😊", ko: "안녕하세요! 👋 VNTrust AI입니다. 다음을 도와드릴 수 있습니다:\n•시리얼 번호로 제품 조회\n•배치 및 공급망 확인\n•시스템 사용 가이드\n•24/7 기술 지원\n\n오늘 무엇을 도와드릴까요? 😊", fr: "Bonjour! 👋 Je suis l'IA VNTrust, prêt à vous aider:\n• Recherche de produits par numéro de série\n• Vérifier les lots & la chaîne d'approvisionnement\n• Guide d'utilisation du système\n• Support technique 24/7\n\nComment puis-je vous aider aujourd'hui? 😊" },

  // ── History & Logs ──
  hist_login_success: { vi: "Đăng nhập hệ thống thành công", en: "System login successful", zh: "系统登录成功", ja: "システムログイン成功", ko: "시스템 로그인 성공", fr: "Connexion au système réussie" },
  hist_mfr_demo:      { vi: "Nhà sản xuất (Demo)", en: "Manufacturer (Demo)", zh: "制造商（演示）", ja: "製造業者（デモ）", ko: "제조업체 (데모)", fr: "Fabricant (Démo)" },
  hist_imp_demo:      { vi: "Nhà nhập khẩu (Demo)", en: "Importer (Demo)", zh: "进口商（演示）", ja: "輸入業者（デモ）", ko: "수입업체 (데모)", fr: "Importateur (Démo)" },

  // ── Quality Monitoring ──
  qual_title:         { vi: "GIÁM SÁT CHẤT LƯỢNG", en: "QUALITY MONITORING", zh: "质量监控", ja: "品質監視", ko: "품질 모니터링", fr: "SURVEILLANCE DE LA QUALITÉ" },
  qual_post:          { vi: "Post-Market Surveillance", en: "Post-Market Surveillance", zh: "上市后监督", ja: "市販後監視", ko: "시판 후 감시", fr: "Surveillance post-commercialisation" },
  qual_upload:        { vi: "Upload Kết quả Phân tích", en: "Upload Analysis Result", zh: "上传分析结果", ja: "分析結果をアップロード", ko: "분석 결과 업로드", fr: "Télécharger le résultat de l'analyse" },
  qual_prod:          { vi: "SẢN PHẨM", en: "PRODUCT", zh: "产品", ja: "製品", ko: "제품", fr: "PRODUIT" },
  qual_date:          { vi: "CƠ SỞ / NGÀY TEST", en: "FACILITY / TEST DATE", zh: "设施 / 测试日期", ja: "施設 / テスト日", ko: "시설 / 테스트 날짜", fr: "INSTALLATION / DATE DU TEST" },
  qual_target:        { vi: "ĐỐI TƯỢNG", en: "TARGET", zh: "目标", ja: "対象", ko: "대상", fr: "CIBLE" },
  qual_result:        { vi: "KẾT QUẢ", en: "RESULT", zh: "结果", ja: "結果", ko: "결과", fr: "RÉSULTAT" },
  qual_verify:        { vi: "XÁC MINH", en: "VERIFICATION", zh: "验证", ja: "検証", ko: "검증", fr: "VÉRIFICATION" },
  qual_unknown:       { vi: "Không xác định", en: "Unknown", zh: "未知", ja: "不明", ko: "알 수 없음", fr: "Inconnu" },
  qual_consumer:      { vi: "Người tiêu dùng", en: "Consumer", zh: "消费者", ja: "消費者", ko: "소비자", fr: "Consommateur" },
  qual_passed:        { vi: "Đạt chuẩn", en: "Passed", zh: "合格", ja: "合格", ko: "합격", fr: "Réussi" },
  qual_pending:       { vi: "Chờ duyệt", en: "Pending", zh: "待定", ja: "保留中", ko: "보류 중", fr: "En attente" },

  // ── Serial Verification ──
  ser_title:          { vi: "Tra cứu Mã Serial", en: "Serial Code Lookup", zh: "序列号查询", ja: "シリアルコード検索", ko: "시리얼 코드 조회", fr: "Recherche de code série" },
  ser_desc:           { vi: "Nhập chuỗi định danh duy nhất (UUID/Serial) in chìm dưới lớp phủ tem VNTrust chống giả.", en: "Enter the unique identification string (UUID/Serial) hidden under the VNTrust anti-counterfeiting stamp layer.", zh: "输入隐藏在VNTrust防伪标志层下的唯一标识字符串（UUID/Serial）。", ja: "VNTrust偽造防止スタンプ層の下に隠されている一意の識別文字列（UUID /シリアル）を入力します。", ko: "VNTrust 위조 방지 스탬프 층 아래에 숨겨진 고유 식별 문자열(UUID/Serial)을 입력하세요.", fr: "Saisissez la chaîne d'identification unique (UUID/Série) cachée sous la couche du cachet anti-contrefaçon VNTrust." },
  ser_uid:            { vi: "MÃ ĐỊNH DANH (UID)", en: "IDENTIFIER CODE (UID)", zh: "识别码（UID）", ja: "識別コード（UID）", ko: "식별 코드(UID)", fr: "CODE D'IDENTIFICATION (UID)" },
  ser_verify_btn:     { vi: "XÁC THỰC TỨC THÌ", en: "INSTANT VERIFY", zh: "即时验证", ja: "即時検証", ko: "즉시 검증", fr: "VÉRIFICATION INSTANTANÉE" },
  ser_enc_title:      { vi: "Mã hóa Cấp Ngân hàng", en: "Bank-Grade Encryption", zh: "银行级加密", ja: "銀行レベルの暗号化", ko: "은행 수준 암호화", fr: "Cryptage de niveau bancaire" },
  ser_enc_desc:       { vi: "Giao dịch truy vấn của bạn được mã hóa hoàn toàn. VNTrust ẩn danh địa chỉ mạng để đảm bảo tính riêng tư trong đối soát.", en: "Your query transaction is fully encrypted. VNTrust anonymizes network addresses to ensure privacy during cross-checking.", zh: "您的查询交易已完全加密。 VNTrust对网络地址进行匿名处理，以确保在交叉核对期间保护隐私。", ja: "クエリトランザクションは完全に暗号化されます。 VNTrustは、クロスチェック中にプライバシーを確​​保するためにネットワークアドレスを匿名化します。", ko: "쿼리 트랜잭션은 완전히 암호화됩니다. VNTrust는 교차 확인 중에 개인 정보를 보장하기 위해 네트워크 주소를 익명화합니다.", fr: "Votre transaction de requête est entièrement cryptée. VNTrust anonymise les adresses réseau pour garantir la confidentialité." },

  // ── QR Scan ──
  qr_title:           { vi: "Quét Mã Bảo Mật", en: "Scan Security Code", zh: "扫描安全码", ja: "セキュリティコードをスキャン", ko: "보안 코드 스캔", fr: "Scanner le code de sécurité" },
  qr_desc:            { vi: "Hướng camera thiết bị vào mã QR hoặc Mã Vạch trên tem chống giả VNTrust. Hệ thống sẽ tự động nhận diện.", en: "Point your device camera at the QR code or Barcode on the VNTrust anti-counterfeit stamp. The system will auto-detect.", zh: "将设备相机对准VNTrust防伪标签上的QR码或条形码。系统将自动检测。", ja: "デバイスカメラをVNTrust偽造防止スタンプのQRコードまたはバーコードに向けます。システムが自動検出します。", ko: "기기 카메라를 VNTrust 위조 방지 스탬프의 QR 코드 또는 바코드로 향하세요. 시스템이 자동으로 감지합니다.", fr: "Pointez l'appareil photo vers le code QR ou le code-barres sur le tampon anti-contrefaçon. Le système détectera automatiquement." },
  qr_tab_qr:          { vi: "Mã QR", en: "QR Code", zh: "QR码", ja: "QRコード", ko: "QR 코드", fr: "Code QR" },
  qr_tab_bar:         { vi: "Mã Vạch", en: "Barcode", zh: "条形码", ja: "バーコード", ko: "바코드", fr: "Code-barres" },
  qr_tip:             { vi: "Hãy đảm bảo môi trường đủ sáng và tem không bị nhàu nát.", en: "Ensure the environment is well-lit and the stamp is not crumpled.", zh: "确保环境光线充足且邮票没有弄皱。", ja: "環境が明るく、スタンプがしわになっていないことを確認してください。", ko: "환경이 밝고 스탬프가 구겨지지 않았는지 확인하세요.", fr: "Assurez-vous que l'environnement est bien éclairé et que le timbre n'est pas froissé." },


  // ── App Carousel ──
  app_dashboard:      { vi: "Bảng điều khiển", en: "Dashboard", zh: "仪表板", ja: "ダッシュボード", ko: "대시보드", fr: "Tableau de bord" },
  app_inventory:      { vi: "Quản lý Tài sản", en: "Asset Management", zh: "资产管理", ja: "資産管理", ko: "자산 관리", fr: "Gestion des actifs" },
  app_qr:             { vi: "Mã QR", en: "QR Code", zh: "QR码", ja: "QRコード", ko: "QR 코드", fr: "Code QR" },
  app_supply:         { vi: "Chuỗi cung ứng", en: "Supply Chain", zh: "供应链", ja: "サプライチェーン", ko: "공급망", fr: "Chaîne d'approvisionnement" },
  app_quality:        { vi: "Hậu kiểm", en: "Quality Check", zh: "质量检查", ja: "品質チェック", ko: "품질 검사", fr: "Contrôle de qualité" },
  app_history:        { vi: "Nhật ký", en: "History", zh: "历史记录", ja: "履歴", ko: "기록", fr: "Historique" },
  app_security:       { vi: "Bảo mật", en: "Security", zh: "安全性", ja: "セキュリティ", ko: "보안", fr: "Sécurité" },
  app_mobile_rep:     { vi: "Báo cáo Mobile", en: "Mobile Report", zh: "移动报告", ja: "モバイルレポート", ko: "모바일 보고서", fr: "Rapport Mobile" },
  app_sms:            { vi: "Cảnh báo SMS", en: "SMS Alert", zh: "短信警报", ja: "SMSアラート", ko: "SMS 알림", fr: "Alerte SMS" },
  app_scan_station:   { vi: "Trạm Quét Mobile", en: "Mobile Scan Station", zh: "移动扫描站", ja: "モバイル スキャン ステーション", ko: "모바일 스캔 스테이션", fr: "Station de scan mobile" },

};

export function t(key: string, lang: string): string {
  return dict[key]?.[lang] ?? dict[key]?.vi ?? key;
}

// ─── Context ─────────────────────────────────────────────────────────────────
interface LangCtx { lang: string; setLang: (l: string) => void; t: (key: string) => string; }
const LanguageContext = createContext<LangCtx>({ lang: "vi", setLang: () => {}, t: (k) => k });

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState("vi");
  useEffect(() => {
    const saved = localStorage.getItem("vntrust_lang");
    if (saved) setLangState(saved);
  }, []);
  const setLang = (l: string) => { setLangState(l); localStorage.setItem("vntrust_lang", l); };
  return (
    <LanguageContext.Provider value={{ lang, setLang, t: (key) => t(key, lang) }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLanguage = () => useContext(LanguageContext);
