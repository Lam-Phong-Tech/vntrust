import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  
  // Protect /dashboard and /enterprise and /supply-chain
  if (pathname.startsWith('/dashboard') || pathname.startsWith('/enterprise') || pathname.startsWith('/supply-chain')) {
    const userRole = request.cookies.get('userRole')?.value
    
    // If no userRole cookie is present, redirect to login
    if (!userRole) {
      return NextResponse.redirect(new URL('/login', request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/enterprise/:path*', '/supply-chain/:path*'],
}
