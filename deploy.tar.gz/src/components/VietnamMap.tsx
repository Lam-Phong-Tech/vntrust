"use client";
import { useState } from "react";
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  ZoomableGroup,
} from "react-simple-maps";
import { MARKERS } from "./GlobeCanvas";

const GEO_URL = "/vn-provinces.topo.json";

const ISLANDS = [
  {
    name: "QĐ. Hoàng Sa (Đà Nẵng)",
    center: [112.33, 16.85] as [number, number],
    dots: [[-6, -5], [0, -8], [6, -4], [9, 0], [7, 5], [2, 8], [-4, 6], [-8, 2], [-3, 0], [3, -2], [0, 3]],
  },
  {
    name: "QĐ. Trường Sa (Khánh Hòa)",
    center: [113.85, 9.0] as [number, number],
    dots: [[-8,-10],[0,-12],[8,-8],[12,-2],[10,5],[6,10],[0,12],[-6,8],[-10,2],[-5,-3],[3,3],[8,-5],[-2,6],[5,-8],[0,0],[-7,5],[4,8],[-3,-7],[9,3],[-5,9]],
  },
];

const ALL_PROVINCES = [
  {name: 'An Giang', lat: 10.3711, lon: 105.4329},
  {name: 'Bà Rịa - Vũng Tàu', lat: 10.4973, lon: 107.1683},
  {name: 'Bạc Liêu', lat: 9.2941, lon: 105.7278},
  {name: 'Bắc Giang', lat: 21.2731, lon: 106.1946},
  {name: 'Bắc Kạn', lat: 22.147, lon: 105.8348},
  {name: 'Bắc Ninh', lat: 21.1861, lon: 106.0763},
  {name: 'Bến Tre', lat: 10.2443, lon: 106.3756},
  {name: 'Bình Dương', lat: 11.2268, lon: 106.666},
  {name: 'Bình Định', lat: 13.7829, lon: 109.2197},
  {name: 'Bình Phước', lat: 11.7516, lon: 106.9189},
  {name: 'Bình Thuận', lat: 11.085, lon: 108.0827},
  {name: 'Cà Mau', lat: 8.5991, lon: 105.0847},
  {name: 'Cao Bằng', lat: 22.6582, lon: 106.257},
  {name: 'Cần Thơ', lat: 10.0452, lon: 105.7469},
  {name: 'Đà Nẵng', lat: 16.0544, lon: 108.2022},
  {name: 'Đắk Lắk', lat: 12.6667, lon: 108.0382},
  {name: 'Đắk Nông', lat: 11.9961, lon: 107.935},
  {name: 'Điện Biên', lat: 21.3853, lon: 103.0189},
  {name: 'Đồng Nai', lat: 10.9388, lon: 106.8153},
  {name: 'Đồng Tháp', lat: 10.2882, lon: 105.7601},
  {name: 'Gia Lai', lat: 13.9785, lon: 108.0536},
  {name: 'Hà Giang', lat: 22.8233, lon: 104.9839},
  {name: 'Hà Nam', lat: 20.5453, lon: 105.9122},
  {name: 'Hà Nội', lat: 21.0285, lon: 105.8542},
  {name: 'Hà Tĩnh', lat: 18.3428, lon: 105.9042},
  {name: 'Hải Dương', lat: 20.9372, lon: 106.3146},
  {name: 'Hải Phòng', lat: 20.8449, lon: 106.6881},
  {name: 'Hậu Giang', lat: 9.7828, lon: 105.4746},
  {name: 'Hòa Bình', lat: 20.8242, lon: 105.3384},
  {name: 'Hưng Yên', lat: 20.6464, lon: 106.0511},
  {name: 'Khánh Hòa', lat: 12.2388, lon: 109.1967},
  {name: 'Kiên Giang', lat: 10.0125, lon: 105.0809},
  {name: 'Kon Tum', lat: 14.3496, lon: 108.0003},
  {name: 'Lai Châu', lat: 22.3965, lon: 103.4682},
  {name: 'Lạng Sơn', lat: 21.8475, lon: 106.7571},
  {name: 'Lào Cai', lat: 22.4836, lon: 104.0233},
  {name: 'Lâm Đồng', lat: 11.5546, lon: 108.1407},
  {name: 'Long An', lat: 10.5367, lon: 106.4067},
  {name: 'Nam Định', lat: 20.4308, lon: 106.1759},
  {name: 'Nghệ An', lat: 18.6667, lon: 105.6667},
  {name: 'Ninh Bình', lat: 20.2539, lon: 105.9748},
  {name: 'Ninh Thuận', lat: 11.5647, lon: 108.9886},
  {name: 'Phú Thọ', lat: 21.3168, lon: 105.2173},
  {name: 'Phú Yên', lat: 13.0886, lon: 109.3005},
  {name: 'Quảng Bình', lat: 17.5147, lon: 106.2573},
  {name: 'Quảng Nam', lat: 15.5682, lon: 108.0195},
  {name: 'Quảng Ngãi', lat: 15.1205, lon: 108.7923},
  {name: 'Quảng Ninh', lat: 21.0069, lon: 107.2925},
  {name: 'Quảng Trị', lat: 16.7456, lon: 107.1881},
  {name: 'Sóc Trăng', lat: 9.6033, lon: 105.9806},
  {name: 'Sơn La', lat: 21.3283, lon: 103.9142},
  {name: 'Tây Ninh', lat: 11.3134, lon: 106.0958},
  {name: 'Thái Bình', lat: 20.4463, lon: 106.3366},
  {name: 'Thái Nguyên', lat: 21.5928, lon: 105.8442},
  {name: 'Thanh Hóa', lat: 19.8055, lon: 105.7725},
  {name: 'Thừa Thiên Huế', lat: 16.4637, lon: 107.5905},
  {name: 'Tiền Giang', lat: 10.3541, lon: 106.3601},
  {name: 'TP Hồ Chí Minh', lat: 10.8231, lon: 106.6297},
  {name: 'Trà Vinh', lat: 9.9405, lon: 106.3403},
  {name: 'Tuyên Quang', lat: 21.8214, lon: 105.2166},
  {name: 'Vĩnh Long', lat: 10.0531, lon: 105.9482},
  {name: 'Vĩnh Phúc', lat: 21.3093, lon: 105.6046},
  {name: 'Yên Bái', lat: 21.7229, lon: 104.9113}
];

export default function VietnamMap({
  onMarkerClick,
}: {
  onMarkerClick: (m: (typeof MARKERS)[0]) => void;
}) {
  const [hovered, setHovered] = useState<number | null>(null);
  const [position, setPosition] = useState({ coordinates: [106.0, 16.0] as [number, number], zoom: 1 });

  function handleMoveEnd(position: { coordinates: [number, number]; zoom: number }) {
    setPosition(position);
  }

  const typeStyle = {
    hot:     { fill: "#f59e0b", stroke: "#fde68a", r: 4 },
    warning: { fill: "#ea580c", stroke: "#fdba74", r: 3 },
    normal:  { fill: "#0891b2", stroke: "#67e8f9", r: 2.5 },
  };

  return (
    <div
      className="absolute inset-0 select-none overflow-hidden bg-transparent"
    >
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{
          center: [107.0, 16.0],
          scale: 1650,
        }}
        width={520}
        height={700}
        style={{ width: "100%", height: "100%", background: "transparent" }}
      >
        <ZoomableGroup
          zoom={position.zoom}
          center={position.coordinates}
          onMoveEnd={handleMoveEnd}
          maxZoom={10}
        >
          {/* ── Geographic base ── */}
          <Geographies geography={GEO_URL}>
            {({ geographies }) =>
              geographies.map((geo) => {
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    fill="#155080"
                    stroke="#5bc8f0"
                    strokeWidth={0.5}
                    style={{
                      default: { outline: "none", fill: "#155080", transition: "all 0.2s" },
                      hover:   { outline: "none", fill: "#1d6aaa", transition: "all 0.2s" },
                      pressed: { outline: "none", fill: "#1d6aaa" },
                    }}
                  />
                );
              })
            }
          </Geographies>

          {/* ── Island groups ── */}
          {ISLANDS.map((island) => (
            <g key={island.name}>
              <Marker coordinates={island.center}>
                {island.dots.map(([dx, dy], i) => (
                  <ellipse
                    key={i}
                    cx={dx * 0.9}
                    cy={dy * 0.9}
                    rx={2}
                    ry={1.2}
                    fill="#1e293b"
                    stroke="#5bc8f0"
                    strokeWidth={0.5}
                  />
                ))}
                <text
                  textAnchor="middle"
                  y={-20}
                  fontSize={4}
                  fontWeight="bold"
                  fill="#7dd4fc"
                  style={{ pointerEvents: "none" }}
                >
                  {island.name}
                </text>
              </Marker>
            </g>
          ))}

          {/* ── Base 63 Province Names ── */}
          {ALL_PROVINCES.map((prov, i) => {
            return (
              <Marker key={`prov-${i}`} coordinates={[prov.lon, prov.lat]}>
                <text
                  textAnchor="middle"
                  dy={2}
                  fontSize={position.zoom > 3 ? 3 : (position.zoom > 1.5 ? 4 : 4.5)}
                  fontWeight="bold"
                  fill="rgba(255,255,255,0.7)"
                  style={{ 
                    pointerEvents: "none", 
                    userSelect: "none",
                    filter: "drop-shadow(0px 0px 2px rgba(0,0,0,0.8))"
                  }}
                >
                  {prov.name}
                </text>
              </Marker>
            );
          })}

          {/* ── Active Scanning Markers ── */}
          {MARKERS.filter(m => m.id !== 35 && m.id !== 36).map((m) => {
            const s = typeStyle[m.type as keyof typeof typeStyle];
            const isHov = hovered === m.id;
            const isHot = m.type === "hot";
            // Scale marker radiuses relative to zoom inverse slightly
            const zoomScale = Math.max(1, 4 / position.zoom); 
            const baseR = s.r * zoomScale;
            const r = isHov ? baseR * 1.5 : baseR;

            return (
              <Marker key={m.id} coordinates={[m.lon, m.lat]}>
                {/* Main dot */}
                <circle
                  r={r}
                  fill={s.fill}
                  stroke={s.stroke}
                  strokeWidth={isHov ? 1.5 : 0.5}
                  onClick={() => onMarkerClick(m)}
                  onMouseEnter={() => setHovered(m.id)}
                  onMouseLeave={() => setHovered(null)}
                  style={{
                    cursor: "pointer",
                    filter: `drop-shadow(0 0 ${isHot ? 5 : 2}px ${s.fill})`,
                    transition: "r 0.12s",
                  }}
                />

                {/* City name for hot / hovered markers to overlay the base ones */}
                {(isHot || isHov) && (
                  <text
                    textAnchor="start"
                    x={r + 2}
                    y={2}
                    fontSize={isHov ? 6 : 5}
                    fontWeight="bold"
                    fill="white"
                    stroke="rgba(0,0,0,0.8)"
                    strokeWidth={1}
                    paintOrder="stroke"
                    style={{ pointerEvents: "none" }}
                  >
                    {m.name}
                  </text>
                )}

                {/* Hover tooltip - fixed position relative to marker */}
                {isHov && (
                  <g style={{ pointerEvents: "none" }}>
                    <rect
                      x={r + 4}
                      y={-28}
                      width={110}
                      height={40}
                      rx={4}
                      fill="rgba(2,12,28,0.95)"
                      stroke="rgba(125,212,252,0.4)"
                      strokeWidth={0.5}
                    />
                    <text x={r + 10} y={-17} fontSize={6} fontWeight="bold" fill="white">
                      {m.name}
                    </text>
                    <text x={r + 10} y={-9} fontSize={4} fill="#94a3b8">
                      Tỉnh/Thành phố • Việt Nam
                    </text>
                    <text x={r + 10} y={-1} fontSize={5} fill="#22d3ee" fontWeight="bold">
                      {m.scans.toLocaleString()} lượt quét
                    </text>
                    <text
                      x={r + 10}
                      y={7}
                      fontSize={4}
                      fill={m.fake > 0 ? "#fbbf24" : "#4ade80"}
                      fontWeight="bold"
                    >
                      {m.fake > 0 ? `⚠ ${m.fake} cảnh báo giả` : "✓ An toàn"}
                    </text>
                  </g>
                )}
              </Marker>
            );
          })}
        </ZoomableGroup>
      </ComposableMap>
    </div>
  );
}
