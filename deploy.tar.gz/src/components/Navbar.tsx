"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect, useRef } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useChat } from "@/contexts/ChatContext";

// ─── Language Modal ───────────────────────────────────────────────────────────
const LANGS = [
  { code: "vi", name: "Tiếng Việt", flag: "🇻🇳", short: "VN" },
  { code: "en", name: "English",    flag: "🇬🇧", short: "GB" },
  { code: "zh", name: "中文",       flag: "🇨🇳", short: "CN" },
  { code: "ja", name: "日本語",     flag: "🇯🇵", short: "JP" },
  { code: "ko", name: "한국어",     flag: "🇰🇷", short: "KR" },
  { code: "fr", name: "Français",  flag: "🇫🇷", short: "FR" },
];

function LanguageModal({ current, onSelect, onClose }: {
  current: string; onSelect: (code: string) => void; onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div className="relative w-full max-w-sm glass-panel border border-white/20 rounded-3xl p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500 flex items-center justify-center">
              <span className="material-symbols-outlined text-white">language</span>
            </div>
            <h2 className="text-lg font-black text-white">Chọn ngôn ngữ</h2>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition">
            <span className="material-symbols-outlined text-white text-[18px]">close</span>
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {LANGS.map(l => (
            <button key={l.code}
              onClick={() => { onSelect(l.code); onClose(); }}
              className={`flex items-center gap-3 p-4 rounded-2xl border transition text-left active:scale-95 ${current === l.code ? "border-cyan-400 bg-cyan-500/15 shadow-[0_0_15px_rgba(0,220,220,0.2)]" : "border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20"}`}>
              <div className="flex flex-col items-center w-8 shrink-0">
                <span className="text-[9px] font-black text-slate-400">{l.short}</span>
                <span className="text-xl leading-none">{l.flag}</span>
              </div>
              <div>
                <p className="text-white font-bold text-sm">{l.name}</p>
                {current === l.code && <span className="text-[9px] text-cyan-400 font-black tracking-wider">ĐANG DÙNG</span>}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Shared AI Engine ─────────────────────────────────────────────────────────
const AI_RESPONSES: Array<{ match: RegExp; replies: string[] }> = [
  { match: /^(xin chào|hello|hi|chào|hey|alo)[\s!]*/i, replies: [
    "Chào bạn! 😊 Rất vui được gặp bạn hôm nay. Mình là AI của VNTrust nha — bạn cần tra serial, kiểm tra lô hàng, hay hỏi gì khác không?",
    "Hey! 👋 Mình đây. Có gì cần giúp không bạn? Nhập số serial để mình check ngay, hoặc hỏi thoải mái nhé!",
  ]},
  { match: /cảm ơn|thanks|thank you|ngon|tốt lắm|hay quá|giỏi/i, replies: [
    "Không có gì bạn ơi 😄 Giúp được bạn là mình vui rồi. Cần gì thêm cứ hỏi nha!",
    "Oki! Lúc nào cũng sẵn sàng hỗ trợ bạn nhé 🙌",
  ]},
  { match: /serial|mã|uid|qr|tem|quét|scan|số sê/i, replies: [
    "Bạn nhập thẳng số serial vào đây mình tra ngay nha! Ví dụ: EDG123456 🔎",
    "Để mình giúp! Bạn gõ mã serial hoặc UID từ tem QR vào đây nhé 😊",
  ]},
  { match: /hàng giả|làm giả|giả mạo|fake|đáng ngờ|không chính hãng/i, replies: [
    "🚨 Nghe có vẻ nghiêm trọng! Bạn cho mình biết mã serial của sản phẩm không? Mình kiểm tra ngay.\n\n• Gọi: **1800 6789** (miễn phí 24/7)\n• Email: report@vntrust.vn",
  ]},
  { match: /sản phẩm|kho|lô hàng|inventory|thêm|đăng ký/i, replies: [
    "Để quản lý sản phẩm, bạn vào **Tài sản & Lô hàng** nhé 📦\n• Thêm sản phẩm → Hệ thống tạo mã QR ngay\n• Tạo lô hàng → Phân phối tem theo lô\n\nBạn đang cần làm bước nào?",
  ]},
  { match: /giá|chi phí|bao nhiêu|gói|plan|pricing|mất tiền/i, replies: [
    "Bạn hỏi về giá à? 😄\n🟢 **Starter** — Miễn phí (100 SP, 500 QR/tháng)\n🔵 **Business** — 2.990.000₫/tháng\n🟡 **Enterprise** — Liên hệ để được báo giá riêng",
  ]},
  { match: /chuỗi cung ứng|supply chain|phân phối|bản đồ|logistics/i, replies: [
    "Chuỗi cung ứng VNTrust theo dõi **4,821 điểm** trên toàn quốc 🗺️\nVào **Chuỗi Cung ứng** trên menu để xem bản đồ realtime nhé!",
  ]},
  { match: /bảo mật|hack|xâm nhập|lộ data|an toàn/i, replies: [
    "Bảo mật là ưu tiên số 1 của VNTrust đó! 🔐\n• Mã hóa AES-256 toàn bộ data\n• 2FA bắt buộc cho doanh nghiệp\n• AI giám sát 24/7 < 10 giây",
  ]},
  { match: /app|ứng dụng|mobile|điện thoại|ios|android/i, replies: [
    "App VNTrust Mobile xịn lắm đó! 📱\n• Quét QR bằng camera mà không cần nhập tay\n• Offline mode khi mất mạng\n\nBấm **APP DOWNLOAD** trên thanh trên để tải!",
  ]},
  { match: /xuất|báo cáo|report|pdf|csv|export/i, replies: [
    "Xuất báo cáo thì dễ bạn ơi! 📊 Bấm nút **EXPORT OFFLINE REPORT** ở góc trên bản đồ là xong.",
  ]},
  { match: /liên hệ|support|hỗ trợ|hotline|điện thoại|gọi|email/i, replies: [
    "📞 Liên hệ ngay:\n• **Hotline**: 1800 6789 (miễn phí, 24/7)\n• **Email**: support@vntrust.vn\n• **Zalo**: zalo.me/vntrust",
  ]},
];
export const AI_FALLBACK = [
  "Hmm, mình chưa hiểu câu đó lắm 🤔 Bạn có thể nói rõ hơn không? Hoặc nhập số serial để mình tra cứu ngay!",
  "Câu hỏi thú vị! Bạn đang hỏi về sản phẩm cụ thể, cách dùng hệ thống, hay về giá cả?",
  "Bạn thử hỏi theo cách khác, hoặc nhập thẳng số serial để mình check nhanh nhé! 😊",
];
export function getSharedAIReply(q: string): string {
  for (const rule of AI_RESPONSES) {
    if (rule.replies.length > 0 && rule.match.test(q))
      return rule.replies[Math.floor(Math.random() * rule.replies.length)];
  }
  return AI_FALLBACK[Math.floor(Math.random() * AI_FALLBACK.length)];
}

const QUICK_BTNS = ["Cách tra mã QR?", "Báo cáo hàng giả", "Giá dịch vụ", "Liên hệ hỗ trợ", "Hướng dẫn dùng app"];
const MAX_CHAT_LEN = 500;

// ─── AI Chat Modal — dùng ChatContext (real-time sync với Dashboard) ──────────
function AiNavModal({ onClose }: { onClose: () => void }) {
  const { msgs, addMsg } = useChat();
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [warning, setWarning] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, typing]);

  const handleInput = (val: string) => {
    setWarning(val.length > MAX_CHAT_LEN ? `⚠️ Vượt quá giới hạn ${MAX_CHAT_LEN} ký tự.` : "");
    setInput(val);
  };

  const send = async () => {
    const q = input.trim();
    if (!q || typing) return;
    if (q.length > MAX_CHAT_LEN) { setWarning(`⚠️ Tin nhắn vượt quá ${MAX_CHAT_LEN} ký tự.`); return; }
    setWarning("");
    addMsg({ from: "user", text: q });
    setInput("");
    setTyping(true);

    const serial = q.replace(/<[^>]*>/g, " ").match(/\b([A-Z0-9]{6,})\b/i)?.[1];
    let reply = "";
    if (serial) {
      try {
        const res = await fetch(`/api/verify/${serial.toUpperCase()}`);
        const data = await res.json();
        if (data.status === "genuine" || data.status === "suspect" || data.status === "expired") {
          const sp = data.data?.loHang?.sanPham;
          const lo = data.data?.loHang;
          const statusText = data.status === "genuine" ? "✅ Chính hãng" : data.status === "expired" ? "⏰ Đã hết hạn" : "⚠️ Nghi ngờ làm giả";
          reply = `🔍 Xong rồi! Mình tìm thấy mã **${serial.toUpperCase()}**\n${statusText}\n📦 Sản phẩm: ${sp?.tenSanPham ?? "N/A"}\n🏭 NSX: ${sp?.doanhNghiep?.tenDoanhNghiep ?? "N/A"}\n📅 SX: ${lo?.ngaySanXuat ? new Date(lo.ngaySanXuat).toLocaleDateString("vi-VN") : "N/A"} · HSD: ${lo?.hanDung ? new Date(lo.hanDung).toLocaleDateString("vi-VN") : "N/A"}\n\nXem chi tiết tại /verify/${serial.toUpperCase()}`;
        } else {
          reply = `⚠️ Mã **${serial.toUpperCase()}** không có trong hệ thống!\n\nCó thể là:\n• Sản phẩm chưa đăng ký VNTrust\n• Mã bị nhập sai hoặc tem hỏng\n• **Nguy hiểm: Có thể là hàng giả!**`;
        }
      } catch { reply = "⚠️ Không thể kết nối hệ thống xác thực. Vui lòng thử lại sau."; }
    } else {
      let matched = false;
      for (const rule of AI_RESPONSES) {
        if (rule.replies.length > 0 && rule.match.test(q)) {
          reply = rule.replies[Math.floor(Math.random() * rule.replies.length)];
          matched = true;
          break;
        }
      }
      if (!matched) reply = AI_FALLBACK[Math.floor(Math.random() * AI_FALLBACK.length)];
    }

    setTimeout(() => { addMsg({ from: "ai", text: reply }); setTyping(false); }, 700 + Math.random() * 500);
  };

  const charCount = input.length;
  const isOverLimit = charCount > MAX_CHAT_LEN;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div className="relative w-full max-w-md glass-panel border border-white/20 rounded-3xl p-6 shadow-2xl" onClick={e => e.stopPropagation()}>

        {/* Header — giống Dashboard */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-white">smart_toy</span>
            </div>
            <h2 className="text-lg font-black text-white font-headline">Trợ lý AI VNTrust</h2>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition">
            <span className="material-symbols-outlined text-white text-[18px]">close</span>
          </button>
        </div>

        <div className="flex flex-col h-[480px]">
          {/* Messages — giống hệt Dashboard */}
          <div className="flex-1 overflow-y-auto space-y-3 hide-scrollbar pr-1">
            {msgs.map((m, i) => (
              <div key={i} className={`flex gap-2 ${m.from === "user" ? "flex-row-reverse" : ""}`}>
                <div className={`w-7 h-7 rounded-full shrink-0 flex items-center justify-center mt-1 ${m.from === "ai" ? "bg-cyan-500" : "bg-slate-600"}`}>
                  <span className="material-symbols-outlined text-white text-[13px]">{m.from === "ai" ? "smart_toy" : "person"}</span>
                </div>
                <div className={`px-4 py-2.5 rounded-2xl text-sm max-w-[82%] whitespace-pre-line leading-relaxed ${m.from === "ai" ? "bg-white/10 text-white rounded-tl-none" : "bg-cyan-500 text-white rounded-tr-none"}`}>
                  {m.text}
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex gap-2">
                <div className="w-7 h-7 rounded-full bg-cyan-500 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-white text-[13px]">smart_toy</span>
                </div>
                <div className="px-4 py-3 rounded-2xl bg-white/10 flex gap-1.5 items-center">
                  {[0, 150, 300].map(d => <div key={d} className="w-2 h-2 rounded-full bg-cyan-300 animate-bounce" style={{ animationDelay: `${d}ms` }} />)}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Quick buttons — giống Dashboard */}
          <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-white/10">
            {QUICK_BTNS.map(q => (
              <button key={q} onClick={() => setInput(q)}
                className="text-[10px] font-bold px-3 py-1.5 bg-white/8 rounded-full text-slate-300 hover:bg-white/15 hover:text-white transition border border-white/10">
                {q}
              </button>
            ))}
          </div>

          {/* Warning */}
          {warning && (
            <div className="mt-2 px-3 py-1.5 bg-red-500/15 border border-red-500/30 rounded-xl text-red-400 text-[11px] font-medium">
              {warning}
            </div>
          )}

          {/* Input — giống Dashboard */}
          <div className="flex gap-2 mt-2">
            <div className="relative flex-1">
              <input
                className={`flex-1 bg-white/10 border rounded-full px-4 py-2.5 text-sm text-white placeholder:text-slate-400 outline-none transition w-full ${isOverLimit ? "border-red-500/70 focus:border-red-500" : "border-white/20 focus:border-cyan-400"}`}
                placeholder="Chat với AI VNTrust..."
                value={input}
                onChange={e => handleInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && send()}
              />
              {charCount >= 400 && (
                <span className={`absolute -bottom-4 right-2 text-[10px] font-bold ${isOverLimit ? "text-red-400" : "text-slate-400"}`}>
                  {charCount}/{MAX_CHAT_LEN}
                </span>
              )}
            </div>
            <button onClick={send} disabled={isOverLimit || !input.trim() || typing}
              className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition ${isOverLimit || !input.trim() || typing ? "bg-white/20 cursor-not-allowed opacity-40" : "bg-cyan-500 hover:bg-cyan-400"}`}>
              <span className="material-symbols-outlined text-white text-[18px]">send</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

function AppDownloadModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <div className="relative w-full max-w-[420px] rounded-[24px] p-6 shadow-2xl overflow-hidden" 
           style={{ backgroundColor: 'rgba(26, 45, 69, 0.9)', border: '1px solid rgba(255,255,255,0.1)' }} 
           onClick={e => e.stopPropagation()}>
        
        {/* Header */}
        <div className="flex items-center justify-between mb-7">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#ff9800] shadow-[0_0_15px_rgba(255,152,0,0.4)] flex items-center justify-center">
              <span className="material-symbols-outlined text-white text-[20px]" style={{fontVariationSettings: "'FILL' 1"}}>download</span>
            </div>
            <span className="font-bold text-white text-[19px] tracking-wide font-headline">Tải VNTrust App</span>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
            <span className="material-symbols-outlined text-white text-[18px]">close</span>
          </button>
        </div>

        {/* Buttons Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <a href="#" className="flex flex-col items-center justify-center h-[130px] rounded-[18px] bg-[#24384e] border border-transparent hover:border-white/20 transition-colors cursor-not-allowed">
            <svg viewBox="0 0 384 512" fill="white" className="w-9 h-9 mb-3 opacity-95">
              <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"/>
            </svg>
            <p className="text-[11px] text-slate-300 font-medium mb-1">Tải trên</p>
            <p className="font-bold text-white text-[16px]">App Store</p>
          </a>
          
          <a href="/downloads/vntrust-mobile-alpha.apk" download className="flex flex-col items-center justify-center h-[130px] rounded-[18px] bg-[#24384e] border border-transparent hover:border-[#4ade80]/40 hover:bg-[#2a4059] transition-all cursor-pointer shadow-[0_4px_20px_rgba(0,0,0,0.1)]">
            <span className="material-symbols-outlined text-[#4ade80] text-[40px] mb-2" style={{fontVariationSettings: "'FILL' 1"}}>android</span>
            <p className="text-[11px] text-slate-300 font-medium mb-1">Tải trên</p>
            <p className="font-bold text-white text-[16px]">Google Play</p>
          </a>
        </div>

        {/* Footer */}
        <p className="text-center text-[12.5px] text-slate-400 font-medium tracking-wide">
          Phiên bản 2.4.1 · iOS 14+ · Android 8+
        </p>
      </div>
    </div>
  );
}

// ─── Navbar ───────────────────────────────────────────────────────────────────
export default function Navbar() {
  const pathname = usePathname();
  const { lang, setLang, t } = useLanguage();
  const [modal, setModal] = useState<"ai" | "lang" | "app" | null>(null);

  const navLinks = [
    { key: "nav_verify",   href: "/verify" },
    { key: "nav_supply",   href: "/supply-chain" },
    { key: "nav_dashboard",href: "/dashboard" },
    { key: "nav_enterprise",href: "/enterprise" },
  ];

  const isActive = (href: string) =>
    href === "/dashboard"
      ? pathname.startsWith("/dashboard") || pathname === "/"
      : pathname.startsWith(href);

  return (
    <>
      {modal === "ai"   && <AiNavModal         onClose={() => setModal(null)} />}
      {modal === "lang" && <LanguageModal current={lang} onSelect={setLang} onClose={() => setModal(null)} />}
      {modal === "app"  && <AppDownloadModal   onClose={() => setModal(null)} />}

      <nav className="fixed top-0 w-full z-50 py-3 px-6 glass-panel border-b-0"
           style={{ background: "linear-gradient(to bottom, rgba(14,30,48,0.5), rgba(14,30,48,0.1))" }}>
        <div className="max-w-[1600px] mx-auto flex justify-between items-center">

          {/* Left: Logo + nav */}
          <div className="flex items-center gap-10">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-cyan-400 to-blue-500 flex items-center justify-center shadow-[0_0_15px_rgba(0,221,221,0.5)]">
                <span className="material-symbols-outlined text-white">shield</span>
              </div>
              <span className="text-xl font-black tracking-tight text-white font-headline">
                VN<span className="text-cyan-400">TRUST</span>
              </span>
            </Link>

            <div className="hidden lg:flex items-center gap-7 pt-0.5">
              {navLinks.map(({ key, href }) => (
                <Link key={href} href={href}
                  className={`text-[13px] font-bold font-headline tracking-widest transition-all uppercase pb-1 ${isActive(href) ? "text-white border-b-2 border-cyan-400 glow-text" : "text-blue-100/70 hover:text-white"}`}>
                  {t(key)}
                </Link>
              ))}
            </div>
          </div>

          {/* Right: action buttons */}
          <div className="hidden lg:flex items-center gap-3">
            <button onClick={() => setModal("ai")}
              className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-xs font-bold text-slate-200 hover:text-white hover:bg-white/15 transition border border-white/10 active:scale-95">
              <span className="material-symbols-outlined text-[15px] text-cyan-300">smart_toy</span>
              ASK AI
            </button>

            <button onClick={() => setModal("lang")}
              className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-xs font-bold text-slate-200 hover:text-white hover:bg-white/15 transition border border-white/10 uppercase active:scale-95">
              <span className="material-symbols-outlined text-[15px]">language</span>
              {LANGS.find(l => l.code === lang)?.short ?? "VN"}
            </button>

            <button onClick={() => setModal("app")}
              className="flex items-center gap-2 bg-gradient-to-r from-[#e7d188] to-[#ceb059] text-[#2c2003] px-5 py-2 rounded-full text-xs font-bold shadow-[0_0_15px_rgba(231,209,136,0.3)] hover:brightness-110 transition active:scale-95">
              APP DOWNLOAD
              <div className="flex gap-1 items-center ml-1">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" fill="currentColor" className="w-[13px] h-[13px]">
                  <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"/>
                </svg>
                <span className="material-symbols-outlined text-[14px]" style={{ fontVariationSettings: "'FILL' 1" }}>android</span>
              </div>
            </button>
          </div>

          <button className="lg:hidden text-white"><span className="material-symbols-outlined">menu</span></button>
        </div>

        <style jsx>{`
          .glow-text { text-shadow: 0 0 10px rgba(0,255,255,0.6); }
        `}</style>
      </nav>
    </>
  );
}
