"use client";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { ChatProvider } from "@/contexts/ChatContext";
import Navbar from "@/components/Navbar";

export default function ClientShell({ children }: { children: React.ReactNode }) {
  return (
    <LanguageProvider>
      <ChatProvider>
        <Navbar />
        <main className="flex-1 pt-20 pb-0">
          {children}
        </main>
      </ChatProvider>
    </LanguageProvider>
  );
}
