"use client";

import Link from "next/link";
import { useState } from "react";
import { useLogs } from "@/hooks/useLogs";

export default function HistoryPage() {
  const [filter, setFilter] = useState("all");
  const { logs } = useLogs();

  return (
    <div className="flex transparent font-body ">
      {/* Sidebar - Matching Dashboard Layout */}
      

      <main className="mx-auto max-w-7xl w-full flex-1 p-8 lg:p-12 min-h-[calc(100vh-80px)] overflow-x-hidden">
        <header className="flex justify-between items-end mb-10">
          <div>
             <p className="font-label text-xs font-bold text-primary tracking-[0.2em] uppercase mb-2">Giám sát Hoạt động</p>
             <h2 className="font-headline text-4xl font-extrabold text-white">Nhật ký Hệ thống</h2>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setFilter('all')} className={`px-4 py-2 text-sm font-bold rounded-xl transition ${filter === 'all' ? 'bg-primary text-white' : 'bg-white/5 glass-panel text-white text-slate-300 border border-white/20 hover:transparent'}`}>Tất cả</button>
            <button onClick={() => setFilter('warning')} className={`px-4 py-2 text-sm font-bold rounded-xl transition ${filter === 'warning' ? 'bg-amber-500 text-white' : 'bg-white/5 glass-panel text-white text-slate-300 border border-white/20 hover:transparent'}`}>Cảnh báo</button>
          </div>
        </header>

        <div className="bg-white/5 glass-panel text-white rounded-3xl p-8 border border-white/10 shadow-sm">
           <table className="w-full text-left">
              <thead>
                <tr className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-white/10">
                   <th className="pb-4 border-b border-white/10">Hành động</th>
                   <th className="pb-4 border-b border-white/10">Người dùng</th>
                   <th className="pb-4 border-b border-white/10">IP</th>
                   <th className="pb-4 border-b border-white/10">Thời gian</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                 {logs.filter(l => filter === 'all' ? true : l.status === filter).map(log => (
                    <tr key={log.id} className="hover:transparent/50 transition">
                       <td className="py-4 font-medium flex items-center gap-3">
                          <span className={`w-8 h-8 rounded-full flex justify-center items-center ${log.status === 'success' ? 'bg-emerald-50 text-emerald-600' : log.status === 'warning' ? 'bg-amber-50 text-amber-600' : 'bg-red-50 text-red-600'}`}>
                              <span className="material-symbols-outlined text-sm">{log.status === 'success' ? 'check' : log.status === 'warning' ? 'warning' : 'close'}</span>
                          </span>
                          {log.action}
                       </td>
                       <td className="py-4 text-sm text-slate-200 font-bold">{log.user}</td>
                       <td className="py-4 text-sm font-mono text-slate-400">{log.ip}</td>
                       <td className="py-4 text-xs font-semibold text-slate-400">{log.time}</td>
                    </tr>
                 ))}
              </tbody>
           </table>
        </div>
      </main>
    </div>
  );
}
