"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useLogs } from "@/hooks/useLogs";

interface SanPham {
  id: string;
  ten: string;
  maSKU: string;
}

interface LoHang {
  id: string;
  maLo: string;
}

interface HauKiem {
  id: string;
  doiTuongLayMau: string;
  coSoPhanTich: string;
  ngayLayMau: string;
  ngayPhanTich: string;
  ketQua: string;
  chiTieuVuotNguong: string | null;
  fileDinhKem: string | null;
  trangThaiXacMinh: string;
  ghiChu: string | null;
  ngayTao: string;
  sanPham: SanPham | null;
  loHang: LoHang | null;
}

export default function HauKiemPage() {
  const [data, setData] = useState<HauKiem[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const { addLog } = useLogs();

  const [sanPhams, setSanPhams] = useState<SanPham[]>([]);
  
  // Form states
  const [form, setForm] = useState<Record<string, any>>({
    ketQua: 'dambao',
    doiTuongLayMau: 'doanhnghiep',
  });

  const fetchData = () => {
    setLoading(true);
    fetch("/api/haukiem")
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  };

  const fetchSanPhams = () => {
    fetch("/api/inventory")
      .then(r => r.json())
      .then(d => { setSanPhams(d?.sanPhams || []); })
      .catch(e => console.error(e));
  }

  useEffect(() => { 
    fetchData();
    fetchSanPhams(); 
  }, []);

  const showToast = (msg: string, ok: boolean) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3500);
  };

  const handleSubmit = async () => {
    if (form.ngayLayMau && form.ngayPhanTich) {
      const layMauDate = new Date(form.ngayLayMau);
      const phanTichDate = new Date(form.ngayPhanTich);
      const today = new Date();
      today.setHours(0,0,0,0);
      
      if (layMauDate > today) {
        showToast("✗ Ngày lấy mẫu không thể ở tương lai", false);
        return;
      }
      if (phanTichDate < layMauDate) {
        showToast("✗ Ngày ra kết quả không thể trước ngày lấy mẫu", false);
        return;
      }
    }
    
    setSubmitting(true);
    try {
      const res = await fetch("/api/haukiem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Lỗi không xác định");
      showToast("✓ Đã thêm kết quả phân tích thành công", true);
      addLog({
        action: "Tải lên kết quả hậu kiểm",
        user: "Admin",
        ip: "10.0.0.5",
        status: form.ketQua === 'dambao' ? 'success' : 'warning'
      });
      setModal(false);
      setForm({ ketQua: 'dambao', doiTuongLayMau: 'doanhnghiep' });
      fetchData();
    } catch (e: any) {
      showToast("✗ " + e.message, false);
    } finally {
      setSubmitting(false);
    }
  };

  const doiTuongLabel = (dt: string) => {
    switch (dt) {
      case 'doanhnghiep': return 'Doanh nghiệp';
      case 'nguoitieudung': return 'Người tiêu dùng';
      case 'doituongthu3': return 'Đối tác thứ 3 / QLTT';
      default: return dt;
    }
  }

  const statusBadge = (st: string) => {
    switch (st) {
      case "verified": return <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded-full border border-emerald-200">Đã xác minh</span>;
      case "pending": return <span className="px-2 py-1 bg-amber-100 text-amber-700 text-[10px] font-bold rounded-full border border-amber-200">Chờ duyệt</span>;
      case "rejected": return <span className="px-2 py-1 bg-red-100 text-red-700 text-[10px] font-bold rounded-full border border-red-200">Từ chối</span>;
      default: return null;
    }
  }

  return (
    <div className="flex transparent font-body ">
      

      <main className="mx-auto max-w-7xl w-full flex-1 p-8 lg:p-12 overflow-x-hidden min-h-[calc(100vh-80px)] transparent">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-4">
          <div>
            <p className="font-label text-xs font-bold text-primary tracking-[0.2em] uppercase mb-2">Giám sát Chất lượng</p>
            <h1 className="font-headline text-4xl font-extrabold text-white tracking-tight">Post-Market Surveillance</h1>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setModal(true)}
              className="px-6 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:opacity-90 transition flex items-center gap-2">
              <span className="material-symbols-outlined text-sm">upload_file</span>
              Upload Kết quả Phân tích
            </button>
          </div>
        </header>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : !data.length ? (
          <div className="flex flex-col items-center justify-center h-80 bg-white/5 glass-panel text-white rounded-3xl border border-dashed border-white/20 gap-4">
            <span className="material-symbols-outlined text-5xl text-slate-300">biotech</span>
            <p className="text-slate-300 font-bold">Chưa có kết quả giám định nào</p>
            <p className="text-sm text-slate-400">Tải lên kết quả test để cập nhật hồ sơ chất lượng công khai.</p>
            <button onClick={() => setModal(true)}
              className="mt-2 px-6 py-3 bg-primary text-white rounded-xl font-bold hover:opacity-90 transition">
              + Tải lên Kết quả
            </button>
          </div>
        ) : (
          <div className="bg-white/5 glass-panel text-white rounded-3xl shadow-sm border border-white/10 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="transparent text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    <th className="px-6 py-4">Sản phẩm</th>
                    <th className="px-6 py-4">Cơ sở / Ngày Test</th>
                    <th className="px-6 py-4">Đối tượng</th>
                    <th className="px-6 py-4">Kết quả</th>
                    <th className="px-6 py-4">Xác minh</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {data.map(hk => (
                    <tr key={hk.id} className="hover:transparent/70 transition-colors">
                      <td className="px-6 py-4">
                        {hk.sanPham ? (
                          <>
                            <p className="font-bold text-sm">{hk.sanPham.ten}</p>
                            <p className="text-xs text-slate-300 font-mono mt-0.5">{hk.sanPham.maSKU}</p>
                          </>
                        ) : <p className="text-slate-400 text-sm italic">Không xác định</p>}
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm font-semibold">{hk.coSoPhanTich}</p>
                        <p className="text-xs text-slate-300 mt-0.5">{new Date(hk.ngayPhanTich).toLocaleDateString("vi-VN")}</p>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-sm text-slate-200">
                           <span className="material-symbols-outlined text-sm">{hk.doiTuongLayMau === 'nguoitieudung' ? 'person' : hk.doiTuongLayMau === 'doanhnghiep' ? 'business' : 'local_police'}</span>
                           {doiTuongLabel(hk.doiTuongLayMau)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {hk.ketQua === 'dambao' ? (
                          <div className="flex items-center gap-1 text-emerald-600 text-sm font-bold">
                            <span className="material-symbols-outlined text-sm">check_circle</span>
                            Đạt chuẩn
                          </div>
                        ) : (
                          <div className="flex flex-col items-start text-red-600 text-sm font-bold">
                            <div className="flex items-center gap-1">
                              <span className="material-symbols-outlined text-sm">warning</span>
                              Vuợt ngưỡng
                            </div>
                            <p className="text-[10px] text-red-500 font-normal mt-1 max-w-[150px]">{hk.chiTieuVuotNguong}</p>
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                         {statusBadge(hk.trangThaiXacMinh)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {modal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setModal(false)}>
          <div className="bg-white/5 glass-panel text-white rounded-3xl shadow-2xl w-full max-w-lg p-8" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold font-headline">Tải lên Kết quả Phân tích</h2>
              <button onClick={() => setModal(false)} className="text-slate-400 hover:text-slate-200">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-4 max-h-[70vh] overflow-y-auto px-1">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Sản phẩm lấy mẫu *</label>
                <select value={form.sanPhamId || ""} onChange={e => setForm(f => ({ ...f, sanPhamId: e.target.value }))}
                  className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition bg-white/5 glass-panel text-white">
                  <option value="">-- Chọn sản phẩm --</option>
                  {sanPhams.map(sp => (
                    <option key={sp.id} value={sp.id}>{sp.ten} ({sp.maSKU})</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Cơ sở phân tích *</label>
                    <input value={form.coSoPhanTich || ""} onChange={e => setForm(f => ({ ...f, coSoPhanTich: e.target.value }))}
                      className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                      placeholder="VD: Viện kiểm nghiệm quốc gia..." />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Người gửi mẫu</label>
                    <select value={form.doiTuongLayMau} onChange={e => setForm(f => ({ ...f, doiTuongLayMau: e.target.value }))}
                      className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition bg-white/5 glass-panel text-white">
                      <option value="doanhnghiep">Doanh nghiệp</option>
                      <option value="nguoitieudung">Người tiêu dùng</option>
                      <option value="doituongthu3">Quản lý thị trường</option>
                    </select>
                  </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Ngày lấy mẫu *</label>
                  <input type="date" value={form.ngayLayMau || ""} onChange={e => setForm(f => ({ ...f, ngayLayMau: e.target.value }))}
                    className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Ngày ra kết quả *</label>
                  <input type="date" value={form.ngayPhanTich || ""} onChange={e => setForm(f => ({ ...f, ngayPhanTich: e.target.value }))}
                    className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Tổng quan kết quả</label>
                <div className="flex gap-4">
                   <label className="flex items-center gap-2">
                      <input type="radio" name="ketQua" value="dambao" checked={form.ketQua === 'dambao'} onChange={e => setForm(f => ({ ...f, ketQua: e.target.value }))} />
                      <span className="text-sm font-semibold text-emerald-700">Đạt chỉ tiêu (Đảm bảo)</span>
                   </label>
                   <label className="flex items-center gap-2">
                      <input type="radio" name="ketQua" value="khongdambao" checked={form.ketQua === 'khongdambao'} onChange={e => setForm(f => ({ ...f, ketQua: e.target.value }))} />
                      <span className="text-sm font-semibold text-red-700">Vượt ngưỡng quy định</span>
                   </label>
                </div>
              </div>

              {form.ketQua === 'khongdambao' && (
                 <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Chỉ tiêu vượt ngưỡng</label>
                    <textarea value={form.chiTieuVuotNguong || ""} onChange={e => setForm(f => ({ ...f, chiTieuVuotNguong: e.target.value }))}
                      className="w-full border border-red-200 rounded-xl px-4 py-3 text-sm bg-red-50 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition resize-none"
                      rows={2} placeholder="Nêu rõ chất phân tích nào vượt ngưỡng bao nhiêu..." />
                  </div>
              )}
            </div>

            <div className="flex gap-3 mt-8">
              <button onClick={() => setModal(false)}
                className="flex-1 py-3 border border-white/20 rounded-xl text-sm font-bold text-slate-200 hover:transparent transition">
                Huỷ
              </button>
              <button onClick={handleSubmit} disabled={submitting || !form.ngayPhanTich || !form.sanPhamId || !form.coSoPhanTich}
                className="flex-1 py-3 bg-primary text-white rounded-xl text-sm font-bold hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2">
                {submitting && <span className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></span>}
                Lưu Hệ thống
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed bottom-8 right-8 z-50 px-6 py-4 rounded-2xl shadow-2xl font-bold text-sm max-w-sm transition-all ${toast.ok ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
