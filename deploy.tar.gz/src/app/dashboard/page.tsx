"use client";

import Link from "next/link";
import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import { useLanguage } from "@/contexts/LanguageContext";
import { useChat } from "@/contexts/ChatContext";
import { useLogs } from "@/hooks/useLogs";
import { MARKERS } from "@/components/GlobeCanvas";

// VietnamMap is client-only (react-simple-maps needs browser)
const VietnamMap = dynamic(() => import("@/components/VietnamMap"), { ssr: false });

// ─── AI Engine ────────────────────────────────────────────────────────────────
const RESPONSES: Array<{ match: RegExp; replies: string[] }> = [
  {
    match: /^(xin chào|hello|hi|chào|hey|alo)[\s!]*/i,
    replies: [
      "Chào bạn! 😊 Rất vui được gặp bạn hôm nay. Mình là AI của VNTrust nha — bạn cần tra serial, kiểm tra lô hàng, hay hỏi gì khác không?",
      "Hey! 👋 Mình đây. Có gì cần giúp không bạn? Nhập số serial để mình check ngay, hoặc hỏi thoải mái nhé!",
      "Chào bạn nhé, mình là AI VNTrust 🤖 Hôm nay bạn muốn mình hỗ trợ gì không?",
    ],
  },
  {
    match: /cảm ơn|thanks|thank you|ngon|tốt lắm|hay quá|giỏi/i,
    replies: [
      "Không có gì bạn ơi 😄 Giúp được bạn là mình vui rồi. Cần gì thêm cứ hỏi nha!",
      "Hehe, tất nhiên thôi! Đó là việc của mình mà 😎 Còn gì cần không?",
      "Oki! Lúc nào cũng sẵn sàng hỗ trợ bạn nhé 🙌",
    ],
  },
  {
    match: /\b([A-Z0-9]{6,})\b/i,
    replies: [], // handled separately
  },
  {
    match: /serial|mã|uid|qr|tem|quét|scan|số sê/i,
    replies: [
      "Bạn nhập thẳng số serial vào đây mình tra ngay nha! Ví dụ: EDG123456 hay gì đó tương tự 🔎",
      "Để mình giúp! Bạn gõ mã serial hoặc UID từ tem QR vào đây nhé, mình xử lý trong vài giây thôi 😊",
    ],
  },
  {
    match: /hàng giả|làm giả|giả mạo|fake|đáng ngờ|không chính hãng/i,
    replies: [
      "🚨 Ôi, nghe có vẻ nghiêm trọng đó! Bạn cho mình biết mã serial của sản phẩm được không? Mình kiểm tra ngay.\n\nHoặc nếu cần báo cáo khẩn, có thể:\n• Gọi: **1800 6789** (miễn phí 24/7)\n• Email: report@vntrust.vn\n• Bấm nút 113 trên Dashboard để báo nhanh",
      "Hmm, đáng lo đó! 😟 Bạn đang nghi ngờ sản phẩm nào? Cho mình mã serial, mình check xem có đăng ký trong hệ thống không nhé.",
    ],
  },
  {
    match: /sản phẩm|kho|lô hàng|inventory|thêm|đăng ký/i,
    replies: [
      "Để quản lý sản phẩm, bạn vào **Tài sản & Lô hàng** nhé 📦\n• Thêm sản phẩm → Hệ thống tạo mã QR ngay\n• Tạo lô hàng → Phân phối tem theo lô\n• Xem báo cáo quét realtime\n\nBạn đang cần làm bước nào?",
      "Thêm sản phẩm mới à? Dễ lắm! 😊 Vào **Kho hàng** → **Thêm sản phẩm** → Điền thông tin → Hệ thống tự sinh mã UID duy nhất. Bạn muốn mình hướng dẫn chi tiết hơn không?",
    ],
  },
  {
    match: /giá|chi phí|bao nhiêu|gói|plan|pricing|mất tiền/i,
    replies: [
      "Bạn hỏi về giá à? Mình mà tiết lộ hết thì ông chủ cho mình nghỉ mất 😄\n\nNhưng thực ra là:\n🟢 **Starter** — Miễn phí (100 SP, 500 QR/tháng)\n🔵 **Business** — 2.990.000₫/tháng (không giới hạn + AI reports)\n🟡 **Enterprise** — Liên hệ để được báo giá riêng\n\nBạn đang ở quy mô nào, mình tư vấn gói phù hợp cho?",
    ],
  },
  {
    match: /chuỗi cung ứng|supply chain|phân phối|bản đồ|logistics/i,
    replies: [
      "Chuỗi cung ứng của VNTrust hiện đang theo dõi **4,821 điểm** trên toàn quốc 🗺️\n\nBạn có thể xem realtime:\n• Luồng hàng từ nhà máy → kho → điểm bán\n• Bản đồ nhiệt cảnh báo vùng hàng giả\n• Thống kê quét theo tỉnh thành\n\nVào **Chuỗi Cung ứng** trên menu để xem nhé! Hoặc bấm vào bản đồ bên phải để chọn tỉnh 😊",
    ],
  },
  {
    match: /bảo mật|hack|xâm nhập|lộ data|an toàn/i,
    replies: [
      "Bảo mật là ưu tiên số 1 của VNTrust đó bạn! 🔐\n• Mã hóa AES-256 toàn bộ data\n• 2FA bắt buộc cho tài khoản doanh nghiệp\n• Blockchain không thể giả mạo\n• AI giám sát 24/7, phát hiện xâm nhập < 10 giây\n• Tuân thủ ISO/IEC 27001\n\nBạn muốn biết về chính sách bảo mật cụ thể nào không?",
    ],
  },
  {
    match: /app|ứng dụng|mobile|điện thoại|ios|android/i,
    replies: [
      "À, app VNTrust Mobile thì xịn lắm đó! 📱\n• Quét QR bằng camera mà không cần nhập tay\n• Nhận thông báo ngay khi phát hiện hàng giả\n• Offline mode: cache data để dùng khi mất mạng\n\n**iOS**: App Store → 'VNTrust'\n**Android**: Google Play → 'VNTrust'\n\nHoặc bấm **APP DOWNLOAD** trên thanh đầu, mình sẽ mở link tải cho bạn!",
    ],
  },
  {
    match: /xuất|báo cáo|report|pdf|csv|export/i,
    replies: [
      "Xuất báo cáo thì dễ bạn ơi! 📊 Bấm nút **EXPORT OFFLINE REPORT** ở góc phải phía trên bản đồ, AI sẽ tổng hợp và tải file CSV về máy trong vài giây.\n\nFile bao gồm:\n• Thống kê quét 30 ngày\n• Danh sách cảnh báo hàng giả\n• Phân tích theo vùng\n\nBạn cần thêm thông tin gì trong báo cáo không?",
    ],
  },
  {
    match: /liên hệ|support|hỗ trợ|hotline|điện thoại|gọi|email/i,
    replies: [
      "Bạn cần liên hệ thì mình kết nối ngay nha! 📞\n• **Hotline**: 1800 6789 (miễn phí, 24/7)\n• **Email**: support@vntrust.vn\n• **Zalo**: zalo.me/vntrust\n• **Địa chỉ**: 123 Nguyễn Huệ, Q1, TP.HCM\n\nHoặc bấm **ĐƯỜNG DÂY NÓNG 24/7** ở góc phải Dashboard, mình hiện số điện thoại theo khu vực của bạn 😊",
    ],
  },
];

const FALLBACK = [
  "Hmm, mình chưa hiểu câu đó lắm 🤔 Bạn có thể nói rõ hơn không? Hoặc nhập số serial để mình tra cứu ngay nha!",
  "Câu hỏi thú vị đó! Nhưng mình cần thêm thông tin xíu. Bạn đang hỏi về: sản phẩm cụ thể, hay về cách dùng hệ thống, hay về giá cả?",
  "Haha, mình AI thôi nên đôi khi không hiểu hết 😄 Bạn thử hỏi theo cách khác, hoặc nhập thẳng số serial để mình check nhanh nhé!",
  "Ừm... mình nghĩ bạn đang hỏi về điều gì đó rất hay, nhưng mình cần thêm context xíu. Bạn có thể nói cụ thể hơn không? 😊",
];

function getAIReply(q: string): string {
  const serialMatch = q.match(/\b([A-Z0-9]{6,})\b/i);
  if (serialMatch) {
    const s = serialMatch[1].toUpperCase();
    const found = Math.random() > 0.25;
    if (found) return `🔍 Xong rồi! Mình tìm thấy mã **${s}** trong database nhé!\n\n✅ Kết quả: **Chính hãng**\n📦 Sản phẩm: Nước mắm Phú Quốc 35N\n🏭 NSX: Công ty Thực phẩm Phú Quốc\n📅 SX: 01/03/2026 · HSD: 01/03/2028\n📍 Phân phối: Khu vực Miền Nam\n\nBạn muốn xem trang xác thực đầy đủ tại **/verify/${s}** không?`;
    return `⚠️ Ồ, mã **${s}** không có trong hệ thống đó bạn!\n\nCó thể là:\n• Sản phẩm chưa được đăng ký với VNTrust\n• Mã bị nhập sai hoặc tem hỏng\n• **Nguy hiểm: Đây có thể là hàng giả!**\n\nBạn muốn mình báo cáo sản phẩm này không? Mình kết nối với đội bảo mật ngay!`;
  }

  for (const rule of RESPONSES) {
    if (rule.replies.length > 0 && rule.match.test(q)) {
      return rule.replies[Math.floor(Math.random() * rule.replies.length)];
    }
  }
  return FALLBACK[Math.floor(Math.random() * FALLBACK.length)];
}

// ─── Modal Wrapper ────────────────────────────────────────────────────────────
function ModalWrapper({ onClose, title, icon, iconColor, children }: {
  onClose: () => void; title: string; icon: string; iconColor: string; children: React.ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div className="relative w-full max-w-md glass-panel border border-white/20 rounded-3xl p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl ${iconColor} flex items-center justify-center shrink-0`}>
              <span className="material-symbols-outlined text-white">{icon}</span>
            </div>
            <h2 className="text-lg font-black text-white font-headline">{title}</h2>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition">
            <span className="material-symbols-outlined text-white text-[18px]">close</span>
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── AI Chat Modal (full) ─────────────────────────────────────────────────────
function AiChatModal({ msgs, addMsg, onClose }: {
  msgs: {from: string, text: string}[];
  addMsg: (msg: {from: string, text: string}) => void;
  onClose: () => void;
}) {
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, typing]);

  const send = async () => {
    const q = input.trim();
    if (!q || typing) return;
    if (q.length > 500) { alert("Tin nhắn quá dài. Vui lòng nhập tối đa 500 ký tự."); return; }
    addMsg({ from: "user", text: q });
    setInput("");
    setTyping(true);

    const serial = q.replace(/<[^>]*>/g, " ").match(/\b([A-Z0-9]{6,})\b/i)?.[1];
    let reply = "";

    if (serial) {
      try {
        const res = await fetch(`/api/verify/${serial.toUpperCase()}`);
        const data = await res.json();
        if (data.status === "genuine" || data.status === "suspect" || data.status === "expired") {
          const sp = data.data?.loHang?.sanPham;
          const lo = data.data?.loHang;
          const statusText = data.status === "genuine" ? "✅ Chính hãng" : data.status === "expired" ? "⏰ Đã hết hạn" : "⚠️ Nghi ngờ làm giả";
          reply = `🔍 Xong rồi! Mình tìm thấy mã **${serial.toUpperCase()}**\n${statusText}\n📦 Sản phẩm: ${sp?.tenSanPham ?? "N/A"}\n🏭 NSX: ${sp?.doanhNghiep?.tenDoanhNghiep ?? "N/A"}\n📅 SX: ${lo?.ngaySanXuat ? new Date(lo.ngaySanXuat).toLocaleDateString("vi-VN") : "N/A"} · HSD: ${lo?.hanDung ? new Date(lo.hanDung).toLocaleDateString("vi-VN") : "N/A"}\n\nXem chi tiết tại /verify/${serial.toUpperCase()}`;
        } else {
          reply = `⚠️ Mã **${serial.toUpperCase()}** không có trong hệ thống!\n\nCó thể là:\n• Sản phẩm chưa đăng ký VNTrust\n• Mã bị nhập sai hoặc tem hỏng\n• **Nguy hiểm: Có thể là hàng giả!**`;
        }
      } catch {
        reply = "⚠️ Không thể kết nối hệ thống xác thực. Vui lòng thử lại sau.";
      }
    } else {
      reply = getAIReply(q);
    }

    setTimeout(() => { addMsg({ from: "ai", text: reply }); setTyping(false); }, 700 + Math.random() * 500);
  };


  const quickBtns = ["Cách tra mã QR?", "Báo cáo hàng giả", "Giá dịch vụ", "Liên hệ hỗ trợ", "Hướng dẫn dùng app"];

  return (
    <ModalWrapper onClose={onClose} title="Trợ lý AI VNTrust" icon="smart_toy" iconColor="bg-cyan-500">
      <div className="flex flex-col h-[480px]">
        <div className="flex-1 overflow-y-auto space-y-3 hide-scrollbar pr-1">
          {msgs.map((m, i) => (
            <div key={i} className={`flex gap-2 ${m.from === "user" ? "flex-row-reverse" : ""}`}>
              <div className={`w-7 h-7 rounded-full shrink-0 flex items-center justify-center mt-1 ${m.from === "ai" ? "bg-cyan-500" : "bg-slate-600"}`}>
                <span className="material-symbols-outlined text-white text-[13px]">{m.from === "ai" ? "smart_toy" : "person"}</span>
              </div>
              <div className={`px-4 py-2.5 rounded-2xl text-sm max-w-[82%] whitespace-pre-line leading-relaxed ${m.from === "ai" ? "bg-white/10 text-white rounded-tl-none" : "bg-cyan-500 text-white rounded-tr-none"}`}>
                {m.text}
              </div>
            </div>
          ))}
          {typing && (
            <div className="flex gap-2">
              <div className="w-7 h-7 rounded-full bg-cyan-500 flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-white text-[13px]">smart_toy</span>
              </div>
              <div className="px-4 py-3 rounded-2xl bg-white/10 flex gap-1.5 items-center">
                {[0, 150, 300].map(d => <div key={d} className="w-2 h-2 rounded-full bg-cyan-300 animate-bounce" style={{ animationDelay: `${d}ms` }} />)}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
        <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-white/10">
          {quickBtns.map(q => (
            <button key={q} onClick={() => setInput(q)}
              className="text-[10px] font-bold px-3 py-1.5 bg-white/8 rounded-full text-slate-300 hover:bg-white/15 hover:text-white transition border border-white/10">
              {q}
            </button>
          ))}
        </div>
        <div className="flex gap-2 mt-2">
          <input
            className="flex-1 bg-white/10 border border-white/20 rounded-full px-4 py-2.5 text-sm text-white placeholder:text-slate-400 outline-none focus:border-cyan-400 transition"
            placeholder="Chat với AI VNTrust..."
            value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()} />
          <button onClick={send} disabled={typing}
            className="w-10 h-10 rounded-full bg-cyan-500 flex items-center justify-center hover:bg-cyan-400 transition shrink-0 disabled:opacity-40">
            <span className="material-symbols-outlined text-white text-[18px]">send</span>
          </button>
        </div>
      </div>
    </ModalWrapper>
  );
}

// ─── Other Modals ─────────────────────────────────────────────────────────────
function ExportReportModal({ onClose }: { onClose: () => void }) {
  const [state, setState] = useState<"idle" | "loading" | "done">("idle");
  const doExport = () => {
    setState("loading");
    setTimeout(() => {
      const now = new Date().toLocaleDateString("vi-VN");
      const csv = ["BÁO CÁO VNTRUST - AI SUMMARY", `Ngày: ${now}`, "", "Chỉ số,Giá trị", "Tổng lượt quét,18.420", "Chính hãng,17.801", "Hàng giả,312", "Cảnh báo,8", "Toàn vẹn,96.7%", "", "Khu vực,Lượt quét,Hàng giả", "TP.HCM,8420,142", "Hà Nội,5210,98", "Bình Dương,2340,44", "Đà Nẵng,1580,28"].join("\n");
      const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
      const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: `VNTrust_BaoCao_${now.replace(/\//g, "-")}.csv` });
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setState("done");
    }, 2000);
  };
  return (
    <ModalWrapper onClose={onClose} title="Xuất Báo cáo AI" icon="summarize" iconColor="bg-violet-500">
      <div className="space-y-3 mb-5">
        {["Tóm tắt hoạt động 30 ngày", "Danh sách cảnh báo hàng giả", "Phân tích theo vùng", "Đánh giá rủi ro AI"].map(i => (
          <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/10">
            <span className="material-symbols-outlined text-emerald-400 text-[18px]">check_circle</span>
            <span className="text-sm text-slate-200">{i}</span>
          </div>
        ))}
      </div>
      {state === "done" ? (
        <div className="text-center p-4 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl">
          <span className="material-symbols-outlined text-4xl text-emerald-400">task_alt</span>
          <p className="text-emerald-400 font-bold mt-1">File CSV đã được tải về máy!</p>
          <button onClick={doExport} className="mt-2 text-xs text-cyan-400 underline">Tải lại</button>
        </div>
      ) : (
        <button onClick={doExport} disabled={state === "loading"}
          className="w-full flex items-center justify-center gap-2 py-3 bg-violet-500 hover:bg-violet-400 rounded-xl text-white font-bold text-sm transition disabled:opacity-70">
          {state === "loading" ? <><span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Đang tạo báo cáo AI...</> : <><span className="material-symbols-outlined text-[18px]">download</span> Xuất CSV</>}
        </button>
      )}
    </ModalWrapper>
  );
}

function SecurityModal({ onClose }: { onClose: () => void }) {
  return (
    <ModalWrapper onClose={onClose} title="Chuyên gia Bảo mật" icon="shield_person" iconColor="bg-emerald-500">
      <div className="space-y-3 mb-5">
        {[{ name: "Nguyễn Văn An", role: "Chuyên gia chống giả cấp cao", status: "online" }, { name: "Trần Thị Bình", role: "Phân tích chuỗi cung ứng", status: "online" }, { name: "Lê Minh Cường", role: "Kỹ thuật xác thực AI", status: "busy" }].map((ex, i) => (
          <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition cursor-pointer">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-white text-[18px]">person</span>
            </div>
            <div className="flex-1"><p className="font-bold text-white text-sm">{ex.name}</p><p className="text-[10px] text-slate-400">{ex.role}</p></div>
            <span className={`w-2.5 h-2.5 rounded-full ${ex.status === "online" ? "bg-emerald-400" : "bg-amber-400"}`}></span>
          </div>
        ))}
      </div>
      <Link href="/dashboard/security" onClick={onClose} className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-500/20 border border-emerald-500/30 rounded-xl text-emerald-400 font-bold text-sm hover:bg-emerald-500/30 transition">
        <span className="material-symbols-outlined text-[18px]">security</span> Mở trang Bảo mật
      </Link>
    </ModalWrapper>
  );
}

function HotlineModal({ onClose }: { onClose: () => void }) {
  return (
    <ModalWrapper onClose={onClose} title="Đường dây Nóng 24/7" icon="call" iconColor="bg-cyan-500">
      <div className="space-y-3 mb-4">
        {[{ area: "TP. Hồ Chí Minh", number: "1800 6789", online: true }, { area: "Hà Nội", number: "1800 1234", online: true }, { area: "Đà Nẵng & Miền Trung", number: "1800 4567", online: false }, { area: "Cần Thơ & Tây Nam Bộ", number: "1900 8888", online: true }].map((h, i) => (
          <a key={i} href={`tel:${h.number.replace(/\s/g, "")}`} className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-cyan-400/40 transition group">
            <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center group-hover:bg-cyan-500 transition shrink-0">
              <span className="material-symbols-outlined text-cyan-400 group-hover:text-white text-[18px]">phone_in_talk</span>
            </div>
            <div className="flex-1"><p className="text-[10px] text-slate-400">{h.area}</p><p className="font-black text-white font-headline">{h.number}</p></div>
            <span className={`text-[9px] font-bold px-2 py-1 rounded-full border ${h.online ? "text-emerald-400 bg-emerald-500/15 border-emerald-500/20" : "text-slate-400 bg-white/5 border-white/10"}`}>{h.online ? "ONLINE" : "Offline"}</span>
          </a>
        ))}
      </div>
      <p className="text-center text-xs text-slate-500">Miễn phí · 24 giờ · 7 ngày / tuần</p>
    </ModalWrapper>
  );
}

function MapDetailModal({ marker, onClose }: { marker: typeof MARKERS[0]; onClose: () => void }) {
  const { t } = useLanguage();
  const typeLabel = marker.type === "hot" ? t("sc_hotspot") : marker.type === "warning" ? t("sc_tracking") : t("sc_normal");
  const typeColor = marker.type === "hot" ? "text-amber-400" : marker.type === "warning" ? "text-orange-400" : "text-emerald-400";
  const typeBg = marker.type === "hot" ? "bg-amber-500/10 border-amber-500/30" : marker.type === "warning" ? "bg-orange-500/10 border-orange-500/30" : "bg-emerald-500/10 border-emerald-500/30";
  return (
    <ModalWrapper onClose={onClose} title={marker.name} icon="language" iconColor={marker.type === 'hot' ? 'bg-amber-500' : marker.type === 'warning' ? 'bg-orange-500' : 'bg-emerald-500'}>
      <p className="text-slate-400 text-xs mb-4 flex items-center gap-2">
        <span className="material-symbols-outlined text-[14px]">location_on</span> {marker.country}
        <span className={`ml-auto font-bold text-[10px] px-2 py-0.5 rounded-full border ${typeBg} ${typeColor}`}>{typeLabel}</span>
      </p>
      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="bg-white/5 rounded-2xl p-4 text-center border border-white/10">
          <p className="text-xl font-black text-cyan-400">{marker.scans.toLocaleString()}</p>
          <p className="text-[9px] text-slate-400 mt-1">Lượt quét</p>
        </div>
        <div className="bg-white/5 rounded-2xl p-4 text-center border border-white/10">
          <p className={`text-xl font-black ${marker.fake > 0 ? "text-amber-400" : "text-emerald-400"}`}>{marker.fake}</p>
          <p className="text-[9px] text-slate-400 mt-1">Hàng giả</p>
        </div>
        <div className="bg-white/5 rounded-2xl p-4 text-center border border-white/10">
          <p className="text-xl font-black text-blue-300">{((marker.scans - marker.fake) / marker.scans * 100).toFixed(1)}%</p>
          <p className="text-[9px] text-slate-400 mt-1">Toàn vẹn</p>
        </div>
      </div>
      {marker.fake > 0 && (
        <div className={`p-4 ${typeBg} border rounded-2xl mb-4`}>
          <p className={`${typeColor} font-bold text-sm flex items-center gap-2`}>
            <span className="material-symbols-outlined text-[18px]">warning</span> Cảnh báo hàng giả
          </p>
          <p className="text-slate-300 text-xs mt-1">Phát hiện {marker.fake} sản phẩm nghi vấn tại <strong>{marker.name}</strong> trong 30 ngày qua.</p>
        </div>
      )}
      <Link href="/supply-chain" onClick={onClose} className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-500/20 border border-emerald-500/30 rounded-xl text-emerald-400 font-bold text-sm hover:bg-emerald-500/30 transition">
        <span className="material-symbols-outlined text-[18px]">open_in_new</span> Mở bản đồ phân phối
      </Link>
    </ModalWrapper>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────
type ModalType = "ai" | "report" | "security" | "hotline" | null;

export default function Dashboard() {
  const [mounted, setMounted] = useState(false);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [modal, setModal] = useState<ModalType>(null);
  const [globeMarker, setGlobeMarker] = useState<typeof MARKERS[0] | null>(null);
  const [searchVal, setSearchVal] = useState("");
  const [searchActive, setSearchActive] = useState(false);
  const { msgs: chatMsgs, addMsg: addChatMsg } = useChat();
  const { t } = useLanguage();
  const router = useRouter();
  const { logs } = useLogs();

  useEffect(() => { 
    const role = localStorage.getItem("userRole");
    if (!role) {
      router.push("/login");
    } else {
      setUserRole(role);
      setMounted(true); 
    }
  }, [router]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchVal.trim()) router.push(`/verify/${searchVal.trim()}`);
  };

  if (!mounted || !userRole) return null;

  return (
    <>
      {modal === "ai"       && <AiChatModal      msgs={chatMsgs} addMsg={addChatMsg} onClose={() => setModal(null)} />}
      {modal === "report"   && <ExportReportModal onClose={() => setModal(null)} />}
      {modal === "security" && <SecurityModal     onClose={() => setModal(null)} />}
      {modal === "hotline"  && <HotlineModal      onClose={() => setModal(null)} />}
      {globeMarker          && <MapDetailModal    marker={globeMarker} onClose={() => setGlobeMarker(null)} />}

      <div className="min-h-[calc(100vh-80px)] w-full relative overflow-hidden flex flex-col p-4 md:p-8 xl:p-12 mb-16 max-w-[1600px] mx-auto">
        <div className="absolute top-10 right-0 w-[800px] h-[800px] rounded-full pointer-events-none z-0"
             style={{ background: "radial-gradient(circle at 30% 30%, rgba(60,200,200,0.25) 0%, rgba(20,100,150,0.1) 40%, transparent 70%)", filter: "blur(60px)", transform: "translate(20%,-10%)" }} />

        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 lg:gap-12 relative z-10 w-full h-full flex-1">

          {/* ── LEFT ── */}
          <div className="xl:col-span-6 flex flex-col gap-6">
            {/* Search */}
            <form onSubmit={handleSearch}
              className={`glass-panel rounded-full p-2 pl-6 flex items-center justify-between border shadow-lg bg-white/5 transition-all ${searchActive ? "border-cyan-400/60" : "border-white/20"}`}>
              <div className="flex items-center gap-4 flex-1">
                <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center pulse-ai shrink-0">
                  <span className="material-symbols-outlined text-cyan-400">robot_2</span>
                </div>
                {searchActive || searchVal ? (
                  <input autoFocus value={searchVal} onChange={e => setSearchVal(e.target.value)}
                    onBlur={() => { if (!searchVal) setSearchActive(false); }}
                    placeholder={t("search_ph")}
                    className="bg-transparent outline-none text-white text-sm w-full placeholder:text-slate-400" />
                ) : (
                  <div onClick={() => setSearchActive(true)} className="cursor-text flex-1">
                    <div className="text-white font-bold text-sm tracking-wide">{t("search_title")}</div>
                    <div className="text-xs text-slate-400">{t("search_sub")}</div>
                  </div>
                )}
              </div>
              <button type="submit" className="w-12 h-12 rounded-full bg-cyan-500 hover:bg-cyan-400 flex items-center justify-center transition shrink-0">
                <span className="material-symbols-outlined text-white">search</span>
              </button>
            </form>

            {/* App Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(userRole === 'admin' || userRole === 'manufacturer' || userRole === 'importer') && (
                <Link href="/dashboard/inventory" className="glass-card rounded-3xl p-5 flex flex-col justify-between h-40 group relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="flex gap-2 mb-2"><span className="material-symbols-outlined text-3xl text-cyan-300">inventory_2</span><span className="material-symbols-outlined text-3xl text-blue-300">apparel</span></div>
                  <div><p className="text-[10px] text-slate-300 border-b border-white/10 pb-1 mb-1">{t("app_inv_sub")}</p><h3 className="text-sm font-bold text-white">{t("app_inv")}</h3></div>
                </Link>
              )}

              {(userRole === 'admin' || userRole === 'importer') && (
                <Link href="/supply-chain" className="glass-card rounded-3xl p-5 flex flex-col justify-between h-40 group relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="flex gap-2 mb-2"><span className="material-symbols-outlined text-3xl text-emerald-300">insights</span><span className="material-symbols-outlined text-3xl text-green-300">route</span></div>
                  <div><p className="text-[10px] text-slate-300 border-b border-white/10 pb-1 mb-1">{t("app_sc_sub")}</p><h3 className="text-sm font-bold text-white">{t("app_sc")}</h3></div>
                </Link>
              )}

              {(userRole === 'admin' || userRole === 'consumer' || userRole === 'manufacturer') && (
                <Link href="/verify" className="glass-card rounded-3xl p-5 flex flex-col h-40 group border border-amber-300/30 bg-amber-900/20">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[11px] font-bold text-amber-200">{t("app_verify_sub")}</span>
                    <div className="bg-gradient-to-b from-yellow-300 to-amber-500 rounded p-1 shadow-lg shadow-amber-500/50"><span className="material-symbols-outlined text-white text-md">star</span></div>
                  </div>
                  <div className="flex gap-[6px]">
                    <div title="Quét Mã QR" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center"><span className="material-symbols-outlined text-white text-[20px]">qr_code_scanner</span></div>
                    <div title="Quét Mã Vạch" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center"><span className="material-symbols-outlined text-white text-[20px]">barcode_reader</span></div>
                    <div title="Nhập Serial" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center"><span className="material-symbols-outlined text-white text-[20px]">pin</span></div>
                    <div title="AI Giấy tờ" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center"><span className="material-symbols-outlined text-white text-[20px]">document_scanner</span></div>
                  </div>
                  <h3 className="text-sm font-bold text-white mt-auto text-center">{t("app_verify")}</h3>
                </Link>
              )}

              {userRole === 'admin' && (
                <Link href="/dashboard/haukiem" className="glass-card rounded-3xl p-5 flex flex-col justify-between h-32 group">
                  <span className="material-symbols-outlined text-4xl text-blue-400">biotech</span>
                  <h3 className="text-sm font-bold text-white uppercase text-center border-t border-white/10 pt-2">{t("app_hk")}</h3>
                </Link>
              )}

              <Link href="/dashboard/history" className="glass-card rounded-3xl p-5 flex flex-col justify-between h-32 group">
                <span className="material-symbols-outlined text-4xl text-slate-300">history</span>
                <h3 className="text-sm font-bold text-white uppercase text-center border-t border-white/10 pt-2">{t("app_hist")}</h3>
              </Link>

              {(userRole === 'admin' || userRole === 'consumer') && (
                <div className="glass-card rounded-3xl p-4 flex flex-col justify-between h-32 bg-red-900/20 border-red-500/30">
                  <div className="flex gap-2">
                    <a href="tel:113" className="flex-1 bg-red-500/20 rounded-xl p-2 text-center border border-red-500/30 hover:bg-red-500/40 transition"><p className="text-[9px] font-bold text-red-200">CẢNH BÁO</p><p className="text-lg font-black text-white">113</p></a>
                    <a href="tel:1900" className="flex-1 bg-orange-500/20 rounded-xl p-2 text-center border border-orange-500/30 hover:bg-orange-500/40 transition"><p className="text-[9px] font-bold text-orange-200">HỖ TRỢ</p><p className="text-lg font-black text-white">1900</p></a>
                  </div>
                  <h3 className="text-sm font-bold text-white uppercase text-center border-t border-red-500/20 pt-2">{t("app_emg")}</h3>
                </div>
              )}
            </div>

            {/* Recent */}
            <div className="mt-2">
              <h2 className="text-lg font-headline font-bold text-white mb-4 tracking-widest uppercase">{t("recent")}</h2>
              <div className="flex gap-4 overflow-x-auto snap-x hide-scrollbar pb-4">
                {logs.slice(0, 2).map((log, i) => (
                  <Link href="/dashboard/history" key={i} className="snap-start shrink-0 w-72 glass-card rounded-2xl overflow-hidden group cursor-pointer h-40 flex flex-col justify-end relative">
                    <div className={`absolute inset-0 bg-gradient-to-t ${log.status === 'success' ? 'from-black/80 via-black/30' : log.status === 'warning' ? 'from-black/80 via-amber-900/40' : 'from-red-900/90 via-red-900/40'} to-transparent z-10`} />
                    <img src={log.status === 'success' ? "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=600&q=80" : "https://images.unsplash.com/photo-1542282088-fe8426682b8f?auto=format&fit=crop&w=600&q=80"} alt="bg" className={`absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ${log.status === 'error' ? 'grayscale' : ''}`} />
                    <div className="relative z-20 p-4">
                      <span className={`px-2 py-1 ${log.status === 'success' ? 'bg-emerald-500' : log.status === 'warning' ? 'bg-amber-500' : 'bg-red-600'} text-white text-[9px] font-black rounded mb-2 inline-block ${log.status === 'error' ? 'animate-pulse' : ''}`}>
                        {log.status === 'success' ? 'THÀNH CÔNG' : log.status === 'warning' ? 'CẢNH BÁO' : 'NGUY HIỂM'}
                      </span>
                      <h4 className="text-sm font-bold text-white uppercase line-clamp-1">{log.action}</h4>
                      <p className="text-xs text-slate-300">{log.user} • {log.ip}</p>
                    </div>
                  </Link>
                ))}
                <Link href="/dashboard/history" className="snap-start shrink-0 w-16 glass-card rounded-2xl flex items-center justify-center hover:bg-white/10 transition">
                  <span className="material-symbols-outlined text-white">chevron_right</span>
                </Link>
              </div>
            </div>
          </div>

          {/* ── RIGHT — Globe ── */}
          <div className="xl:col-span-6 relative flex flex-col justify-between h-full min-h-[640px]">
            {/* Header */}
            <div className="absolute top-3 left-4 z-20 flex gap-2 items-center">
              <span className="text-white text-xl font-headline font-bold">{t("map_title")}</span>
              <div className="w-12 h-px bg-cyan-400 mt-0.5 relative"><div className="absolute right-0 -top-1 w-2 h-2 rotate-45 border-r border-t border-cyan-400" /></div>
            </div>

            {/* Legend */}
            <div className="absolute top-10 left-4 z-20 flex flex-col gap-1">
              {[
                { color: "bg-amber-400", label: t("sc_hotspot") },
                { color: "bg-orange-500", label: t("sc_tracking") },
                { color: "bg-cyan-400",   label: t("sc_normal") },
              ].map(l => (
                <div key={l.label} className="flex items-center gap-1.5">
                  <div className={`w-2 h-2 rounded-full ${l.color}`} />
                  <span className="text-[9px] text-slate-400">{l.label}</span>
                </div>
              ))}
            </div>

            {/* Map buttons */}
            <div className="absolute top-3 right-4 z-20 flex flex-col gap-2">

              <button onClick={() => setModal("report")}
                className="glass-panel px-3 py-2 rounded-xl text-[10px] font-bold text-slate-200 hover:bg-white/10 transition text-left cursor-pointer active:scale-95">
                {t("sc_export")}<br /><span className="text-[9px] text-slate-500">(AI Summary)</span>
              </button>

              <button onClick={() => { localStorage.removeItem("userRole"); router.push("/login"); }}
                className="glass-panel px-3 py-2 rounded-xl text-[10px] font-bold text-rose-400 hover:bg-rose-500/20 border-rose-500/20 transition flex items-center justify-center gap-1 cursor-pointer active:scale-95 mt-2">
                <span className="material-symbols-outlined text-[14px]">logout</span> Đăng xuất
              </button>
            </div>

            {/* Vietnam SVG Map — full height */}
            <div className="absolute inset-0 z-10">
              <VietnamMap onMarkerClick={(m) => setGlobeMarker(m)} />
            </div>



            {/* Bottom section */}
            <div className="mt-auto relative z-20 flex justify-between items-end w-full pb-4">
              <div className="w-80 space-y-4 pt-12">
                <h3 className="text-white font-bold tracking-widest text-sm mb-2">{t("sec_title")}</h3>
                <button onClick={() => setModal("security")}
                  className="glass-card rounded-2xl p-4 flex gap-4 cursor-pointer group w-full text-left hover:border-emerald-400/40 transition">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition shrink-0">
                    <span className="material-symbols-outlined">shield_person</span>
                  </div>
                  <div><h4 className="text-[11px] font-bold text-white">{t("sec_team")}</h4><p className="text-[10px] text-slate-400">{t("sec_team_sub")}</p></div>
                </button>
                <button onClick={() => setModal("hotline")}
                  className="glass-card rounded-2xl p-4 flex gap-4 cursor-pointer group w-full text-left hover:border-cyan-400/40 transition">
                  <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:bg-cyan-500 group-hover:text-white transition shrink-0">
                    <span className="material-symbols-outlined">call</span>
                  </div>
                  <div><h4 className="text-[11px] font-bold text-white">{t("sec_hotline")}</h4><p className="text-[10px] text-slate-400">{t("sec_hotline_sub")}</p></div>
                </button>
              </div>

              <button onClick={() => setModal("ai")}
                className="glass-panel px-6 py-3 rounded-full flex items-center gap-3 text-sm font-bold text-white hover:bg-white/20 transition hover:scale-105 active:scale-95 z-30">
                <div className="w-6 h-6 rounded-full bg-cyan-500 flex items-center justify-center">
                  <span className="material-symbols-outlined text-[14px]">smart_toy</span>
                </div>
                {t("ai_btn")}
                <span className="material-symbols-outlined text-[18px]">chevron_right</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
