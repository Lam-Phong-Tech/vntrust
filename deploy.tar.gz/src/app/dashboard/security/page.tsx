"use client";

import Link from "next/link";
import { useState } from "react";

export default function SecurityPage() {
  const [mfa, setMfa] = useState(true);

  return (
    <div className="flex transparent font-body ">
      

      <main className="mx-auto max-w-7xl w-full flex-1 p-8 lg:p-12 min-h-[calc(100vh-80px)] overflow-x-hidden">
        <header className="mb-10">
          <p className="font-label text-xs font-bold text-primary tracking-[0.2em] uppercase mb-2">Quản trị Hệ thống</p>
          <h2 className="font-headline text-4xl font-extrabold text-white">Cài đặt Bảo mật</h2>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
           <div className="bg-white/5 glass-panel text-white rounded-3xl p-8 border border-white/10 shadow-sm flex flex-col items-start gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                 <span className="material-symbols-outlined text-primary">key</span>
              </div>
              <h3 className="text-xl font-bold font-headline mt-2">Xác thực Hai yếu tố (2FA)</h3>
              <p className="text-slate-300 text-sm">Tăng cường tính bảo mật của tài khoản với mã OTP từ Google Authenticator hoặc SMS.</p>
              
              <div className="mt-4 flex items-center gap-3">
                 <button 
                  onClick={() => setMfa(!mfa)} 
                  className={`relative w-12 h-6 rounded-full transition-colors ${mfa ? 'bg-primary' : 'bg-slate-200'}`}
                 >
                    <span className={`absolute top-1 left-1 bg-white/5 glass-panel text-white w-4 h-4 rounded-full transition-transform ${mfa ? 'translate-x-6' : 'translate-x-0'}`}></span>
                 </button>
                 <span className="font-bold text-sm">{mfa ? "Đang Bật" : "Đã Tắt"}</span>
              </div>
           </div>

           <div className="bg-white/5 glass-panel text-white rounded-3xl p-8 border border-white/10 shadow-sm flex flex-col items-start gap-4">
              <div className="w-12 h-12 bg-rose-100 rounded-2xl flex items-center justify-center">
                 <span className="material-symbols-outlined text-rose-600">password</span>
              </div>
              <h3 className="text-xl font-bold font-headline mt-2">Đổi mật khẩu</h3>
              <p className="text-slate-300 text-sm">Nên thay đổi mật khẩu định kỳ 3 tháng một lần để đảm bảo an toàn tuyệt đối cho DApp.</p>
              
              <button 
                className="mt-4 px-6 py-2 bg-white/10 hover:bg-slate-200 text-slate-800 font-bold text-sm rounded-xl transition"
                onClick={() => alert("Chức năng đang được tích hợp cùng hệ thống SSO.")}
              >
                Cập nhật Ngay
              </button>
           </div>
        </div>
      </main>
    </div>
  );
}
