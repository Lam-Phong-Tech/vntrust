"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useLogs } from "@/hooks/useLogs";

interface SanPham {
  id: string;
  maSKU: string;
  ten: string;
  moTa: string | null;
  nuocSanXuat: string | null;
  ngayTao: string;
  loHangs: {
    id: string;
    maLo: string;
    ngaySanXuat: string;
    hanDung: string;
    soLuong: number;
    trangThai: string;
    _count: { uids: number };
  }[];
  _count: { loHangs: number };
}

interface InvData {
  doanhNghiep: { id: string; ten: string };
  sanPhams: SanPham[];
}

export default function InventoryPage() {
  const [data, setData] = useState<InvData | null>(null);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<"product" | "batch" | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const { addLog } = useLogs();

  // Form states
  const [form, setForm] = useState<Record<string, string>>({});

  const fetchData = () => {
    setLoading(true);
    fetch("/api/inventory")
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => { fetchData(); }, []);

  const showToast = (msg: string, ok: boolean) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3500);
  };

  const handleSubmit = async (type: "product" | "batch") => {
    if (type === "batch") {
      if (!selectedProduct) {
        showToast("✗ Vui lòng chọn sản phẩm", false);
        return;
      }
      const { ngaySanXuat, hanDung, soLuong } = form;
      if (!ngaySanXuat || !hanDung || !soLuong) {
        showToast("✗ Vui lòng điền đầy đủ thông tin", false);
        return;
      }
      const sxDate = new Date(ngaySanXuat);
      const hdDate = new Date(hanDung);
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      if (sxDate.getFullYear() < 2000) {
        showToast("✗ Ngày sản xuất không hợp lệ", false);
        return;
      }
      if (sxDate > hdDate) {
        showToast("✗ Ngày sản xuất không được lớn hơn hạn sử dụng", false);
        return;
      }
      if (sxDate > today) {
        showToast("✗ Ngày sản xuất không thể ở tương lai", false);
        return;
      }
      const qty = Number(soLuong);
      if (!Number.isInteger(qty) || qty <= 0) {
        showToast("✗ Số lượng phải là số nguyên dương", false);
        return;
      }
      if (qty > 10000) {
        showToast("✗ Số lượng không được vượt quá 10,000", false);
        return;
      }
    }

    setSubmitting(true);
    const body: Record<string, string> = { type, ...form };
    if (type === "batch") body.sanPhamId = selectedProduct;

    try {
      const res = await fetch("/api/inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Lỗi không xác định");
      showToast(type === "product" ? `✓ Đã thêm sản phẩm: ${json.sanPham.ten}` : `✓ Đã tạo lô ${json.loHang.maLo} với ${json.totalUids} tem QR`, true);
      addLog({
        action: type === 'product' ? `Tạo sản phẩm: ${json.sanPham.ten}` : `Tạo lô hàng ${json.loHang.maLo}`,
        user: "Admin",
        ip: "10.0.0.5",
        status: "success"
      });
      setModal(null);
      setForm({});
      fetchData();
    } catch (e: any) {
      showToast("✗ " + e.message, false);
    } finally {
      setSubmitting(false);
    }
  };

  const seedDB = async () => {
    setSubmitting(true);
    const res = await fetch("/api/seed");
    const json = await res.json();
    if (json.doanhNghiep) showToast("✓ Database đã khởi tạo dữ liệu mẫu", true);
    else showToast("ℹ " + (json.message || json.error), true);
    fetchData();
    setSubmitting(false);
  };

  return (
    <div className="flex transparent font-body ">
      
      

      
      <main className="mx-auto max-w-7xl w-full flex-1 p-8 lg:p-12 overflow-x-hidden min-h-[calc(100vh-80px)] transparent">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-4">
          <div>
            <p className="font-label text-xs font-bold text-primary tracking-[0.2em] uppercase mb-2">Quản lý Kho hàng</p>
            <h1 className="font-headline text-4xl font-extrabold text-white tracking-tight">Sản phẩm & Lô hàng</h1>
          </div>
          <div className="flex gap-3">
            <button onClick={seedDB} disabled={submitting}
              className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-bold text-slate-200 hover:bg-white/5 glass-panel text-white transition flex items-center gap-2">
              <span className="material-symbols-outlined text-sm">database</span>
              Khởi tạo dữ liệu mẫu
            </button>
            <button onClick={() => setModal("product")}
              className="px-6 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:opacity-90 transition flex items-center gap-2">
              <span className="material-symbols-outlined text-sm">add</span>
              Sản phẩm mới
            </button>
          </div>
        </header>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : !data?.sanPhams?.length ? (
          <div className="flex flex-col items-center justify-center h-80 bg-white/5 glass-panel text-white rounded-3xl border border-dashed border-white/20 gap-4">
            <span className="material-symbols-outlined text-5xl text-slate-300">inventory_2</span>
            <p className="text-slate-300 font-bold">Chưa có sản phẩm nào</p>
            <p className="text-sm text-slate-400">Nhấn "Sản phẩm mới" để thêm, hoặc "Khởi tạo dữ liệu mẫu" nếu lần đầu dùng.</p>
            <button onClick={() => setModal("product")}
              className="mt-2 px-6 py-3 bg-primary text-white rounded-xl font-bold hover:opacity-90 transition">
              + Thêm sản phẩm đầu tiên
            </button>
          </div>
        ) : (
          <div className="space-y-8">
            {data.sanPhams.map(sp => (
              <div key={sp.id} className="bg-white/5 glass-panel text-white rounded-3xl shadow-sm border border-white/10 overflow-hidden">
                {/* Product header */}
                <div className="p-6 border-b border-white/10 flex justify-between items-start">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <span className="material-symbols-outlined text-primary">inventory_2</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg text-white font-headline">{sp.ten}</h3>
                      <p className="text-sm text-slate-300">SKU: <span className="font-mono">{sp.maSKU}</span> · {sp.nuocSanXuat || "N/A"}</p>
                      {sp.moTa && <p className="text-xs text-slate-400 mt-0.5">{sp.moTa}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-bold">
                      {sp._count.loHangs} lô hàng
                    </span>
                    <button onClick={() => { setSelectedProduct(sp.id); setModal("batch"); }}
                      className="px-4 py-2 bg-white/10 hover:bg-slate-200 rounded-lg text-sm font-bold text-white transition flex items-center gap-2">
                      <span className="material-symbols-outlined text-sm">add_box</span>
                      Thêm lô hàng
                    </button>
                  </div>
                </div>
                {/* Batch list */}
                {sp.loHangs.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-sm">Chưa có lô hàng nào. Thêm lô hàng để tạo tem QR.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="transparent text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                          <th className="px-6 py-3">Mã lô</th>
                          <th className="px-6 py-3">Ngày SX</th>
                          <th className="px-6 py-3">Hạn dùng</th>
                          <th className="px-6 py-3">Số lượng</th>
                          <th className="px-6 py-3">Tem QR</th>
                          <th className="px-6 py-3">Trạng thái</th>
                          <th className="px-6 py-3 text-right">Thao tác</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {sp.loHangs.map(lo => {
                          const expired = new Date(lo.hanDung) < new Date();
                          return (
                            <tr key={lo.id} className="hover:transparent/70 transition-colors">
                              <td className="px-6 py-4 font-mono text-sm font-bold">{lo.maLo}</td>
                              <td className="px-6 py-4 text-sm">{new Date(lo.ngaySanXuat).toLocaleDateString("vi-VN")}</td>
                              <td className={`px-6 py-4 text-sm font-bold ${expired ? "text-red-500" : "text-green-700"}`}>
                                {new Date(lo.hanDung).toLocaleDateString("vi-VN")}
                                {expired && <span className="ml-1 text-[10px]">(Hết hạn)</span>}
                              </td>
                              <td className="px-6 py-4 text-sm">{lo.soLuong.toLocaleString()}</td>
                              <td className="px-6 py-4">
                                <span className="px-2 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-bold">
                                  {lo._count.uids} tem
                                </span>
                              </td>
                              <td className="px-6 py-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-bold ${expired ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-700"}`}>
                                  {expired ? "Hết hạn" : "Đang hoạt động"}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                <Link href={`/dashboard/inventory/${lo.id}/qr`}
                                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-primary text-white text-xs font-bold rounded-lg hover:opacity-90 transition">
                                  <span className="material-symbols-outlined text-sm">qr_code</span>
                                  Xem & In tem
                                </Link>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Modal */}
      {modal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setModal(null)}>
          <div className="bg-white/5 glass-panel text-white rounded-3xl shadow-2xl w-full max-w-md p-8" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold font-headline">
                {modal === "product" ? "Thêm Sản phẩm mới" : "Thêm Lô hàng mới"}
              </h2>
              <button onClick={() => setModal(null)} className="text-slate-400 hover:text-slate-200">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-4">
              {modal === "product" ? (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Tên sản phẩm *</label>
                    <input value={form.ten || ""} onChange={e => setForm(f => ({ ...f, ten: e.target.value }))}
                      className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                      placeholder="VD: Nước mắm Phú Quốc 35N" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Mô tả</label>
                    <textarea value={form.moTa || ""} onChange={e => setForm(f => ({ ...f, moTa: e.target.value }))}
                      className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition resize-none"
                      rows={3} placeholder="Mô tả ngắn về sản phẩm..." />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">GTIN/Barcode</label>
                      <input value={form.GTIN || ""} onChange={e => setForm(f => ({ ...f, GTIN: e.target.value }))}
                        className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                        placeholder="893xxxxxx" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Nước SX</label>
                      <input value={form.nuocSanXuat || ""} onChange={e => setForm(f => ({ ...f, nuocSanXuat: e.target.value }))}
                        className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                        placeholder="Việt Nam" />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Sản phẩm *</label>
                    <select value={selectedProduct} onChange={e => setSelectedProduct(e.target.value)}
                      className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition bg-white/5 glass-panel text-white">
                      <option value="">-- Chọn sản phẩm --</option>
                      {data?.sanPhams.map(sp => (
                        <option key={sp.id} value={sp.id}>{sp.ten} ({sp.maSKU})</option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Ngày SX *</label>
                      <input type="date" value={form.ngaySanXuat || ""} onChange={e => setForm(f => ({ ...f, ngaySanXuat: e.target.value }))}
                        className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Hạn dùng *</label>
                      <input type="date" value={form.hanDung || ""} onChange={e => setForm(f => ({ ...f, hanDung: e.target.value }))}
                        className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">Số lượng sản phẩm *</label>
                    <input type="number" min="1" max="10000" value={form.soLuong || ""} onChange={e => setForm(f => ({ ...f, soLuong: e.target.value }))}
                      className="w-full border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                      placeholder="VD: 500" />
                    <p className="text-xs text-slate-400 mt-1">Hệ thống sẽ tự động tạo tem QR tương ứng</p>
                  </div>
                </>
              )}
            </div>

            <div className="flex gap-3 mt-8">
              <button onClick={() => setModal(null)}
                className="flex-1 py-3 border border-white/20 rounded-xl text-sm font-bold text-slate-200 hover:transparent transition">
                Huỷ
              </button>
              <button onClick={() => handleSubmit(modal)} disabled={submitting}
                className="flex-1 py-3 bg-primary text-white rounded-xl text-sm font-bold hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2">
                {submitting && <span className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></span>}
                {modal === "product" ? "Tạo Sản phẩm" : "Tạo Lô hàng & In tem"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-8 right-8 z-50 px-6 py-4 rounded-2xl shadow-2xl font-bold text-sm max-w-sm transition-all ${toast.ok ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
