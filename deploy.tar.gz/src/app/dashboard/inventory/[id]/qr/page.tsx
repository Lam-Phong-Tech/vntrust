"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { QRCodeSVG } from "qrcode.react";

interface BatchData {
  id: string;
  maLo: string;
  ngaySanXuat: string;
  hanDung: string;
  soLuong: number;
  trangThai: string;
  sanPham: {
    ten: string;
    maSKU: string;
    doanhNghiep: { ten: string };
  };
  uids: { uid: string; trangThai: string; soLanQuet: number }[];
}

export default function QRPrintPage() {
  const { id } = useParams();
  const [batch, setBatch] = useState<BatchData | null>(null);
  const [loading, setLoading] = useState(true);
  const [printMode, setPrintMode] = useState(false);

  useEffect(() => {
    fetch(`/api/inventory/${id}`)
      .then(r => r.json())
      .then(data => { setBatch(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [id]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
    </div>
  );

  if (!batch) return (
    <div className="min-h-screen flex items-center justify-center">
      <p className="text-red-500 font-bold">Không tìm thấy lô hàng</p>
    </div>
  );

  const baseUrl = typeof window !== "undefined" ? window.location.origin : "";
  const hanDung = new Date(batch.hanDung).toLocaleDateString("vi-VN");
  const ngaySX = new Date(batch.ngaySanXuat).toLocaleDateString("vi-VN");

  return (
    <div className={`${printMode ? "" : "bg-slate-100 min-h-screen"}`}>
      {/* Toolbar — ẩn khi print */}
      {!printMode && (
        <div className="bg-white border-b border-slate-200 px-8 py-4 flex items-center justify-between print:hidden">
          <div>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">In tem QR — Lô hàng</p>
            <h1 className="text-xl font-bold text-slate-900">{batch.maLo} — {batch.sanPham?.ten || "Sản phẩm không có tên"}</h1>
            <p className="text-xs text-slate-500 mt-1">{batch.uids.length} tem · NSX: {ngaySX} · HSD: {hanDung}</p>
          </div>
          <div className="flex gap-3">
            <a href="/dashboard/inventory"
              className="px-4 py-2 text-sm font-bold text-slate-600 border border-slate-200 rounded-lg hover:bg-slate-50 transition">
              ← Quay lại
            </a>
            <button
              onClick={() => { setPrintMode(true); setTimeout(() => window.print(), 300); window.onafterprint = () => setPrintMode(false); }}
              className="px-6 py-2 bg-primary text-white text-sm font-bold rounded-lg hover:opacity-90 transition flex items-center gap-2">
              <span className="material-symbols-outlined text-sm">print</span>
              In tất cả {batch.uids.length} tem
            </button>
          </div>
        </div>
      )}

      {/* Grid QR codes */}
      <div className={`${printMode ? "p-4" : "p-8 max-w-7xl mx-auto"}`}>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4 print:grid-cols-5 print:gap-3">
          {batch.uids.map((item, idx) => (
            <div key={item.uid}
              className="bg-white rounded-xl border border-slate-200 p-3 flex flex-col items-center gap-2 print:rounded-md print:border print:break-inside-avoid">
              {/* QR Code */}
              <div className="bg-white p-1.5 rounded-lg border border-slate-100">
                <QRCodeSVG
                  value={`${baseUrl}/verify/${item.uid}`}
                  size={100}
                  bgColor="#ffffff"
                  fgColor="#004c4c"
                  level="M"
                />
              </div>
              {/* Thông tin */}
              <div className="text-center w-full">
                <p className="text-[9px] font-bold text-primary uppercase tracking-wider">VNTRUST</p>
                <p className="text-[9px] text-slate-500 truncate w-full text-center font-mono">{item.uid.substring(0, 13)}…</p>
                <p className="text-[9px] text-slate-400">{(batch.sanPham?.ten || "Sản phẩm không rõ").substring(0, 18)}</p>
                <p className="text-[9px] font-bold text-slate-600">HSD: {hanDung}</p>
                <div className={`mt-1 inline-block px-2 py-0.5 rounded-full text-[8px] font-bold ${
                  item.trangThai === "active" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
                }`}>
                  #{idx + 1} · {item.soLanQuet > 0 ? `${item.soLanQuet} quét` : "Mới"}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        @media print {
          body { -webkit-print-color-adjust: exact; }
          nav, header, footer, .print\\:hidden { display: none !important; }
        }
      `}</style>
    </div>
  );
}
