import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const loHang = await prisma.loHang.findUnique({
      where: { id },
      include: {
        sanPham: { include: { doanhNghiep: true } },
        uids: {
          orderBy: { ngayTao: "asc" },
          select: { uid: true, trangThai: true, soLanQuet: true, ngayTao: true }
        }
      }
    });

    if (!loHang) {
      return NextResponse.json({ error: "Không tìm thấy lô hàng" }, { status: 404 });
    }

    return NextResponse.json(loHang);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
