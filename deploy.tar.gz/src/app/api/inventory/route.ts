import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { prisma } from "@/lib/prisma";

// GET: Lấy toàn bộ sản phẩm + lô hàng của doanhNghiep đầu tiên
export async function GET() {
  try {
    const doanhNghiep = await prisma.doanhNghiep.findFirst();
    if (!doanhNghiep) {
      return NextResponse.json({ error: "Chưa có doanh nghiệp nào. Hãy gọi /api/seed trước." }, { status: 404 });
    }

    const sanPhams = await prisma.sanPham.findMany({
      where: { doanhNghiepId: doanhNghiep.id },
      include: {
        loHangs: {
          include: {
            _count: { select: { uids: true } }
          },
          orderBy: { ngaySanXuat: "desc" },
        },
        _count: { select: { loHangs: true } },
      },
      orderBy: { ngayTao: "desc" },
    });

    return NextResponse.json({ doanhNghiep, sanPhams });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// POST: Tạo sản phẩm mới hoặc lô hàng mới
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { type } = body;

    if (type === "product") {
      const { ten, moTa, GTIN, nuocSanXuat } = body;
      const doanhNghiep = await prisma.doanhNghiep.findFirst();
      if (!doanhNghiep) {
        return NextResponse.json({ error: "Chưa có doanh nghiệp. Hãy gọi /api/seed trước." }, { status: 404 });
      }
      const sanPham = await prisma.sanPham.create({
        data: {
          maSKU: `SKU-${randomUUID().substring(0, 8).toUpperCase()}`,
          ten,
          moTa: moTa || null,
          GTIN: GTIN || null,
          nuocSanXuat: nuocSanXuat || null,
          doanhNghiepId: doanhNghiep.id,
        }
      });
      return NextResponse.json({ sanPham }, { status: 201 });
    }

    if (type === "batch") {
      const { sanPhamId, ngaySanXuat, hanDung, soLuong } = body;
      if (!sanPhamId || !ngaySanXuat || !hanDung || !soLuong) {
        return NextResponse.json({ error: "Thiếu thông tin bắt buộc" }, { status: 400 });
      }

      const loHang = await prisma.loHang.create({
        data: {
          maLo: `LO-${randomUUID().substring(0, 8).toUpperCase()}`,
          ngaySanXuat: new Date(ngaySanXuat),
          hanDung: new Date(hanDung),
          soLuong: parseInt(soLuong),
          sanPhamId,
        }
      });

      // Tự động tạo MaDinhDanh (QR UIDs) theo số lượng
      const qty = Math.min(parseInt(soLuong), 10000);
      const uids = Array.from({ length: qty }, () => ({
        uid: randomUUID(),
        loai: "QR",
        loHangId: loHang.id,
      }));

      await prisma.maDinhDanh.createMany({ data: uids });

      return NextResponse.json({ loHang, totalUids: uids.length }, { status: 201 });
    }

    return NextResponse.json({ error: "type phải là 'product' hoặc 'batch'" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
