import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";


export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const sanPhamId = searchParams.get('sanPhamId');

    const whereClause = sanPhamId ? { sanPhamId } : {};

    const haukiems = await prisma.ketQuaHauKiem.findMany({
      where: whereClause,
      include: {
        sanPham: true,
        loHang: true,
      },
      orderBy: {
        ngayPhanTich: 'desc',
      },
    });

    return NextResponse.json(haukiems);
  } catch (error) {
    console.error("GET /api/haukiem list error:", error);
    return NextResponse.json({ error: "Lỗi Server" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { 
      doiTuongLayMau, 
      coSoPhanTich, 
      ngayLayMau, 
      ngayPhanTich, 
      ketQua, 
      chiTieuVuotNguong, 
      fileDinhKem, 
      ghiChu, 
      sanPhamId, 
      loHangId 
    } = body;

    const newHauKiem = await prisma.ketQuaHauKiem.create({
      data: {
        doiTuongLayMau,
        coSoPhanTich,
        ngayLayMau: new Date(ngayLayMau),
        ngayPhanTich: new Date(ngayPhanTich),
        ketQua,
        chiTieuVuotNguong,
        fileDinhKem,
        ghiChu,
        sanPhamId: sanPhamId || null,
        loHangId: loHangId || null,
        trangThaiXacMinh: "pending",
      },
    });

    return NextResponse.json(newHauKiem);
  } catch (error) {
    console.error("POST /api/haukiem create error:", error);
    return NextResponse.json({ error: "Lỗi Server" }, { status: 500 });
  }
}
