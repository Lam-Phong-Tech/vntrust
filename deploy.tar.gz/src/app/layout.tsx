import type { Metadata } from "next";
import { Manrope, Inter } from "next/font/google";
import "./globals.css";
import ClientShell from "@/components/ClientShell";

const fontManrope = Manrope({ variable: "--font-headline", subsets: ["latin", "vietnamese"] });
const fontInter = Inter({ variable: "--font-body", subsets: ["latin", "vietnamese"] });

export const metadata: Metadata = {
  title: "VNTrust | Intelligent Anti-Counterfeit",
  description: "Bảo vệ Di sản Thương hiệu với VNTrust.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="vi" className={`${fontManrope.variable} ${fontInter.variable} h-full antialiased`}>
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
      </head>
      <body className="min-h-full flex flex-col text-white font-body selection:bg-cyan-500/30">
        <ClientShell>
          {children}
        </ClientShell>
      </body>
    </html>
  );
}
