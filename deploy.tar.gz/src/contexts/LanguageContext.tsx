"use client";
import { createContext, useContext, useState, useEffect, ReactNode } from "react";

// ─── Translation Dictionary ───────────────────────────────────────────────────
const dict: Record<string, Record<string, string>> = {
  // ── Nav ──
  nav_verify:        { vi: "Xác thực",         en: "Verify",       zh: "认证",       ja: "認証",    ko: "인증",    fr: "Vérifier" },
  nav_supply:        { vi: "Chuỗi cung ứng",   en: "Supply Chain", zh: "供应链",     ja: "サプライチェーン", ko: "공급망", fr: "Chaîne d'approvisionnement" },
  nav_dashboard:     { vi: "Bảng điều khiển",  en: "Dashboard",    zh: "控制台",     ja: "ダッシュボード",   ko: "대시보드", fr: "Tableau de bord" },
  nav_enterprise:    { vi: "Doanh nghiệp",     en: "Enterprise",   zh: "企业",       ja: "エンタープライズ", ko: "기업",     fr: "Entreprise" },
  nav_login:         { vi: "Đăng nhập",        en: "Login",        zh: "登录",       ja: "ログイン", ko: "로그인",   fr: "Connexion" },
  // ── Search ──
  search_title:      { vi: "TÌM KIẾM SẢN PHẨM BẰNG SỐ SERIAL?", en: "SEARCH PRODUCTS BY SERIAL?", zh: "通过序列号搜索产品?", ja: "シリアル番号で商品を検索?", ko: "시리얼 번호로 제품 검색?", fr: "RECHERCHER PAR NUMÉRO DE SÉRIE?" },
  search_sub:        { vi: "Trợ lý AI VNTrust...", en: "VNTrust AI Assistant...", zh: "VNTrust AI助手...", ja: "VNTrust AIアシスタント...", ko: "VNTrust AI 어시스턴트...", fr: "Assistant IA VNTrust..." },
  search_ph:         { vi: "Nhập số serial để xác thực...", en: "Enter serial number to verify...", zh: "输入序列号进行验证...", ja: "シリアル番号を入力...", ko: "시리얼 번호 입력...", fr: "Entrez le numéro de série..." },
  // ── App Cards ──
  app_inv:           { vi: "Tài sản & Lô hàng",    en: "Assets & Batches",      zh: "资产和批次",    ja: "資産とバッチ",   ko: "자산 및 배치",       fr: "Actifs & Lots" },
  app_inv_sub:       { vi: "Quản lý Kho hàng",     en: "Inventory Management",  zh: "库存管理",      ja: "在庫管理",       ko: "재고 관리",          fr: "Gestion des stocks" },
  app_sc:            { vi: "Chuỗi Cung ứng",       en: "Supply Chain",          zh: "供应链",        ja: "サプライチェーン",ko: "공급망",             fr: "Chaîne d'approvisionnement" },
  app_sc_sub:        { vi: "Bản đồ Phân phối",     en: "Distribution Map",      zh: "分发地图",      ja: "配送マップ",     ko: "배포 지도",          fr: "Carte de distribution" },
  app_verify:        { vi: "Quét QR Ngay",         en: "Scan QR Now",           zh: "立即扫描QR",    ja: "QRをスキャン",   ko: "QR 스캔",            fr: "Scanner QR" },
  app_verify_sub:    { vi: "Xác thực Nhanh",       en: "Quick Verify",          zh: "快速验证",      ja: "クイック認証",   ko: "빠른 인증",          fr: "Vérification rapide" },
  app_hk:            { vi: "Hậu kiểm & Thu hồi",  en: "Post-Audit & Recall",   zh: "事后审计和召回", ja: "事後監査と回収",  ko: "사후 감사 및 회수",  fr: "Audit & Rappel" },
  app_hist:          { vi: "Nhật ký Hệ thống",    en: "System History",        zh: "系统历史",      ja: "システム履歴",   ko: "시스템 기록",        fr: "Historique système" },
  app_emg:           { vi: "Trung tâm Sự cố",     en: "Incident Center",       zh: "事故中心",      ja: "インシデントセンター", ko: "사고 센터",      fr: "Centre d'incidents" },
  // ── Security ──
  sec_title:         { vi: "BẢO MẬT & HỖ TRỢ",    en: "SECURITY & SUPPORT",   zh: "安全与支持",   ja: "セキュリティとサポート", ko: "보안 및 지원", fr: "SÉCURITÉ & SUPPORT" },
  sec_team:          { vi: "ĐỘI NGŨ CHUYÊN GIA BẢO MẬT", en: "SECURITY EXPERT TEAM", zh: "安全专家团队", ja: "セキュリティ専門家チーム", ko: "보안 전문가 팀", fr: "ÉQUIPE D'EXPERTS SÉCURITÉ" },
  sec_team_sub:      { vi: "Hỗ trợ chống giả chuyên sâu", en: "In-depth anti-counterfeit support", zh: "深度防伪支持", ja: "詳細な偽造防止サポート", ko: "심층 위조 방지 지원", fr: "Support anti-contrefaçon approfondi" },
  sec_hotline:       { vi: "ĐƯỜNG DÂY NÓNG 24/7",  en: "HOTLINE 24/7",         zh: "24/7热线",     ja: "24/7ホットライン", ko: "24/7 핫라인",  fr: "LIGNE D'ASSISTANCE 24/7" },
  sec_hotline_sub:   { vi: "Xử lý ngay lập tức: HCM, HN...", en: "Immediate support: HCM, HN...", zh: "立即处理：胡志明市，河内...", ja: "即時対応：HCM、HN...", ko: "즉각 처리: HCM, HN...", fr: "Traitement immédiat：HCM, HN..." },
  // ── AI button ──
  ai_btn:            { vi: "TRỢ LÝ AI",            en: "AI ASSISTANT",         zh: "AI助手",       ja: "AIアシスタント",  ko: "AI 어시스턴트",      fr: "ASSISTANT IA" },
  recent:            { vi: "Hoạt động Gần đây",    en: "Recent Activity",      zh: "最近活动",     ja: "最近のアクティビティ", ko: "최근 활동",      fr: "Activité récente" },
  map_title:         { vi: "BẢN ĐỒ VIỆT NAM",     en: "VIETNAM MAP",           zh: "越南地图",     ja: "ベトナム地図",      ko: "베트남 지도",         fr: "CARTE VIETNAM" },
  // ── Verify Page ──
  verify_badge:      { vi: "Cổng Xác thực Trung tâm (Zero-Trust)", en: "Central Authentication Gateway (Zero-Trust)", zh: "中央认证网关", ja: "中央認証ゲートウェイ", ko: "중앙 인증 게이트웨이", fr: "Passerelle d'authentification centrale" },
  verify_title:      { vi: "Mạng lưới đối soát", en: "Verification Network", zh: "核查网络", ja: "検証ネットワーク", ko: "검증 네트워크", fr: "Réseau de vérification" },
  verify_sub:        { vi: "Chọn phương thức phù hợp để bắt đầu quy trình kiểm định. Mọi dữ liệu đều được ánh xạ lên Sổ cái Bất biến Blockchain VNTrust.", en: "Choose the appropriate method to begin the verification process. All data is mapped to the VNTrust Immutable Blockchain Ledger.", zh: "选择合适的方式开始验证流程。所有数据均映射到VNTrust不可变区块链账本。", ja: "検証プロセスを開始する適切な方法を選択してください。", ko: "검증 프로세스를 시작하기 위해 적절한 방법을 선택하세요.", fr: "Choisissez la méthode appropriée pour commencer le processus de vérification." },
  verify_new:        { vi: "MỚI", en: "NEW", zh: "新功能", ja: "新機能", ko: "신규", fr: "NOUVEAU" },
  verify_card1_title:{ vi: "Quét Mã Bảo Mật", en: "Scan Security Code", zh: "扫描安全码", ja: "セキュリティコードをスキャン", ko: "보안 코드 스캔", fr: "Scanner le code de sécurité" },
  verify_card1_desc: { vi: "Sử dụng Camera thiết bị để quét Tem Chống Giả (QR / Mã Vạch 1D) chuẩn xác nhất.", en: "Use your device camera to scan Anti-Counterfeit Stamps (QR / 1D Barcode) with the highest accuracy.", zh: "使用设备摄像头扫描防伪贴标（QR码/一维条形码），准确率最高。", ja: "デバイスカメラで偽造防止スタンプをスキャンします。", ko: "기기 카메라를 사용하여 위조 방지 스탬프를 스캔하세요.", fr: "Utilisez la caméra de votre appareil pour scanner les tampons anti-contrefaçon." },
  verify_card1_cta:  { vi: "Bắt đầu Quét", en: "Start Scanning", zh: "开始扫描", ja: "スキャン開始", ko: "스캔 시작", fr: "Commencer le scan" },
  verify_card2_title:{ vi: "Nhập Mã Serial", en: "Enter Serial Code", zh: "输入序列号", ja: "シリアルコードを入力", ko: "시리얼 코드 입력", fr: "Saisir le code série" },
  verify_card2_desc: { vi: "Tra cứu chéo bằng cách nhập mã ký tự (UID) in dọc tem thẻ cào hoặc mã in trên nhãn.", en: "Cross-check by entering the character code (UID) printed on the scratch card or label.", zh: "通过输入刮刮卡或标签上印制的字符码进行交叉核验。", ja: "スクラッチカードに印刷された文字コードを入力してクロスチェックします。", ko: "스크래치 카드에 인쇄된 문자 코드를 입력하여 교차 확인하세요.", fr: "Vérification croisée en saisissant le code alphanumérique imprimé sur la carte." },
  verify_card2_cta:  { vi: "Nhập Dữ liệu", en: "Enter Data", zh: "输入数据", ja: "データを入力", ko: "데이터 입력", fr: "Saisir les données" },
  verify_card3_title:{ vi: "AI Đối Soát Giấy Tờ", en: "AI Document Verification", zh: "AI文件核查", ja: "AI書類照合", ko: "AI 문서 검증", fr: "Vérification de documents par IA" },
  verify_card3_desc: { vi: "Tải lên Chứng nhận, Vi bằng, Invoice. Công nghệ OCR bóc tách và phân tích mộc chữ ký giả mạo.", en: "Upload Certificates, Notarial Records, Invoices. OCR technology extracts and analyzes forged seals and signatures.", zh: "上传证书、公证记录、发票。OCR技术提取并分析伪造的印章和签名。", ja: "証明書をアップロード。OCR技術で偽造の印章と署名を分析します。", ko: "증명서를 업로드하세요. OCR 기술로 위조 도장과 서명을 분석합니다.", fr: "Téléchargez des certificats. La technologie OCR extrait les cachets et signatures falsifiés." },
  verify_card3_cta:  { vi: "Tải file lên", en: "Upload File", zh: "上传文件", ja: "ファイルをアップロード", ko: "파일 업로드", fr: "Télécharger le fichier" },

  // ── Enterprise Page ──
  ent_badge:         { vi: "Giải pháp B2B Toàn diện", en: "Comprehensive B2B Solution", zh: "全面的B2B解决方案", ja: "包括的なB2Bソリューション", ko: "종합 B2B 솔루션", fr: "Solution B2B complète" },
  ent_title:         { vi: "Nền tảng Quản trị", en: "Management Platform", zh: "管理平台", ja: "管理プラットフォーム", ko: "관리 플랫폼", fr: "Plateforme de gestion" },
  ent_sub:           { vi: "Hệ sinh thái chống giả mạo và quản lý chuỗi cung ứng bằng công nghệ siêu thông minh. Chúng tôi cung cấp giải pháp chuyển đổi số toàn diện giúp doanh nghiệp bảo vệ di sản thương hiệu, minh bạch hoá nguồn gốc và trực tiếp giao tiếp với tệp người dùng cuối.", en: "An anti-counterfeiting ecosystem powered by hyper-intelligent technology. We provide comprehensive digital transformation solutions to protect brand heritage and ensure origin transparency.", zh: "基于超智能技术的防伪和供应链管理生态系统，帮助企业保护品牌遗产、透明化溯源。", ja: "超知能技術を活用した偽造防止エコシステム。ブランド資産の保護と原産地の透明化を支援します。", ko: "초지능 기술로 구동되는 위조 방지 생태계. 브랜드 유산 보호와 원산지 투명성을 돕습니다.", fr: "Un écosystème anti-contrefaçon alimenté par une technologie hyper-intelligente pour protéger le patrimoine de marque." },
  ent_features_title:{ vi: "Tính năng Cốt lõi", en: "Core Features", zh: "核心功能", ja: "コア機能", ko: "핵심 기능", fr: "Fonctionnalités principales" },
  ent_f1_title:      { vi: "Số hoá Chuỗi Cung ứng", en: "Supply Chain Digitization", zh: "供应链数字化", ja: "サプライチェーンのデジタル化", ko: "공급망 디지털화", fr: "Numérisation de la chaîne d'approvisionnement" },
  ent_f1_desc:       { vi: "Theo dõi đường đi của từng đơn vị sản phẩm từ xưởng sản xuất, kho bãi, qua nhà phân phối đến điểm bán lẻ trên hệ thống bản đồ nhiệt thời gian thực.", en: "Track each product unit from factory, warehouse, through distributors to retail points on a real-time heat map.", zh: "在实时热力图上追踪每件产品从工厂到零售点的全程路径。", ja: "リアルタイムヒートマップで各製品の工場から小売店までの移動を追跡します。", ko: "실시간 히트맵에서 공장, 창고, 소매점까지 각 제품 단위를 추적합니다.", fr: "Suivez chaque unité de produit de l'usine aux points de vente sur une carte thermique en temps réel." },
  ent_f2_title:      { vi: "Xác thực Chống giả Tức thời", en: "Instant Anti-counterfeit Verification", zh: "即时防伪验证", ja: "即時偽造防止検証", ko: "즉각 위조 방지 인증", fr: "Vérification anti-contrefaçon instantanée" },
  ent_f2_desc:       { vi: "Bộ thẻ sản phẩm được gắn định danh mã QR động. Khách hàng dễ dàng dùng Camera điện thoại để check mã, nhận chứng chỉ chính hãng trực quan.", en: "Product cards embedded with dynamic QR identity codes. Customers use their phone camera to check codes and receive authenticity certificates.", zh: "产品卡片嵌入动态QR身份码。客户可用手机摄像头扫码，获取正品证书。", ja: "製品カードにダイナミックQRコードを埋め込み。顧客はスマホで正規品証明書を受け取れます。", ko: "제품 카드에 동적 QR 식별 코드 내장. 고객이 정품 인증서를 받을 수 있습니다.", fr: "Les cartes produits dotées de codes QR dynamiques. Les clients reçoivent des certificats d'authenticité." },
  ent_f3_title:      { vi: "Báo cáo Mảng AI Cảnh Báo", en: "AI Alert Analytics", zh: "AI预警分析报告", ja: "AIアラート分析レポート", ko: "AI 경고 분석", fr: "Rapports d'alertes IA" },
  ent_f3_desc:       { vi: "Thu thập và phân tích dữ liệu quét toàn thế giới. Tự động phát giác ngay hành vi làm giả khi 1 lô hàng/mã số có luồng quét bất thường.", en: "Collect and analyze global scan data. Automatically detect counterfeiting when a batch has abnormal scan patterns.", zh: "收集并分析全球扫描数据。自动检测批次异常扫描流量中的伪造行为。", ja: "グローバルスキャンデータを分析。異常なスキャンパターンで偽造行為を自動検出します。", ko: "전 세계 스캔 데이터를 분석합니다. 비정상 스캔 패턴이 있을 때 위조 행위를 자동 감지합니다.", fr: "Collectez les données de scan mondiales. Détectez automatiquement les comportements de contrefaçon." },
  ent_f4_title:      { vi: "Tích hợp Hệ thống (ERP)", en: "System Integration (ERP)", zh: "系统集成（ERP）", ja: "システム統合（ERP）", ko: "시스템 통합 (ERP)", fr: "Intégration système (ERP)" },
  ent_f4_desc:       { vi: "Giao thức API kết nối sẵn với Oracle, SAP, phần mềm quản kho nội khối. Đẩy dữ liệu theo kiện hàng tự động không cần thao tác dán mã thủ công.", en: "API protocols ready to connect with Oracle, SAP, internal warehouse software. Push data per shipment automatically without manual code entry.", zh: "API协议可与Oracle、SAP及内部仓储软件直接对接，按货件自动推送数据。", ja: "Oracle、SAP、社内倉庫ソフトウェアとの接続に対応。手動入力不要で貨物ごとにデータを自動プッシュ。", ko: "Oracle, SAP와 연결 준비된 API 프로토콜. 수동 코드 입력 없이 화물별 데이터를 자동 전송합니다.", fr: "Protocoles API prêts à se connecter avec Oracle, SAP. Poussez les données par expédition automatiquement." },
  ent_process_title: { vi: "Quy trình Vận hành Chuẩn", en: "Standard Operating Process", zh: "标准运营流程", ja: "標準運営プロセス", ko: "표준 운영 프로세스", fr: "Processus opérationnel standard" },
  ent_s1_title:      { vi: "Gắn Định Danh (Tagging)", en: "Identity Tagging", zh: "身份标签贴标", ja: "識別タグ付け", ko: "식별 태깅", fr: "Étiquetage d'identité" },
  ent_s1_desc:       { vi: "Sản phẩm ở nhà máy được gắn mã QR VNTrust công nghệ nén mật mã trước khi đóng thùng và xuất xưởng ra thị trường.", en: "Products at the factory are tagged with VNTrust QR codes using encryption technology before packaging and market release.", zh: "工厂产品在包装出厂前贴附采用加密技术的VNTrust QR码。", ja: "工場の製品は梱包前に暗号化QRコードでタグ付けされます。", ko: "공장의 제품은 포장 전에 암호화 QR 코드로 태깅됩니다.", fr: "Les produits sont étiquetés avec des codes QR VNTrust avant l'emballage." },
  ent_s2_title:      { vi: "Kích hoạt và Phân phối", en: "Activation and Distribution", zh: "激活与分发", ja: "有効化と配布", ko: "활성화 및 유통", fr: "Activation et Distribution" },
  ent_s2_desc:       { vi: "Tổng kho / Đại lý quét mã lô hàng lúc nhập kho, kích hoạt trạng thái hợp pháp trên hệ thống kiểm soát trung tâm.", en: "Warehouses and Agents scan batch codes upon receiving, activating legal circulation status on the central control system.", zh: "总仓和代理商在入库时扫描批次码，在中央控制系统中激活合法流通状态。", ja: "倉庫と代理店が入庫時にバッチコードをスキャンし、合法流通ステータスを有効化します。", ko: "창고와 대리점이 입고 시 배치 코드를 스캔하여 합법적 유통 상태를 활성화합니다.", fr: "Les entrepôts et agents scannent les codes de lot à la réception, activant le statut de circulation légale." },
  ent_s3_title:      { vi: "Người dùng Xác minh", en: "Consumer Verification", zh: "消费者验证", ja: "消費者検証", ko: "소비자 인증", fr: "Vérification du consommateur" },
  ent_s3_desc:       { vi: "Phía người mua chỉ cần một chiếc smartphone quét mã QR trên hộp. Nhận ngay chứng minh nguồn gốc chính hiệu một cách nhanh chóng.", en: "Buyers only need a smartphone to scan the QR code on the box. Instantly receive proof of authentic origin.", zh: "买家只需用智能手机扫描包装盒上的QR码，即可即时获得正品溯源证明。", ja: "購入者はスマートフォンでQRコードをスキャンするだけで正規品証明を受け取れます。", ko: "구매자는 스마트폰으로 QR 코드를 스캔하기만 하면 즉시 정품 원산지 증명을 받으세요.", fr: "Les acheteurs scannent le code QR et reçoivent instantanément la preuve d'origine authentique." },

  // ── Supply Chain & Dashboard ──
  sc_board:          { vi: "Bảng điều khiển", en: "Dashboard", zh: "控制台", ja: "ダッシュボード", ko: "대시보드", fr: "Tableau de bord" },
  sc_analytics:      { vi: "Phân tích", en: "Analytics", zh: "分析", ja: "分析", ko: "분석", fr: "Analyse" },
  sc_title:          { vi: "Phân tích Chuỗi Cung ứng", en: "Supply Chain Analytics", zh: "供应链分析", ja: "サプライチェーン分析", ko: "공급망 분석", fr: "Analyse de la chaîne d'approvisionnement" },
  sc_30d:            { vi: "30 Ngày Qua", en: "Last 30 Days", zh: "过去30天", ja: "過去30日", ko: "지난 30일", fr: "30 derniers jours" },
  sc_7d:             { vi: "7 Ngày Qua", en: "Last 7 Days", zh: "过去7天", ja: "過去7日", ko: "지난 7일", fr: "7 derniers jours" },
  sc_90d:            { vi: "90 Ngày Qua", en: "Last 90 Days", zh: "过去90天", ja: "過去90日", ko: "지난 90일", fr: "90 derniers jours" },
  sc_total_auth:     { vi: "Tổng Số Lượt Xác Thực", en: "Total Authentications", zh: "总认证次数", ja: "総認証数", ko: "총 인증 수", fr: "Authentifications totales" },
  sc_fake_prev:      { vi: "Nỗ Lực Làm Giả Bị Ngăn Chặn", en: "Fake Attempts Prevented", zh: "已阻止的伪造尝试", ja: "阻止した偽造試行", ko: "차단된 위조 시도", fr: "Tentatives de faux empêchées" },
  sc_active:         { vi: "ĐANG HOẠT ĐỘNG", en: "ACTIVE", zh: "活跃中", ja: "アクティブ", ko: "활성", fr: "ACTIF" },
  sc_efficiency:     { vi: "Hiệu Quả Chuỗi Cung Ứng", en: "Supply Chain Efficiency", zh: "供应链效率", ja: "サプライチェーン効率", ko: "공급망 효율", fr: "Efficacité de la chaîne" },
  sc_optimal:        { vi: "TỐI ƯU", en: "OPTIMAL", zh: "最优", ja: "最適", ko: "최적", fr: "OPTIMAL" },
  sc_auth_speed:     { vi: "Tốc Độ Xác Thực", en: "Authentication Speed", zh: "认证速度", ja: "認証速度", ko: "인증 속도", fr: "Vitesse d'authentification" },
  sc_live_traffic:   { vi: "Lưu lượng thực tế trên các nút mạng toàn cầu", en: "Live traffic across global nodes", zh: "全球节点实时流量", ja: "グローバルノードのライブトラフィック", ko: "글로벌 노드의 실시간 트래픽", fr: "Trafic en direct sur les noeuds" },
  sc_day:            { vi: "Ngày", en: "Day", zh: "天", ja: "日", ko: "일", fr: "Jour" },
  sc_week:           { vi: "Tuần", en: "Week", zh: "周", ja: "週", ko: "주", fr: "Semaine" },
  sc_month:          { vi: "Tháng", en: "Month", zh: "月", ja: "月", ko: "월", fr: "Mois" },
  sc_today:          { vi: "Hôm nay:", en: "Today:", zh: "今天：", ja: "本日：", ko: "오늘：", fr: "Aujourd'hui:" },
  sc_trust_dist:     { vi: "Phân bổ Mức Độ Tinh cậy", en: "Trust Level Distribution", zh: "信任度分布", ja: "信頼レベル分布", ko: "신뢰 수준 분포", fr: "Répartition du niveau de confiance" },
  sc_safety_status:  { vi: "Trạng thái an toàn trên toàn hệ thống", en: "System-wide safety status", zh: "全系统安全状态", ja: "システム全体のセキュリティ状態", ko: "시스템 전체 안전 상태", fr: "Statut de sécurité du système" },
  sc_safe_score:     { vi: "ĐIỂM AN TOÀN", en: "SAFETY SCORE", zh: "安全评分", ja: "安全スコア", ko: "안전 점수", fr: "SCORE DE SÉCURITÉ" },
  sc_scan_activity:  { vi: "Hoạt Động Quét Toàn Quốc", en: "National Scan Activity", zh: "全国扫描活动", ja: "全国スキャン活動", ko: "전국 스캔 활동", fr: "Activité de scan nationale" },
  sc_geo_dist:       { vi: "Phân bổ xác thực theo vị trí địa lý", en: "Authentication distribution by geography", zh: "按地理位置的认证分布", ja: "地域別認証分布", ko: "지역별 인증 분포", fr: "Répartition par géographie" },
  sc_live_data:      { vi: "Dữ Liệu Trực Tiếp", en: "Live Data", zh: "实时数据", ja: "ライブデータ", ko: "실시간 데이터", fr: "Données en direct" },
  sc_new_scan:       { vi: "Lượt quét mới: Nút", en: "New scan: Node", zh: "新扫描：节点", ja: "新しいスキャン：ノード", ko: "새 스캔：노드", fr: "Nouveau scan: Noeud" },
  sc_latest_ledger:  { vi: "Nhật Ký Sổ Cái Mới Nhất", en: "Latest Ledger Logs", zh: "最新账本日志", ja: "最新台帳ログ", ko: "최신 원장 로그", fr: "Derniers journaux du grand livre" },
  sc_live:           { vi: "LIVE", en: "LIVE", zh: "实时", ja: "ライブ", ko: "라이브", fr: "EN DIRECT" },
  sc_realtime_block: { vi: "Cập nhật khối thời gian thực", en: "Real-time block updates", zh: "实时区块更新", ja: "リアルタイムブロック更新", ko: "실시간 블록 업데이트", fr: "Mises à jour des blocs en temps réel" },
  sc_full_network:   { vi: "Toàn Bộ Mạng Lưới Blockchain", en: "Full Blockchain Network", zh: "完整区块链网络", ja: "完全ブロックチェーンネットワーク", ko: "전체 블록체인 네트워크", fr: "Réseau complet de la blockchain" },
  sc_ai_running:     { vi: "Trình Phân Tích AI Đang Chạy", en: "AI Analyzer Running", zh: "AI分析器运行中", ja: "AIアナライザー稼働中", ko: "AI 분석기 실행 중", fr: "Analyseur IA en cours" },
  sc_scanning:       { vi: "Đang quét", en: "Scanning", zh: "正在扫描", ja: "スキャン中", ko: "스캔 중", fr: "Analyse en cours" },
  sc_hotspot:        { vi: "Điểm nóng", en: "Hotspot", zh: "热点", ja: "ホットスポット", ko: "핫스팟", fr: "Point chaud" },
  sc_tracking:       { vi: "Đang theo dõi", en: "Tracking", zh: "追踪中", ja: "追跡中", ko: "추적 중", fr: "En suivi" },
  sc_normal:         { vi: "Bình thường", en: "Normal", zh: "正常", ja: "正常", ko: "정상", fr: "Normal" },
  sc_export:         { vi: "EXPORT REPORT", en: "EXPORT REPORT", zh: "导出报告", ja: "レポート出力", ko: "보고서 내보내기", fr: "EXPORTER RAPPORT" },

  // ── Supply Chain inline text ──
  sc_active_badge:   { vi: "ĐANG HOẠT ĐỘNG", en: "ACTIVE", zh: "活跃中", ja: "アクティブ", ko: "활성", fr: "ACTIF" },
  sc_ai_detect:      { vi: "Phát hiện bởi Phân tích Phân cực AI", en: "Detected by Polarization AI Analytics", zh: "由极化AI分析检测", ja: "偏光AI分析によって検出", ko: "편광 AI 분석으로 감지", fr: "Détecté par l'analyse IA de polarisation" },
  sc_latency:        { vi: "Độ trễ Blockchain:", en: "Blockchain Latency:", zh: "区块链延迟：", ja: "ブロックチェーン遅延：", ko: "블록체인 지연：", fr: "Latence blockchain :" },
  sc_unit_scans:     { vi: "lượt", en: "scans", zh: "次", ja: "回", ko: "회", fr: "scans" },
  sc_data_per_sec:   { vi: "dữ liệu/giây", en: "data/sec", zh: "数据/秒", ja: "データ/秒", ko: "데이터/초", fr: "données/sec" },
  sc_action_log1:    { vi: "Thực thi Hợp đồng Thông minh", en: "Smart Contract Execution", zh: "智能合约执行", ja: "スマートコントラクト実行", ko: "스마트 컨트랙트 실행", fr: "Exécution de contrat intelligent" },
  sc_action_log2:    { vi: "Xác nhận NFT Lô hàng mới", en: "New Batch NFT Confirmed", zh: "新批次NFT已确认", ja: "新バッチNFT確認済み", ko: "신규 배치 NFT 확인됨", fr: "NFT de nouveau lot confirmé" },
  sc_action_log3:    { vi: "Đồng bộ Giao dịch Blockchain", en: "Blockchain Transaction Sync", zh: "区块链交易同步", ja: "ブロックチェーン取引同期", ko: "블록체인 거래 동기화", fr: "Synchronisation des transactions blockchain" },
  sc_action_log4:    { vi: "Cập nhật Trạng thái Phân cực AI", en: "AI Polarization Status Update", zh: "AI极化状态更新", ja: "AI偏光ステータス更新", ko: "AI 편광 상태 업데이트", fr: "Mise à jour du statut IA de polarisation" },
  sc_log_auth_done:  { vi: "Xác Thực Lô Hàng Hoàn Tất", en: "Batch Authentication Complete", zh: "批次验证完成", ja: "バッチ認証完了", ko: "배치 인증 완료", fr: "Authentification de lot terminée" },
  sc_log_blocked:    { vi: "Ngăn Chặn Hoạt Động Bất Thường", en: "Abnormal Activity Blocked", zh: "已阻止异常活动", ja: "異常活動を遮断", ko: "비정상 활동 차단됨", fr: "Activité anormale bloquée" },
  sc_log_contract:   { vi: "Thực Thi Hợp Đồng Thông Minh", en: "Smart Contract Executed", zh: "智能合约已执行", ja: "スマートコントラクト実行済み", ko: "스마트 컨트랙트 실행됨", fr: "Contrat intelligent exécuté" },
  sc_log_just_now:   { vi: "Vừa xong", en: "Just now", zh: "刚刚", ja: "たった今", ko: "방금 전", fr: "À l'instant" },
  sc_log_mins_ago:   { vi: "phút trước", en: "min ago", zh: "分钟前", ja: "分前", ko: "분 전", fr: "min. avant" },
  sc_log_fraud:      { vi: "Ngăn Chặn Cố Gắng Làm Giả", en: "Counterfeit Attempt Blocked", zh: "已阻止伪造尝试", ja: "偽造試行を遮断", ko: "위조 시도 차단됨", fr: "Tentative de contrefaçon bloquée" },
  sc_log_found_at:   { vi: "Phát hiện tại", en: "Detected at", zh: "发现于", ja: "発見場所：", ko: "발견 위치：", fr: "Détecté à" },
  sc_log_sig_viol:   { vi: "Vi phạm chữ ký:", en: "Signature violation:", zh: "签名违规：", ja: "署名違反：", ko: "서명 위반：", fr: "Violation de signature :" },
  sc_log_sync:       { vi: "Đồng bộ dữ liệu mạng: Nút", en: "Network data sync: Node", zh: "网络数据同步：节点", ja: "ネットワークデータ同期：ノード", ko: "네트워크 데이터 동기화：노드", fr: "Sync données réseau : Noeud" },
  sc_log_new_node:   { vi: "Kết Nối Nút Mạng Mới:", en: "New Network Node Connected:", zh: "新网络节点已连接：", ja: "新しいネットワークノード接続済み：", ko: "새 네트워크 노드 연결됨：", fr: "Nouveau noeud réseau connecté :" },
  sc_log_auth_cert:  { vi: "Xác thực Cấp phép", en: "Licensed Authentication", zh: "授权认证", ja: "ライセンス認証", ko: "인가 인증", fr: "Authentification autorisée" },

};

export function t(key: string, lang: string): string {
  return dict[key]?.[lang] ?? dict[key]?.vi ?? key;
}

// ─── Context ─────────────────────────────────────────────────────────────────
interface LangCtx { lang: string; setLang: (l: string) => void; t: (key: string) => string; }
const LanguageContext = createContext<LangCtx>({ lang: "vi", setLang: () => {}, t: (k) => k });

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState("vi");
  useEffect(() => {
    const saved = localStorage.getItem("vntrust_lang");
    if (saved) setLangState(saved);
  }, []);
  const setLang = (l: string) => { setLangState(l); localStorage.setItem("vntrust_lang", l); };
  return (
    <LanguageContext.Provider value={{ lang, setLang, t: (key) => t(key, lang) }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLanguage = () => useContext(LanguageContext);
