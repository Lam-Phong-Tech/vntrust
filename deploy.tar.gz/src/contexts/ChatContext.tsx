"use client";
import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────
export interface ChatMsg { from: string; text: string; }

interface ChatContextValue {
  msgs: ChatMsg[];
  addMsg: (msg: ChatMsg) => void;
  setMsgs: (msgs: ChatMsg[]) => void;
  clearHistory: () => void;
}

// ─── Constants ────────────────────────────────────────────────────────────────
const CHAT_KEY = "vntrust_chat_web";
export const INIT_MSG: ChatMsg = {
  from: "ai",
  text: "Chào bạn! 👋 Mình là AI VNTrust, sẵn sàng giúp bạn:\n• Tra cứu sản phẩm theo số serial\n• Kiểm tra lô hàng & chuỗi cung ứng\n• Hướng dẫn sử dụng hệ thống\n• Hỗ trợ kỹ thuật 24/7\n\nBạn cần giúp gì hôm nay? 😊",
};

// ─── Context ──────────────────────────────────────────────────────────────────
const ChatContext = createContext<ChatContextValue | null>(null);

// ─── Old greeting patterns to migrate away from ───────────────────────────────
const OLD_GREETINGS = [
  "Chào! Tôi là AI VNTrust",
  "Mình là AI VNTrust. Bạn cần phân tích",
  "ở đây để giúp bạn",
];
function isOldGreeting(text: string) {
  return OLD_GREETINGS.some(g => text.includes(g));
}

export function ChatProvider({ children }: { children: ReactNode }) {
  const [msgs, setMsgsState] = useState<ChatMsg[]>([INIT_MSG]);

  // Load from localStorage on mount, with migration for old greetings
  useEffect(() => {
    try {
      const saved = localStorage.getItem(CHAT_KEY);
      if (saved) {
        const parsed: ChatMsg[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Migrate: if first message is an old greeting, replace it with new INIT_MSG
          if (parsed[0]?.from === "ai" && isOldGreeting(parsed[0].text)) {
            parsed[0] = INIT_MSG;
          }
          setMsgsState(parsed);
        }
      }
    } catch {}
  }, []);

  // Persist to localStorage on every change
  useEffect(() => {
    try { localStorage.setItem(CHAT_KEY, JSON.stringify(msgs)); } catch {}
  }, [msgs]);

  const addMsg = useCallback((msg: ChatMsg) => {
    setMsgsState(prev => [...prev, msg]);
  }, []);

  const setMsgs = useCallback((newMsgs: ChatMsg[]) => {
    setMsgsState(newMsgs);
  }, []);

  const clearHistory = useCallback(() => {
    setMsgsState([INIT_MSG]);
    try { localStorage.removeItem(CHAT_KEY); } catch {}
  }, []);

  return (
    <ChatContext.Provider value={{ msgs, addMsg, setMsgs, clearHistory }}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error("useChat must be used inside <ChatProvider>");
  return ctx;
}
