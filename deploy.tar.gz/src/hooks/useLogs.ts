import { useState, useEffect } from 'react';

export type Log = {
  id: number;
  action: string;
  user: string;
  ip: string;
  time: string;
  status: 'success' | 'warning' | 'error';
};

const DEFAULT_LOGS: Log[] = [
  { id: 1, action: "Đăng nhập hệ thống thành công", user: "Admin", ip: "192.168.1.1", time: "2 phút trước", status: "success" },
  { id: 2, action: "Cập nhật lô hàng Mắm 35N", user: "Admin", ip: "192.168.1.1", time: "1 giờ trước", status: "success" },
  { id: 3, action: "Cảnh báo: Phát hiện quét mã ảo", user: "System", ip: "Unknown", time: "2 giờ trước", status: "warning" },
  { id: 4, action: "Xóa cấu hình sản phẩm lỗi", user: "Admin", ip: "192.168.1.1", time: "1 ngày trước", status: "error" },
  { id: 5, action: "Tạo thành công sản phẩm: Gạo ST25", user: "Staff", ip: "10.0.0.5", time: "2 ngày trước", status: "success" },
  { id: 6, action: "Thay đổi cài đặt bảo mật", user: "Admin", ip: "192.168.1.1", time: "3 ngày trước", status: "success" },
];

export function useLogs() {
  const [logs, setLogs] = useState<Log[]>([]);

  const loadLogs = () => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('vntrust_logs');
      if (stored) {
        setLogs(JSON.parse(stored));
      } else {
        setLogs(DEFAULT_LOGS);
        localStorage.setItem('vntrust_logs', JSON.stringify(DEFAULT_LOGS));
      }
    }
  };

  useEffect(() => {
    loadLogs();
    
    const handleStorageChange = () => {
      loadLogs();
    };

    window.addEventListener('vntrust_log_update', handleStorageChange);
    return () => window.removeEventListener('vntrust_log_update', handleStorageChange);
  }, []);

  const addLog = (log: Omit<Log, 'id' | 'time'>) => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('vntrust_logs');
      let currentLogs = stored ? JSON.parse(stored) : DEFAULT_LOGS;
      
      const newLog: Log = {
        ...log,
        id: Date.now(),
        time: 'Vừa xong'
      };
      
      currentLogs = [newLog, ...currentLogs];
      localStorage.setItem('vntrust_logs', JSON.stringify(currentLogs));
      window.dispatchEvent(new Event('vntrust_log_update'));
    }
  };

  return { logs, addLog };
}
